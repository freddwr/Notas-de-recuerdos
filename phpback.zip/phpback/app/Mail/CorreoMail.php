<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CorreoMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $correo;
    public $contrasenia;
    public $usuario;
    public $datosNav;
    public function __construct($contrasenia, $usuario, $datosNav, $correo)
    {
        $this->correo= $correo;
        $this->usuario= $usuario;
        $this->datosNav= $datosNav;
        $this->contrasenia= $contrasenia;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('prueba@grupoinmofuerte.com', env('MAIL_FROM_NAME'))
                        ->view('correomail')
                        ->subject('CAMBIO DE CONTRASEÑA')
                        ->with(
                            $this->correo,
                            $this->usuario,
                            $this->datosNav,
                            $this->contrasenia,
                        );
    }
}

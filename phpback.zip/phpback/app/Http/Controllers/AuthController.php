<?php

namespace App\Http\Controllers;

use App\Mail\CorreoMail;
use Mail;
use Illuminate\Http\Request;

use App\Models\User;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Facades\JWTFactory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public $loginAfterSignUp = true;
    private $tablaUsers = 'estudiante';
    private $tablaRoles = 'roles';

    public function __construct()
    {
        $this->middleware('auth:api', [
            'except' => ['login',
                'register',
                'refresh',
                'logoutuser',
                'fogotpassword',
                'contraseniapass',
            ]
        ]);
    }


    public function contraseniapass(Request $request)
    {
        $users = User::select(
                'id',
                'pass_view',
            )
            ->where([ ['rol', '=', 'docente_tobyc'] ])
            ->get();

        // dd($users->pass_view);
        foreach ($users as $key => $value) {
            // DB::table("estudiante")->where('id', $value->id)->update([
            //     'password' => Hash::makez("{$value->pass_view}"),
            // ]);
            
            $users = User::find($value->id);
            $users->password = null;
            $users->save();
        }
        dd($users);
        // Mail::to("$usuario->correo")->send(new CorreoMail($password, $usuario, $datosNav, "$usuario->correo"));

        return $this->sendResponseFuse('', 'revisa tu email para ver tu nueva contrasenia', 200);
    }

    public function fogotpassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|min:3|max:50',
        ]);

        if ($validator->fails()) : return $this->sendErrorFuse('', "{$this->data_require}1");
        endif;
        $correo = $request->email;
        $user = User::where('correo', $correo)
            ->select(
                'id',
                'correo',
                'nombre',
                'paterno',
                'materno'
            )
            ->first();
        if (!$user) : return $this->sendErrorFuse('', "{$this->data_require}, cuenta inexistente");
        endif;
        $password = $this->random_string(8);
        $usuario = User::find($user->id);
        $usuario->pass_view = $password;
        $usuario->password = Hash::make($password);
        $usuario->activo = false;
        $usuario->save();
        $datosNav = [
            'navegador' => $request->server->get('HTTP_SEC_CH_UA'),
            'ip' => $request->server->get('REMOTE_ADDR'),
            'tiempo' => $request->server->get('REQUEST_TIME')
        ];


        // Mail::to("$usuario->correo")->send(new CorreoMail($password, $usuario, $datosNav, "$usuario->correo"));

        return $this->sendResponseFuse('', 'revisa tu email para ver tu nueva contrasenia', 200);
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'password' => 'required|string|min:6|max:20',
        ]);
        if ($validator->fails()) return $this->sendErrorFuse('', "{$this->data_require}1");

        $password = $request->password;

        $user = $this->getUserRoles('nick', $request->password);
        if (!$user) return $this->sendErrorFuse('', "error");
        if (!Hash::check($password, $user->password)) return $this->sendErrorFuse('', "verifique sus datos");

        $nick = $user->nick;
        $token = null;
        $jwt = JWTFactory::sub($user->id)
            ->datoPersonal([
                // 'usuario_rol' => $user->rol,
                'usuario_rol_id' => $user->rol,
            ])
            ->datoUser($user)
            ->make();
        if (!$token = JWTAuth::attempt([
            'nick' => $nick,
            'password' => $password,
            // 'correo' => $correo
        ], $jwt)) $this->sendErrorFuse('', "Error al obtener tus datos");

        [$principal, $main_ruta, $main_menu] = $this->menu_permisos($user->rol);

        return $this->sendResponseToken(
            $user,
            $principal,
            $main_menu,
            $main_ruta,
            $token,
            "{$this->success_login_message}",
        );
        // $validator = Validator::make($request->all(), [
        //     'email' => 'required|min:3|max:50',
        //     'password' => 'required|string|min:6|max:20',
        // ]);
        // if ($validator->fails()) return $this->sendErrorFuse('', "{$this->data_require}1");

        // $correo = $request->email;
        // $password = $request->password;

        // $user = $this->getUserRoles("correo", $correo);
        // if (!$user) return $this->sendErrorFuse('', "error");
        // if (!Hash::check($password, $user->password)) return $this->sendErrorFuse('', "verifique sus datos");

        // $nick = $user->nick;
        // $token = null;
        // $jwt = JWTFactory::sub($user->id)
        //     ->datoPersonal([
        //         'usuario_rol' => $user->rol,
        //         'usuario_rol_id' => $user->id_roles,
        //     ])
        //     ->datoUser($user)
        //     ->make();
        // if (!$token = JWTAuth::attempt([
        //     'nick' => $nick,
        //     'password' => $password,
        //     'correo' => $correo
        // ], $jwt)) $this->sendErrorFuse('', "Error al obtener tus datos");

        // [$main_ruta, $main_menu] = $this->menu_permisos($user->rol);

        // return $this->sendResponseToken(
        //     $user,
        //     $main_menu,
        //     $main_ruta,
        //     $token,
        //     "{$this->success_login_message}",
        // );
    }

    public function register(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'id' => 'required',
                'nombre' => 'required|max:50',
                'paterno' => 'required|max:50',
                'materno' => 'required|max:50',
                'telefono' => 'required|unique:users|max:50',
                'password' => 'required|string|min:6|max:20',
                'correo' => 'required|unique:users|string|min:6|max:50',
            ]);

            if ($validator->fails()) : return $this->sendError401('', "{$this->data_require}");
            endif;
            $users = new User();
            $users->id = $request->id;
            $users->nombre = $request->nombre;
            $users->paterno = $request->paterno;
            $users->materno = $request->materno;
            $users->telefono = $request->telefono;
            $users->correo = $request->correo;
            $users->pass_view = $request->password;
            $users->password = Hash::make($request->password);
            $users->id_roles = '9a84da48-fcd9-4f7c-8948-01dd707224b9';
            $users->save();

            return $this->sendResponse('Registrado', "Registrado. {$users->nombre} {$users->paterno} {$users->materno} ponte en contacto con el gerente para ser habilitado", 200);
        } catch (JWTException $exeption) {
            return response()->json([
                'status' => false,
                'message' => $exeption
            ]);
        }
    }

    public function logout()
    {
        $id = auth()->user()->id;

        try {

            $estado = User::find($id);
            $estado->activo = false;
            $estado->save();

            JWTAuth::invalidate(JWTAuth::getToken());

            return response()->json([
                'status' => true,
                'message' => 'user logout'
            ]);
        } catch (JWTException $exeption) {
            return response()->json([
                'status' => false,
                'message' => 'no logout'
            ]);
        }
    }


    public function refresh()
    {
        try {
            $token = JWTAuth::getToken();
            $refreshed = JWTAuth::refresh($token);
            $user = JWTAuth::setToken($refreshed)->toUser();

            $id = auth()->user()->id;

            $user = DB::table("estudiante")->where(['id' => $id])->first();

            $payload = JWTFactory::sub($user->id)
                ->datoPersonal([])
                ->datoUser($user)
                ->make();

            $password = $user->pass_view;
            $correo = $user->correo;
            $nick = $user->nick;
            $token = null;

            if (!$token = JWTAuth::attempt(['nick' => $nick, 'password' => $password, 'correo' => $correo], $payload)) : return $this->sendErrorFuse('', "{$this->data_require}, verificar!!!");
            endif;


            return response()->json([
                'access_token' => $token,
            ])
                ->header('Cache-Control', 'no-cache, no-store, must-revalidate');;
        } catch (JWTException $exeption) {
            return response()->json([
                'error' => $exeption,
                'status' => true,
                'message' => 'no login refresh token'
            ], 403);
        }
    }

    public function userProfile()
    {
        return response()->json(auth()->user());
    }



    protected function updateUserPass(Request $request)
    {
        $Id = auth()->user()->id;

        try {
            $persona = User::where('id', $Id)
                ->select(
                    'password',
                )
                ->first();
            $password = $request->password_old;

            if (!Hash::check($password, $persona->password)) : return $this->sendErrorFuse('password incorrecto', ['error' => 'invalido'], 400);
            endif;

            $users = User::find($Id);
            $users->nick = $request->password_new;
            $users->pass_view = $request->password_new;
            $users->password = Hash::make($request->password_new);
            $users->save();

            $this->sendResponseFuse([], 'contrasenia actualizada');
        } catch (\Exception $e) {
            return $this->sendErrorFuse('error', ['error' => $e->getMessage()], 400);
        }
    }

    protected function getUser($user)
    {
        try {

            $datos = User::where(["id" => $user])
                ->first([
                    'id',
                    'nick',
                    'nombre',
                    'paterno',
                    'materno',
                    'telefono',
                    'correo',
                ]);
            if (!$user) return null;

            $collection = $datos;

            return $this->sendResponseFuse($collection, ":)");
        } catch (\Exception $e) {
            return $this->sendErrorFuse('error', ['error' => $e->getMessage()], 401);
        }
    }
    protected function updateUser(Request $request, $user)
    {
        try {
            $Id = auth()->user()->id;;
            $datos = $request->json()->all();


            if ($request->fotonew) {
                [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutUsuario($request->foto, $request->fotonew, $request->fotoextension, 'estudiante');
                $this->deleteFile('estudiante', $Id, 'foto');

                $datos['foto'] = $foto;
                $datos['fototam'] = $fototam;
                $datos['fototipo'] = $fototipo;
                // $datos['fototipocom'] = $fototipocom;
            } else {
                unset(
                    $datos['foto'],
                    $datos['fototam'],
                    $datos['fototipo'],
                    $datos['fototipocom']
                );
            }

            unset($datos['fotonew']);
            unset($datos['fotoextension']);
            unset($datos['created']);
            unset($datos['updated']);

            foreach (array_keys($datos) as $campo) {
                DB::table('estudiante')->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            $user = $this->getUserRoles("id", $Id);
            $token_access = JWTAuth::getToken();
            $token = "{$token_access}";

            [$principal, $main_ruta, $main_menu] = $this->menu_permisos($user->rol);

            return $this->sendResponseToken(
                $user,
                $principal,
                $main_menu,
                $main_ruta,
                $token,
                "{$this->success_update_message}",
            );
        } catch (\Exception $e) {
            return $this->sendErrorFuse('error', ['error' => $e->getMessage()], 401);
        }
    }
    protected function updateUserClearPhoto()
    {
        try {
            $Id = auth()->user()->id;

            $this->deleteFile('estudiante', $Id, 'foto');

            DB::table('estudiante')->where('id', $Id)->update([
                'foto' => null,
                'fototam' => null,
                'fototipo' => null,
            ]);

            $user = $this->getUserRoles("id", $Id);
            $token_access = JWTAuth::getToken();
            $token = "{$token_access}";

            [$principal, $main_ruta, $main_menu] = $this->menu_permisos($user->rol);

            return $this->sendResponseToken(
                $user,
                $principal,
                $main_menu,
                $main_ruta,
                $token,
                "{$this->success_update_message}",
            );
        } catch (\Exception $e) {
            return $this->sendErrorFuse('error', ['error' => $e->getMessage()], 401);
        }
    }

    protected function accessToken(Request $request)
    {
        $id = auth()->user()->id;
        $token_access = JWTAuth::getToken();
        $token = "{$token_access}";

        $user = $this->getUserRoles("id", $id);
        [$principal, $main_ruta, $main_menu] = $this->menu_permisos($user->rol);

        return $this->sendResponseToken(
            $user,
            $principal,
            $main_menu,
            $main_ruta,
            $token,
            "{$this->success_login_message}"
        );
    }


    protected function sendResponseToken($user, $principal_ruta, $menu, $rutas, $token, $message)
    {
        $lastSessionId = [
            'uuid'      => $user->id,
            'role'      => $user->rol,
            'data'      => [
                'displayName'   => $user->nick,
                'displayCorreo'   => $user->correo,
                'photoURL'      => $user->foto,
            ],
            'ruta_principal' => $principal_ruta,
            'main_menu'      => $menu,
            'main_rutas'      => $rutas,
            'access_token' => $token
        ];
        return $this->sendResponseFuse($lastSessionId, $message);
    }

    protected function getUserRoles($campo, $valor)
    {
        try {
            // $user = User::join('roles', 'users.id_roles', '=', 'roles.id')
            //     ->where(["users.{$campo}" => $valor])
            //     ->first([
            //         'users.id',
            //         'users.nick',
            //         'users.password',
            //         'users.correo',
            //         'users.foto',
            //         'users.id_roles',
            //         'roles.nombre as rol'
            //     ]);
            $user = User::where($campo, $valor)
                ->first([
                    'id',
                    'nick',
                    'password',
                    'correo',
                    'foto',
                    'rol',
                ]);
            if (!$user) return null;

            return $user;
        } catch (\Exception $e) {
            dd($e);
            return null;
        }
    }
}
<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

use Intervention\Image\ImageManagerStatic as Image;

class ControllerCopy extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public $success_get_message = "Datos obtenido";
    public $success_get_one_message = "Dato obtenido";
    public $success_login_message = "Cession iniciado exitosamente";
    public $success_register_message = "Registrado exitosamente";
    public $success_update_message = "Actualizado exitosamente";
    public $success_update_one_message = "Actualizado exitosamente un registro";
    public $success_delete_message = "Eliminado exitosamente";

    public $data_require = "Datos requeridos";

    public function sendResponse($result, $message, $code = 200){
        $response = [
            'success' => true,
            'data'    => $result,
            'message' => $message,
        ];

        return response()->json($response, $code);
    }

    //no autorizado
    public function sendError401($error, $message){
        $response = [
            'success' => false,
            'message' => $message,
        ];

        if(!empty($error)){
            $response['data'] = $error;
        }

        return response()->json($response, 401);
    }

    public function sendResponseFuse($result, $message, $code = 200){
        $response = [
            'success' => true,
            'data'    => $result,
            'message' => $message,
        ];

        return response()->json($response, $code);
    }

    public function sendErrorFuse($error, $errorMessages = [], $code = 200){
        $response = [
            'success' => false,
            'data' => null,
            'message' => $errorMessages,
        ];

        if(!empty($error)){
            $response['error'] = $error;
        }

        return response()->json($response, $code);
    }

    function deleteFile ($tabla, $id,  $campo) {
        try {

            $delete = DB::table("{$tabla}")
                ->where('id', $id)
                ->first();

            Storage::disk("{$tabla}")->delete("{$delete->$campo}");

            DB::table("{$tabla}")
                ->where('id', $id)
                ->update([
                    "${campo}" => '',
                    "${campo}tipo" => '',
                    "${campo}tam" => 0,
                ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }

    }



    function imagePutFileArchivo ($img, $fotonew, $fotoextension, $carpeta) {
        // dd($img);
        $image = $img;
        $image_extension = "";
        $image_extension_completo = "";
        $archivo_extension = '';
        $cont = 0;

        $allowed_mimetypes_excel_pdf = array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/pdf', 'application/zip');

        $allowed_mimetypes_imagen = array('image/png', 'image/jpeg', 'image/jpg');

    if ($image && in_array($fotoextension, $allowed_mimetypes_excel_pdf)) {
        preg_match("/data:application\/(.*?);/",$image,$image_extension);
        preg_match("/data:(.*?);/",$image,$image_extension_completo);
        $cont = 1;
    }

    if ($image && in_array($fotoextension, $allowed_mimetypes_imagen)) {
        preg_match("/data:image\/(.*?);/",$image,$image_extension);
        preg_match("/data:(.*?);/",$image,$image_extension_completo);
        $cont = 2;
    }

        $datos['foto'] = "";
        $datos['fototam'] = 0.0;
        $datos['fototipo'] = "";
        $datos['fototipocom'] = "";

        $allowed_mimetypes = array('zip', 'png', 'jpeg', 'jpg', 'pdf', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        if ($fotonew && $image && in_array($image_extension[1], $allowed_mimetypes)){

            if($cont == 1) $image = preg_replace("/data:application\/(.*?);base64,/",'',$image);

            if($cont == 2) $image = preg_replace("/data:image\/(.*?);base64,/",'',$image);

            $image = str_replace(' ', '+', $image);

            if($image_extension[1]=='vnd.openxmlformats-officedocument.spreadsheetml.sheet')$image_extension[1] = 'xlsx';

            $imageName = "{$carpeta}_image_" .date('Ymd_Gis'). '.' . $image_extension[1];
            Storage::disk("{$carpeta}")->put("{$imageName}", base64_decode($image));

            $datos['foto'] = $imageName;
            $datos['fototam'] = round(floatval((strlen(base64_decode($image)))/1024), 4);
            $datos['fototipo'] = $image_extension[1];
            $datos['fototipocom'] = $image_extension_completo[1];
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom']
        ];
    }


    function imagePutUsuario ($img, $fotonew, $fotoextension, $carpeta) {
        // dd($img);
        $image = $img;
        $image_extension = "";
        $image_extension_completo = "";
        $archivo_extension = '';
        $cont = 0;

        $allowed_mimetypes_excel_pdf = array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/pdf', 'application/zip');

        $allowed_mimetypes_imagen = array('image/png', 'image/jpeg', 'image/jpg');

        if ($image && in_array($fotoextension, $allowed_mimetypes_excel_pdf)) {
            preg_match("/data:application\/(.*?);/",$image,$image_extension);
            preg_match("/data:(.*?);/",$image,$image_extension_completo);
            $cont = 1;
        }

        if ($image && in_array($fotoextension, $allowed_mimetypes_imagen)) {
            preg_match("/data:image\/(.*?);/",$image,$image_extension);
            preg_match("/data:(.*?);/",$image,$image_extension_completo);
            $cont = 2;
        }

        $datos['foto'] = "";
        $datos['fototam'] = 0.0;
        $datos['fototipo'] = "";
        $datos['fototipocom'] = "";

        $allowed_mimetypes = array('zip', 'png', 'jpeg', 'jpg', 'pdf', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        if ($fotonew && $image && in_array($image_extension[1], $allowed_mimetypes)){

            if($cont == 1) $image = preg_replace("/data:application\/(.*?);base64,/",'',$image);

            if($cont == 2) $image = preg_replace("/data:image\/(.*?);base64,/",'',$image);

            $image = str_replace(' ', '+', $image);

            if($image_extension[1]=='vnd.openxmlformats-officedocument.spreadsheetml.sheet')$image_extension[1] = 'xlsx';

            $imageName = "{$carpeta}_image_" .date('Ymd_Gis'). '.' . $image_extension[1];


            $imagen = Image::make(base64_decode($image));
            $imagen->resize(600, 600);

            $imagen->encode('jpeg', 70);

            Storage::disk("{$carpeta}")->put("{$imageName}", ($imagen));

            $datos['foto'] = $imageName;
            $datos['fototam'] = round(floatval((strlen(base64_decode($imagen)))/1024), 4);
            $datos['fototipo'] = 'jpeg';
            $datos['fototipocom'] = 'image/jpeg';
//            $datos['foto'] = $imageName;
//            $datos['fototam'] = round(floatval((strlen(base64_decode($image)))/1024), 4);
//            $datos['fototipo'] = $image_extension[1];
//            $datos['fototipocom'] = $image_extension_completo[1];
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom']
        ];
    }

    function random_string($length) {
        $key = '';
        $keys = array_merge(range(0, 9), range('a', 'z'));

        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[array_rand($keys)];
        }

        return $key;
    }

    function menu_permisos($permiso) {
        dd(in_array($permiso, ['gerente']));
        $Cliente = [
            'id' => "cliente",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.sidebar.cliente",
            'to' => "/app/menu-cliente",
            'permiso' => in_array($permiso, ['gerente', 'administrador'])
        ];

        $Personal = [
            'id' => "personal",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.sidebar.personal",
            'to' => "/app/menu-personal",
            'permiso' => in_array($permiso, ['gerente', 'administrador'])
        ];

        $Servicios = [
            'id' => "servicios",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.sidebar.servicios",
            'to' => "/app/menu-servicios",
            'permiso' => in_array($permiso, ['gerente', 'administrador'])
        ];

        $Historial = [
            'id' => "historial",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.sidebar.historial",
            'to' => "/app/menu-historial",
            'permiso' => in_array($permiso, ['gerente', 'administrador'])
        ];

        $Reportes = [
            'id' => "reportes",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.sidebar.reportes",
            'to' => "/app/menu-reportes",
            'permiso' => in_array($permiso, ['gerente', 'administrador'])
        ];

        $Estadistica = [
            'id' => "estadistica",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.sidebar.estadistica",
            'to' => "/app/menu-estadistica",
            'permiso' => in_array($permiso, ['gerente', 'administrador'])
        ];

        $main_menu = [
            'Cliente' => $Cliente,
            'Personal' => $Personal,
            'Servicios' => $Servicios,
            'Historial' => $Historial,
            'Estadistica' => $Estadistica,
            'Reportes' => $Reportes,
        ];

        $key = '';

        return $key;
    }

}


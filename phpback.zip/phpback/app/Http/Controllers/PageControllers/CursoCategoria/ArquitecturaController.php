<?php

namespace App\Http\Controllers\PageControllers\CursoCategoria;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ArquitecturaController extends Controller
{
    public function index()
    {
        return view('components.body.cursocategoria.arquitectura');
    }
}
<?php

namespace App\Http\Controllers\PageControllers\CursoCategoria;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SanitariaController extends Controller
{
    public function index()
    {
        return view('components.body.cursocategoria.sanitaria');
    }
}
<?php

namespace App\Http\Controllers\PageControllers\CursoCategoria;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CursosdetalleController extends Controller
{
    public function index()
    {
        return view('components.body.cursocategoria.cursosdetalle');
    }
}
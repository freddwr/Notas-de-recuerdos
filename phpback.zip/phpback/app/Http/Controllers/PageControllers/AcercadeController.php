<?php

namespace App\Http\Controllers\PageControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AcercadeController extends Controller
{
    public function index()
    {
        return view('components.body.acercade');
    }
}

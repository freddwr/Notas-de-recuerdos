<?php

namespace App\Http\Controllers\PageControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Docente;

class EfectosController extends Controller
{
    public function index()
    {

        ///////////////////MANERAS PARA RETORNAR ID DESPUES DE LA INSERCION///////////////////////////
        // 1

        // $docente = new Docente; 
        // $docente->nombre = 'new docente'; 
        // $docente->save();
        // $idr = $docente->id;
        // dd($idr);

        // 2
        // $id = \DB::table('docente')->insertGetId(
        //     ['nombre' => 'doc con trigger']
        // );

        // $updates = \DB::table('docente')
        //     ->where('id', '=', '4')
        //     ->update([
        //         'nombre' => 'update docente triger 3'
        //     ]);

        // dd($updates);


        $docente = Docente::get();
        // return $this->sendResponse($persona->toArray(), 'Products retrieved successfully.');
        return view('components.body.efectos', ['docente'=> $docente]);
    }
}

<?php

namespace App\Http\Controllers\PageControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LibrosController extends Controller
{
    public function index()
    {
        return view('components.body.libros');
    }
}

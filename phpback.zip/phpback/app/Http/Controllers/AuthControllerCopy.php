<?php

namespace App\Http\Controllers;

use App\Mail\CorreoMail;
use Mail;
use Illuminate\Http\Request;

// use JWTAuth;
use App\Models\User;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Facades\JWTFactory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthControllerCopy extends Controller
{
    public $loginAfterSignUp = true;
    private $tablaUsers = 'users';
    private $tablaRoles = 'roles';

    public function __construct() {
        $this->middleware('auth:api', ['except' => ['login', 'register', 'refresh', 'logoutuser', 'fogotpassword']]);
    }

//    public function changeActive($id, $activo){
//        $usuario = User::find($id);
//        $usuario->activo = $activo;
//        $usuario->save();
//    }

    public function fogotpassword (Request $request){
//         dd($request);
        $validator = Validator::make($request->all(), [
            'email' => 'required|min:3|max:50',
        ]);

        if ($validator->fails()) : return $this->sendErrorFuse('', "{$this->data_require}1"); endif;
        $correo = $request->email;
        $user = User::where('correo', $correo)
                    ->select(
                        'id',
                        'correo',
                        'nombre',
                        'paterno',
                        'materno'
                    )
                    ->first();
        if (!$user) : return $this->sendErrorFuse('', "{$this->data_require}, cuenta inexistente"); endif;
//        dd($user);
//
        $password = $this->random_string(8);
//
        $usuario = User::find($user->id);
        $usuario->pass_view = $password;
        $usuario->password = Hash::make($password);
        $usuario->activo = false;
        $usuario->save();
//
        $datosNav = [
            'navegador' => $request->server->get('HTTP_SEC_CH_UA'),
            'ip' => $request->server->get('REMOTE_ADDR'),
            'tiempo' => $request->server->get('REQUEST_TIME')
        ];

//        Mail::to("")->send(new CorreoMail($password, $usuario, $datosNav, ""));

        Mail::to("$usuario->correo")->send(new CorreoMail($password, $usuario, $datosNav, "$usuario->correo"));

        return $this->sendResponseFuse('', 'revisa tu email para ver tu nueva contrasenia', 200);

    }

    public function login (Request $request){
        // dd($request);
        $validator = Validator::make($request->all(), [
            'email' => 'required|min:3|max:50',
            'password' => 'required|string|min:6|max:20',
        ]);

        if ($validator->fails()) : return $this->sendErrorFuse('', "{$this->data_require}1"); endif;

        $correo = $request->email;
        $user = User::where('correo', $correo)
                    ->select(
                        'id',
                        'password',
//                        'foto',
                        'nick',
                        'id_roles',
//                        'estado_permiso',
                    )
                    ->first();
        if (!$user) : return $this->sendErrorFuse('', "{$this->data_require}, cuenta inexistente"); endif;


        $password = $request->password;
        $nick = $user->nick;
        $uuid = $user->id;
        $token = null;

        if (!Hash::check($password, $user->password)) : return $this->sendErrorFuse('', "{$this->data_require}, verificar"); endif;
//        if (!($user->estado_permiso)) : return $this->sendErrorFuse('', "Usuario no activado, pongase en contacto con el gerente"); endif;

        $rol = null;
        $rol = DB::table("{$this->tablaRoles}")->where(['id' => $user->id_roles])->first();


        $payload = JWTFactory::sub($request->id)
            // ->myCustomString('Foo Bar')
            // ->myCustomArray(['Apples', 'Oranges', 'fredd'])
            ->datoPersonal([
                'usuario_rol' => $rol->nombre,
                'usuario_rol_id' => $rol->id,
                // 'user' => $uuid
                ])
            ->datoUser($user)
            ->make();

        if (!$token = JWTAuth::attempt(['nick'=>$nick, 'password'=>$password, 'correo'=>$correo], $payload)) : return $this->sendErrorFuse('', "{$this->data_require}, verificar!!!"); endif;

//        $this->changeActive($uuid, true);

        return $this->sendResponseToken(
            $user->id,
            $user->nick,
            $correo,
            $token,
            $rol->nombre,
            "{$this->success_login_message}",
            $user->foto
        );

    }

    public function register(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'id' => 'required',
                'nombre' => 'required|max:50',
                'paterno' => 'required|max:50',
                'materno' => 'required|max:50',
                'celular' => 'required|unique:users|max:50',
                'password' => 'required|string|min:6|max:20',
                'correo' => 'required|unique:users|string|min:6|max:50',
            ]);

            if ($validator->fails()) : return $this->sendError401('', "{$this->data_require}"); endif;
            $users = new User();
            $users->id = $request->id;
            $users->nombre = $request->nombre;
            $users->paterno = $request->paterno;
            $users->materno = $request->materno;
            $users->celular = $request->celular;
            $users->correo = $request->correo;
            $users->pass_view = $request->password;
            $users->password = Hash::make($request->password);
//            $users->activo = false;
            $users->id_roles = '9a84da48-fcd9-4f7c-8948-01dd707224b9';
            $users->save();

            return $this->sendResponse('Registrado', "Registrado. {$users->nombre} {$users->paterno} {$users->materno} ponte en contacto con el gerente para ser habilitado", 200);
        }catch(JWTException $exeption){
            return response()->json([
            'status'=>false,
            'message'=>$exeption
            ]);
        }
    }
//
//    public function register(Request $request){
//        $validator = Validator::make($request->all(), [
//            'id' => 'required',
//            'nick' => 'required|unique:users|max:50',
//            'password' => 'required|string|min:6|max:20',
//            'email' => 'required|string|min:4|max:50',
//        ]);
//        // dd($request);
//
//        if ($validator->fails()) : return $this->sendError401('', "{$this->data_require}"); endif;
//        $users = new User();
//        $users->id = $request->id;
//        $users->nick = $request->nick;
//        $users->pass_view = $request->password;
//        $users->correo = $request->email;
//        $users->password = Hash::make($request->password);
//        $users->activo = true;
//        $users->id_roles = '9a84da48-fcd9-4f7c-8948-01dd707224b9';
//        $users->save();
//
//        $payload = JWTFactory::sub($request->id)
//            // ->myCustomString('Foo Bar')
//            // ->myCustomArray(['Apples', 'Oranges', 'fredd'])
//            ->datoPersonal([
//                'usuario_rol' => 'Agente inmobiliario',
//                'usuario_rol_id' => $request->id
//                ])
//            ->datoUser($request)
//            ->make();
//
//        if (!$token = JWTAuth::attempt(['nick'=>$request->nick, 'password'=>$request->password, 'correo'=>$request->email], $payload)) : return $this->sendErrorFuse('', 'Error'); endif;
//
//        return $this->sendResponseToken(
//            $request->id,
//            $request->nick,
//            $request->email,
//            $token,
//            'Agente inmobiliario',
//            "{$this->success_register_message}",
//            null
//        );
//    }

    // public function logout(Reques $request){
    public function logout(){
        $id = auth()->user()->id;

        try{

            $estado = User::find($id);
//            $estado->activo = false;
            $estado->save();

            JWTAuth::invalidate(JWTAuth::getToken());

            return response()->json([
                'status'=>true,
                'message'=>'user logout'
            ]);
        }catch(JWTException $exeption){
            return response()->json([
                'status'=>false,
                'message'=>'no logout'
            ]);
        }
        // $this->validate($request, [
        //     'token' => 'required'
        // ]);

        // try {
        //     JWTAuth::invalidate($request->token);
        //     return  response()->json([
        //         'status' => 'ok',
        //         'message' => 'Cierre de sesión exitoso.'
        //     ]);
        // } catch (JWTException  $exception) {
        //     return  response()->json([
        //         'status' => 'unknown_error',
        //         'message' => 'Al usuario no se le pudo cerrar la sesión.'
        //     ], 500);
        // }
    }


    public function logoutuser(Request $request){
        // dd($request);
        $response = [
            'success' => true,
            'message' => 'logout user',
        ];
        return response()->json($response, $code);
    }

    public function refresh() {
        try{
            $token = JWTAuth::getToken();
            $refreshed = JWTAuth::refresh($token);
            $user = JWTAuth::setToken($refreshed)->toUser();

            $id = auth()->user()->id;

            $user = DB::table("users")->where(['id' => $id])->first();

            $payload = JWTFactory::sub($user->id)
                // ->myCustomString('Foo Bar')
                // ->myCustomArray(['Apples', 'Oranges', 'fredd'])
                ->datoPersonal([
//                    'usuario_rol' => $rol->nombre,
//                    'usuario_rol_id' => $rol->id,
                    // 'user' => $uuid
                ])
                ->datoUser($user)
                ->make();

            $password = $user->pass_view;
            $correo = $user->correo;
            $nick = $user->nick;
            $token = null;

            if (!$token = JWTAuth::attempt(['nick'=>$nick, 'password'=>$password, 'correo'=>$correo], $payload)) : return $this->sendErrorFuse('', "{$this->data_require}, verificar!!!"); endif;


            return response()->json([
                'access_token' => $token,
            ])
            ->header('Cache-Control', 'no-cache, no-store, must-revalidate');;

        }catch(JWTException $exeption){
            return response()->json([
                'error'=>$exeption,
                'status'=>true,
                'message'=>'no login refresh token'
            ], 403);
        }
    }

    public function userProfile() {
        return response()->json(auth()->user());
    }

    // protected function createNewToken($token, $user){
    //     $refreshed = JWTAuth::refresh(JWTAuth::getToken());
    //     $user = JWTAuth::setToken($refreshed)->toUser();
    //     $request->headers->set('Authorization','Bearer '.$refreshed);

    //     return response()->json([
    //         'access_token' => $refreshed,
    //     ]);
    // }

    // protected function updateUserPass(Request $request, $user){
    protected function updateUserPass(Request $request){
        // $Id = $user;
        // dd($request);
        $Id = auth()->user()->id;
        $rowAffect = 0;

        try {
            $persona = User::where('id', $Id)
            ->select(
                'password',
            )
            ->first();
            $password = $request->password_old;
            $token = null;

            if (!Hash::check($password, $persona->password)) : return $this->sendErrorFuse('password incorrecto', ['error'=>'invalido'], 400); endif;

            $users = User::find($Id);
            $users->pass_view = $request->password_new;
            $users->password = Hash::make($request->password_new);
            $users->save();

            $this->sendResponseFuse('', 'contrasenia actualizada', 200);

        } catch (\Exception $e) {
            return $this->sendErrorFuse('error', ['error'=> $e->getMessage()], 400);
        }

    }

    protected function updateUser(Request $request, $user){
        $Id = auth()->user()->id;;
        $rowAffect = 0;
        $datos = $request->json()->all();

        [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutUsuario($request->foto, $request->fotonew, $request->fotoextension, 'users');

        if($request->fotonew){
            $this->deleteFile('users', $Id, 'foto');

            $datos['foto'] = $foto;
            $datos['fototam'] = $fototam;
            $datos['fototipo'] = $fototipo;
            $datos['fototipocom'] = $fototipocom;
        }else{
            unset(
                $datos['foto'],
                $datos['fototam'],
                $datos['fototipo'],
                $datos['fototipocom']
            );
        }

        unset($datos['fotonew']);
        unset($datos['fotoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                $rowAffect = DB::table('users')->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            $user = User::where('id', $Id)->first();
        } catch (\Exception $e) {
            return $this->sendErrorFuse('error', ['error'=> $e->getMessage()], 401);
        }

        $token = JWTAuth::getToken();

        $rol = null;
        $rol = DB::table("{$this->tablaRoles}")->where(['id' => $user->id_roles])->first();

        // $rol = null;
        // switch ($user->rol) {
        //     case 'admin':
        //         $rol = "admin";
        //         break;
        //     case 'user':
        //         $rol = "user";
        //         break;
        //     case 'estudiante_tobyc':
        //         $rol = "estudiante_tobyc";
        //         break;

        //     default:
        //         $rol = "estudiante_tobyc";
        //         break;
        // }

        return $this->sendResponseToken(
            $user->id,
            $user->nick,
            $user->correo,
            $token,
            $rol->nombre,
            "{$this->success_update_message}",
            $user->foto
        );
    }

    protected function accessToken(Request $request){
        $id = auth()->user()->id;
        $id_persona = auth()->user()->id_persona;
        $id_anterior = auth()->user()->id_anterior;
        $nick = auth()->user()->nick;
        $correo = auth()->user()->correo;
        $rolview = auth()->user()->id_roles;
        $foto = auth()->user()->foto;
        $token_access = JWTAuth::getToken();
        $token = "{$token_access}";
        // $user = User::select('id', 'password', 'nick', 'activo', 'rol', 'id_persona')->where('nick', $nick)->first();
        // $password = $request->password;
        // $token = null;

        // if (!$token = JWTAuth::attempt(['nick'=>$nick, 'password'=>$password])) : return $this->sendErrorFuse('nick o password no valido', ['error'=>'invalido'], 401); endif;


        $rol = null;
        $rol = DB::table("{$this->tablaRoles}")->where(['id' => $rolview])->first();

//        $this->changeActive($id, true);

        return $this->sendResponseToken(
            $id,
            $nick,
            $correo,
            $token,
            $rol->nombre,
            'logeado exitosamente',
            $foto
        );

        // try {

        //     if (!$user = JWTAuth::parseToken()->authenticate()) {
        //         return response()->json(['user_not_found'], 404);
        //     }
        //     $token = JWTAuth::getToken();
        //     dd(JWTAuth::getPayload($token)->toArray());
        // } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
        //         return response()->json(['token_expired'], $e->getStatusCode());
        // } catch (Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
        //         return response()->json(['token_invalid'], $e->getStatusCode());
        // } catch (Tymon\JWTAuth\Exceptions\JWTException $e) {
        //         return response()->json(['token_absent'], $e->getStatusCode());
        // }
        // return response()->json(compact('user'));
    }


    protected function sendResponseToken($id, $nick, $correo, $token, $rol, $message, $image){
        $lastSessionId = [
            'user'      => [
                'uuid'      => $id,
                // // 'from'      => 'custom-db',
                // // 'password'  => "admin",
                'role'      => $rol,
                'data'      => [
                    'displayName'   => $nick,
                    'displayCorreo'   => $correo,
                    'photoURL'      => $image ? $image:'',
                    // 'email'         => 'admin',
                    // 'settings'      => [
                    //     'layout'        => [
                    //         'style'     => 'layout1',
                    //         'config'    => [
                    //             'scroll'    => 'content',
                    //             'navbar'    => [
                    //                 'display'   => true,
                    //                 'folded'    => true,
                    //                 'position'  => 'left'
                    //             ],
                    //             'toolbar'   => [
                    //                 'display'   => true,
                    //                 'style'     => 'fixed',
                    //                 'position'  => 'below'
                    //             ],
                    //             'footer'    => [
                    //                 'display'   => true,
                    //                 'style'     => 'fixed',
                    //                 'position'  => 'below'
                    //             ],
                    //             'mode'      => 'fullwidth'
                    //         ]
                    //     ],
                    //     'customScrollbars'  => true,
                    //     'theme'             => [
                    //         'main'      => 'tteeNbe',
                    //         'navbar'    => 'tteeNbe',
                    //         'toolbar'   => 'tteeNbe',
                    //         'footer'    => 'tteeNbe'
                    //     ]
                    // ],
                    // 'shortcuts'     => [
                    //     'calendar',
                    //     'mail',
                    //     'contacts'
                    // ]
                ]
            ],
            'access_token' => $token
        ];
        // dd($lastSessionId);
        // return $this->createNewToken($token, $user);
        return $this->sendResponseFuse($lastSessionId, $message);
    }


}

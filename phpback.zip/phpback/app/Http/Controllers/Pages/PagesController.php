<?php

namespace App\Http\Controllers\Pages;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Admin\ResController as Ctrl;

use Intervention\Image\ImageManagerStatic as Image;


use Illuminate\Support\Facades\File;


use GDText\Box;
use GDText\Color;

class PagesController extends Ctrl
{
    private $tablaInmueble = 'inmueble';
    private $tablaProyecto = 'proyecto';
    private $tabla_imagen = 'imagen';

    public function indexInmueble ($id_proyecto){

        $id = $id_proyecto;
        try {
            $inmuebleDatos = DB::table("{$this->tablaInmueble}")->where('id', $id)->first();

            $imagenes = DB::table($this->tabla_imagen)
                ->where([
                    "{$this->tabla_imagen}.id_inmueble"=>$id,
                ])
                ->get();
            $imgFiles = array();
            foreach ($imagenes as $key => $val) {
                $val = str_replace("public/","",$val->fotocmda);
                array_push($imgFiles, $val);
            }

//            $collection = ['id'=> $id, 'id_int'=>$inmuebleDatos->id_int, 'nombre_publicacion'=>$inmuebleDatos->nombre_publicacion, 'inmuebles' => $inmuebleDatos, 'imagenes' => $imagenes];

//            return $this->sendResponse200($collection, "{$this->success_get_one_message}");

            return view('app', ['inmueble' => $inmuebleDatos, 'imagenes' => $imgFiles]);

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function indexProyecto ($id_proyecto){

        $id = $id_proyecto;
        try {
            $pryectoDatos = DB::table("{$this->tablaProyecto}")->where('id', $id)->first();

            $imagenes = DB::table("{$this->tabla_imagen}_proyecto")
                ->where([
                    "{$this->tabla_imagen}_proyecto.id_proyecto"=>$id,
                ])
                ->get();
            $imgFiles = array();
            foreach ($imagenes as $key => $val) {
                $val = str_replace("public/","",$val->fotocmda);
                array_push($imgFiles, $val);
            }

//            $collection = ['id'=> $id, 'id_int'=>$inmuebleDatos->id_int, 'nombre_publicacion'=>$inmuebleDatos->nombre_publicacion, 'inmuebles' => $inmuebleDatos, 'imagenes' => $imagenes];

//            return $this->sendResponse200($collection, "{$this->success_get_one_message}");

            return view('appproyecto', ['proyecto' => $pryectoDatos, 'imagenes' => $imgFiles]);

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    function downloadFile($file_name){
        $file = Storage::disk("imagen_cmda")->get($file_name);
        dd($file);
        return (new Response($file, 200))
            ->header('Content-Type', 'image/jpeg');
    }

}

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Intervention\Image\ImageManagerStatic as Image;

use GDText\Box;
use GDText\Color;

class ResController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public $success_get_message = "Datos obtenido";
    public $success_get_one_message = "Dato obtenido";
    public $success_register_message = "Registrado exitosamente";
    public $success_update_message = "Actualizado exitosamente";
    public $success_update_one_message = "Actualizado exitosamente un registro";
    public $success_delete_message = "Eliminado exitosamente";

    public $data_require = "Datos requeridos";

    public function getImagenesCertificado($Datos, $tabla, $value)
    {

        $is1FondoImageExist = Storage::exists("files/{$tabla}/{$Datos->fondo}");
        $is2ArribaImageExist = Storage::exists("files/{$tabla}/{$Datos->img_arriba}");
        $is3AbajoIzqImageExist = Storage::exists("files/{$tabla}/{$Datos->img_abajo_izq}");
        $is4AbajoDerImageExist = Storage::exists("files/{$tabla}/{$Datos->img_abajo_der}");
        $is5TituloImageExist = Storage::exists("files/{$tabla}/{$Datos->img_titulo}");
        $is6SelloImageExist = Storage::exists("files/{$tabla}/{$Datos->img_sello}");
        $is7SelloDirecImageExist = Storage::exists("files/{$tabla}/{$Datos->img_sello_direc}");
        $is8FirmaDirecImageExist = Storage::exists("files/{$tabla}/{$Datos->img_firma_direc}");

        $fechaInicio = $value && $value['fechaInicio'] ? Carbon::parse($value['fechaInicio'])->format('d-m-Y') : "00-00-0000";
        $fechaFin = $value && $value['fechaFin'] ? Carbon::parse($value['fechaFin'])->format('d-m-Y') : "00-00-0000";

        $arrayCertificado = [
            [
                'is' => $is1FondoImageExist && $Datos->fondo,
                'tipo' => 'image',
                'nombre' => 'fondo',
                'image' => $Datos->fondo,
                'scaleX' => 0.9494949494949494,
                'scaleY' => 0.9494949494949494,
                'left' => 753.0000000000001,
                'top' => 583.0628817860096,
                // 'width' => 1584,
                // 'height' => 1224,
            ],
            [
                'is' => $is2ArribaImageExist && $Datos->img_arriba,
                'tipo' => 'image',
                'nombre' => 'img_arriba',
                'image' => $Datos->img_arriba,
                'scaleX' => 1.0763619282580061,
                'scaleY' => 1.0763619282580061,
                'left' => 854.1937544102228,
                'top' => 148.78621654456717,
            ],
            [
                'is' => $is3AbajoIzqImageExist && $Datos->img_abajo_izq,
                'tipo' => 'image',
                'nombre' => 'img_abajo_izq',
                'image' => $Datos->img_abajo_izq,
                'scaleX' => 0.7499999999999996,
                'scaleY' => 0.7499999999999996,
                'left' => 209.13198235729521,
                'top' => 941.3279595522852,
            ],
            [
                'is' => $is4AbajoDerImageExist && $Datos->img_abajo_der,
                'tipo' => 'image',
                'nombre' => 'img_abajo_der',
                'image' => $Datos->img_abajo_der,
                'scaleX' => 0.6996199714937372,
                'scaleY' => 0.6996199714937372,
                'left' => 1312.3059766560427,
                'top' => 930.1539652535378,
            ],
            [
                'is' => $is5TituloImageExist && $Datos->img_titulo,
                'tipo' => 'image',
                'nombre' => 'img_titulo',
                'image' => $Datos->img_titulo,
                'scaleX' => 1.4554502598673351,
                'scaleY' => 1.4554502598673351,
                'left' => 779.5153747444809,
                'top' => 568.6166076128143,
                // 'width' => 563,
                // 'height' => 150,
            ],
            [
                'is' => $is6SelloImageExist && $Datos->img_sello,
                'tipo' => 'image',
                'nombre' => 'img_sello',
                'image' => $Datos->img_sello,
                'scaleX' => 0.5563000726130247,
                'scaleY' => 0.5563000726130247,
                'left' => 275.14199687990003,
                'top' => 913.3379740748901,
            ],
            [
                'is' => $is7SelloDirecImageExist && $Datos->img_sello_direc,
                'tipo' => 'image',
                'nombre' => 'img_sello_direc',
                'image' => $Datos->img_sello_direc,
                'scaleX' => 0.47255007261302434,
                'scaleY' => 0.47255007261302434,
                'left' => 784.7720041412026,
                'top' => 1018.2079668135876,
            ],
            [
                'is' => $is8FirmaDirecImageExist && $Datos->img_firma_direc,
                'tipo' => 'image',
                'nombre' => 'img_firma_direc',
                'image' => $Datos->img_firma_direc,
                'scaleX' => 0.5900400580904197,
                'scaleY' => 0.5900400580904197,
                'left' => 793.8919968799,
                'top' => 952.0879740748901,
            ],
            [
                'is' => true,
                'tipo' => 'texto',
                'nombre' => 'text_1',
                // 'image' => $Datos->img_firma_direc,
                'contenido' => 'Confiere el presente:',
                'width' => 1000,
                'fontSize' => 50,
                'textAlign' => 'left',
                'fontWeight' => 'normal',
                'splitByGrapheme' => true,
                'left' => 94.30048081810855,
                'top' => 190.32795955228517,
                'scaleX' => 0.5101017972323952,
                'scaleY' => 0.5101017972323952,
                'dynamicMinWidth' => 26.66,
                'zoomX' => 0.51010180,
                'zoomY' => 0.51010180,
            ],
            [
                'is' => true,
                'tipo' => 'texto',
                'nombre' => 'text_2',
                // 'image' => $Datos->img_firma_direc,
                'contenido' => 'CERTIFICADO DE PARTICIPACION',
                'width' => 1043.8680176427047,
                'fontSize' => 65,
                'textAlign' => 'center',
                'fontWeight' => 'bold',
                'splitByGrapheme' => true,
                'left' => 298.1319823572953,
                'top' => 244.32795955228522,
                'scaleX' => 0.8974572393697291,
                'scaleY' => 0.8974572393697291,
                'dynamicMinWidth' => 43.95,
                'zoomX' => 0.897457,
                'zoomY' => 0.897457,
            ],
            [
                'is' => true,
                'tipo' => 'texto',
                'nombre' => 'text_3',
                // 'image' => $Datos->img_firma_direc,
                'contenido' => 'Al Señor(a):',
                'width' => 292.469891684562,
                'fontSize' => 50,
                'textAlign' => 'left',
                'fontWeight' => 'normal',
                'splitByGrapheme' => true,
                'left' => 94.30048081810855,
                'top' => 303.32795955228517,
                'scaleX' => 0.5101017972323952,
                'scaleY' => 0.5101017972323952,
                'dynamicMinWidth' => 28.93,
                'zoomX' => 0.51010180,
                'zoomY' => 0.51010180,
            ],
            [
                'is' => true,
                'tipo' => 'texto',
                'nombre' => 'text_4',
                // 'image' => $Datos->img_firma_direc,
                'contenido' => $value && $value['nombre_completo'] ? strtoupper("{$value['nombre_completo']}") : 'ING. PEPITO PEPINO PEREZ DE LA TORRE',
                'width' => 1017.3611984429939,
                'fontSize' => 40,
                'textAlign' => 'center',
                'fontWeight' => 'bold',
                'splitByGrapheme' => true,
                'left' => 146.02818888329512,
                'top' => 335.32795955228517,
                'scaleX' => 1.1766762243415518,
                'scaleY' => 1.1766762243415518,
                'dynamicMinWidth' => 27.050,
                'zoomX' => 1.177676,
                'zoomY' => 1.177676,
            ],
            [
                'is' => true,
                'tipo' => 'texto',
                'nombre' => 'text_5',
                // 'image' => $Datos->img_firma_direc,
                'contenido' => 'Por cumplir satisfactoriamente y haber participado en el curso de:',
                'width' => 1716.2125461506748,
                'fontSize' => 50,
                'textAlign' => 'left',
                'fontWeight' => 'normal',
                'splitByGrapheme' => true,
                'left' => 94.30048081810855,
                'top' => 441.32795955228517,
                'scaleX' => 0.5101017972323952,
                'scaleY' => 0.5101017972323952,
                'dynamicMinWidth' => 39.94,
                'zoomX' => 0.51010180,
                'zoomY' => 0.51010180,
            ],
            [
                'is' => true,
                'tipo' => 'texto',
                'nombre' => 'text_6',
                // 'image' => $Datos->img_firma_direc,
                'contenido' => $value ? "Curso realizado del {$fechaInicio} al {$fechaFin}, con una intensidad de {$value['cargaHoraria']} horas académicas prácticas. Reconociendo su excelente participación y compromiso." : "Curso realizado del 10-10-2020 al 20-20-2020, con una intensidad de 00 horas académicas prácticas. Reconociendo su excelente participación y compromiso.",
                'width' => 2360.031179289164,
                'fontSize' => 50,
                'textAlign' => 'left',
                'fontWeight' => 'normal',
                'splitByGrapheme' => true,
                'left' => 94.30048081810855,
                'top' => 719.3279595522852,
                'scaleX' => 0.5101017972323952,
                'scaleY' => 0.5101017972323952,
                'dynamicMinWidth' => 39.94,
                'zoomX' => 0.51010180,
                'zoomY' => 0.51010180,
            ],
        ];

        return $arrayCertificado;
    }

    public function sendResponse200($result, $message)
    {
        $response = [
            'success' => true,
            'data'    => $result,
            'message' => $message,
        ];

        return response()->json($response, 200);
    }

    public function sendResponse200False($message)
    {
        $response = [
            'success' => false,
            'data'    => [],
            'message' => $message,
        ];

        return response()->json($response, 200);
    }

    public function sendError($error, $errorMessages = [], $code = 404)
    {
        $response = [
            'success' => false,
            'message' => $error,
        ];

        if (!empty($errorMessages)) {
            $response['data'] = $errorMessages;
        }

        return response()->json($response, $code);
    }

    //no autorizado
    public function sendError405($error, $message)
    {
        $response = [
            'success' => false,
            'message' => $message,
        ];

        if (!empty($error)) : $response['data'] = $error;
        endif;

        return response()->json($response, 405);
    }

    //error en el servidor
    public function sendError500($error, $message)
    {
        $response = [
            'success' => false,
            'message' => $message,
        ];

        if (!empty($error)) : $response['data'] = $error;
        endif;

        return response()->json($response, 500);
    }

    function iniciales($str)
    {
        $ret = '';
        foreach (explode(' ', $str) as $word) {
            $ret .= $word[0];
        }
        $d = mt_rand(1000, 9999);
        $ret = $ret . strval($d);
        return $ret;
    }

    function imagePutFileArchivo($img, $fotonew, $fotoextension, $carpeta, $nombre)
    {
        //            dd($img);
        $image = $img;
        $image_extension = "";
        $image_extension_completo = "";
        $archivo_extension = '';
        $cont = 0;

        $allowed_mimetypes_excel_pdf = array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/pdf', 'application/zip', 'application/x-zip-compressed');

        $allowed_mimetypes_imagen = array('image/png', 'image/jpeg', 'image/jpg');

        if ($image && in_array($fotoextension, $allowed_mimetypes_excel_pdf)) {
            preg_match("/data:application\/(.*?);/", $image, $image_extension);
            preg_match("/data:(.*?);/", $image, $image_extension_completo);
            $cont = 1;
        }

        if ($image && in_array($fotoextension, $allowed_mimetypes_imagen)) {
            preg_match("/data:image\/(.*?);/", $image, $image_extension);
            preg_match("/data:(.*?);/", $image, $image_extension_completo);
            $cont = 2;
        }

        $datos['foto'] = "";
        $datos['fototam'] = 0.0;
        $datos['fototipo'] = "";
        $datos['fototipocom'] = "";

        $allowed_mimetypes = array('x-zip-compressed', 'zip', 'png', 'jpeg', 'jpg', 'pdf', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'vnd.openxmlformats-officedocument.wordprocessingml.document');

        if ($fotonew && $image && in_array($image_extension[1], $allowed_mimetypes)) {

            if ($cont == 1) $image = preg_replace("/data:application\/(.*?);base64,/", '', $image);

            if ($cont == 2) $image = preg_replace("/data:image\/(.*?);base64,/", '', $image);

            $image = str_replace(' ', '+', $image);

            if ($image_extension[1] == 'vnd.openxmlformats-officedocument.spreadsheetml.sheet') $image_extension[1] = 'xlsx';
            if ($image_extension[1] == 'vnd.openxmlformats-officedocument.wordprocessingml.document') $image_extension[1] = 'docx';
            if ($image_extension[1] == 'x-zip-compressed') $image_extension[1] = 'zip';

            $imageName = "$nombre" . date('Ymd_Gis') . '.' . $image_extension[1];
            Storage::disk("{$carpeta}")->put("{$imageName}", base64_decode($image));

            $datos['foto'] = $imageName;
            $datos['fototam'] = round(floatval((strlen(base64_decode($image))) / 1024), 4);
            $datos['fototipo'] = $image_extension[1];
            $datos['fototipocom'] = $image_extension_completo[1];
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom']
        ];
    }

    function imageConvertSave($img, $carpeta, $index)
    {
        $image = $img;
        $datos['foto'] = '';
        $uploaded = [];

        if ($image) {
            //            $imagen = Image::make(base64_decode($image));
            //            $imagen->resize(1200, 1200);
            //            $imagen->encode('jpeg', 70);
            //
            //            $imageName = "{$carpeta}_archivo_" .date('Ymd_Gis') . "_{$index}" . '.jpeg';
            //            $uploaded[] = Storage::disk("{$carpeta}")->put("{$imageName}", ($imagen));
            //            $datos['foto'] = $imageName;

            $imageName = "{$carpeta}_archivo_" . date('Ymd_Gis') . "_{$index}" . '.jpeg';
            $uploaded[] = Storage::disk("{$carpeta}")->put("{$imageName}", base64_decode($image));
            $datos['foto'] = $imageName;
        }

        return [
            $datos['foto'],
        ];
    }

    function imageConvert($img, $message, $carpeta)
    {
        $image = $img;
        $datos['foto'] = '';
        $datos['fototam'] = 0;
        $datos['fototipo'] = 'jpeg';
        $datos['fototipocom'] = 'image/jpeg';

        if ($image) {
            $data = explode(',', $image, 2);
            $image_convert = '';

            $img = imagecreatefromstring(base64_decode($data[1]));
            $logo = imagecreatefrompng('assets/logo.png');
            $img_data = getimagesizefromstring(base64_decode($data[1]));

            $this->newImage = imagecreatetruecolor(1200, 1200);
            imagecopyresized($this->newImage, $img, 0, 0, 0, 0, 1200, 1200, $img_data[0], $img_data[1]);

            $color_elegido = ImageColorAllocate($this->newImage, 255, 255, 255);

            // $sx = imagesx($logo);
            // $sy = imagesy($logo);
            // $margen_dcho = 2;
            // $margen_inf = 2;

            $color3 = ImageColorAllocateAlpha($this->newImage, 0, 0, 0, 30);
            ImageFilledRectangle($this->newImage, 0, 1000, 1200, 1200, $color3);

            $box = new Box($this->newImage);
            $box->setFontFace('assets/verdana.ttf');
            $box->setFontSize(24);
            $box->setFontColor(new Color(255, 255, 255));
            $box->setTextShadow(new Color(0, 0, 0, 50), 0, 5);
            $box->setBox(20, 20, 980, 1160);
            $box->setTextAlign('left', 'bottom');
            $box->draw("{$message}");

            imagecopyresampled($this->newImage, $logo, 1000, 1000, 35, 0, 200, 300, 400, 600);

            ob_start();
            imagejpeg($this->newImage, null, 66);
            $final_image = ob_get_contents();
            // ob_end_clean();
            $image_convert = base64_encode(ob_get_clean());
            $imageName = "{$carpeta}_archivo_cmda_" . date('Ymd_Gis') . '.jpeg';
            Storage::disk("{$carpeta}_cmda")->put("{$imageName}", base64_decode($image_convert));

            preg_replace("/data:image\/(.*?);base64,/", '', $image);
            $image = str_replace(' ', '+', $image);

            $datos['foto'] = $imageName;
            $datos['fototam'] = round(floatval((strlen(base64_decode($image))) / 1024), 4);;
            $datos['fototipo'] = 'jpeg';
            $datos['fototipocom'] = 'image/jpeg';
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom'],
        ];
    }







    function imageConvertConDatosReset($img, $carpeta)
    {
        $image = $img;
        $datos['foto'] = '';
        $datos['fototam'] = 0;
        $datos['fototipo'] = 'jpeg';
        $datos['fototipocom'] = 'image/jpeg';

        if ($image) {
            $data = explode(',', $image, 2);
            //            $image_convert = '';
            //
            //            $img = imagecreatefromstring(base64_decode($data[1]));
            //            $img_data = getimagesizefromstring(base64_decode($data[1]));
            //
            //            $this->newImage = imagecreatetruecolor(1200, 1200);
            //            imagecopyresized($this->newImage, $img, 0, 0, 0, 0, 1200, 1200, $img_data[0], $img_data[1]);
            //
            //            ob_start();
            //            imagejpeg($this->newImage, null, 66);
            //            $final_image = ob_get_contents();
            //            $image_convert = base64_encode(ob_get_clean());
            //
            //            preg_replace("/data:image\/(.*?);base64,/",'',$image);
            //            $image = str_replace(' ', '+', $image);
            $img = Image::make(base64_decode($data[1]));
            $img->resize(1200, 1200);
            $img->encode('jpeg', 70);
            $image_convert = base64_encode($img);

            $datos['foto'] = $image_convert;
            $datos['fototam'] = round(floatval((strlen(base64_decode($image))) / 1024), 4);
            $datos['fototipo'] = 'jpeg';
            $datos['fototipocom'] = 'image/jpeg';

            $img->destroy();
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom'],
        ];
    }


    function imagePutHeaders($img, $fotonew, $fotoextension, $carpeta)
    {
        // dd($img);
        $image = $img;
        $image_extension = "";
        $image_extension_completo = "";
        $archivo_extension = '';


        $datos['foto'] = "";
        $datos['fototam'] = 0.0;
        $datos['fototipo'] = "";
        $datos['fototipocom'] = "";


        if ($fotonew && $image) {
            $data = explode(',', $image, 2);
            $imagen = Image::make(base64_decode($data[1]));
            $imagen->resize(1894, 362);

            $imagen->encode('jpeg', 70);


            $imageName = "{$carpeta}_archivo_" . date('Ymd_Gis') . '.jpeg';

            Storage::disk("{$carpeta}")->put("{$imageName}", ($imagen));

            $datos['foto'] = $imageName;
            $datos['fototam'] = round(floatval((strlen(base64_decode($imagen))) / 1024), 4);
            $datos['fototipo'] = 'jpeg';
            $datos['fototipocom'] = 'image/jpeg';

            $imagen->destroy();
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom']
        ];
    }


    function deleteFileCmda($tabla, $value, $campo, $inmueble, $index)
    {
        try {

            Storage::disk("{$tabla}_cmda")->delete("{$value->fotocmda}");
            $file = Storage::disk("imagen")->get("{$value->foto}");

            $imagen64 = base64_encode($file);
            $img64 = "data:image/jpeg;base64,{$imagen64}";

            [$fotocmda, $fotocmdatam, $fotocmdatipo, $fotocmdatipocom] = $this->imageConvertConDatos2($img64, $inmueble, $tabla, $value);


            [$foto] = $this->imageConvertSave($fotocmda, "{$tabla}_cmda", $index);

            DB::table("{$tabla}")
                ->where('id', $value->id)
                ->update([
                    "${campo}cmda" => $foto,
                    "${campo}cmdatam" => $fotocmdatam,
                    "${campo}cmdatipo" => $fotocmdatipo,
                    "${campo}cmdatipocom" => $fotocmdatipocom,
                ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    function deleteFile($tabla, $id,  $campo)
    {
        try {

            $delete = DB::table("{$tabla}")
                ->where('id', $id)
                ->first();

            Storage::disk("{$tabla}")->delete("{$delete->$campo}");

            DB::table("{$tabla}")
                ->where('id', $id)
                ->update([
                    "${campo}" => '',
                    "${campo}tipo" => '',
                    "${campo}tam" => 0,
                ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    function deleteFileServicio($tabla, $id,  $campo)
    {
        try {

            $delete = DB::table("{$tabla}")
                ->where('id', $id)
                ->first();

            Storage::disk("servicio")->delete("{$delete->$campo}");
            DB::table("{$tabla}")->where('id', $id)->delete();

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }



    function textUppercase($palabra)
    {

        $datos['palabra'] = "";

        if (strlen($palabra) > 0) {
            $datos['palabra'] = strtoupper($palabra);
        }

        return [
            $datos['palabra']
        ];
    }

    function v4()
    {
        $data = openssl_random_pseudo_bytes(16, $secure);
        if (false === $data) {
            return false;
        }
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    function random_string($length)
    {
        $key = '';
        $keys = array_merge(range(0, 9), range('a', 'z'));

        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[array_rand($keys)];
        }

        return $key;
    }
}
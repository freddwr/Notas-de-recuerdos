<?php

namespace App\Http\Controllers\Admin\DB\Webinar\Webinar;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Webinar\Webinar\Others;

class QueryPublicWebinarController extends Others
{

    public function __construct()
    {
    }

    public function publicGetWebinarHome()
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_public_web_home)
                ->where(['estado' => true])
                ->orderBy('id', 'desc')
                ->limit(5)
                ->get();

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                // $Docente = DB::table("{$this->tabla_estudiante_docente}")
                //     ->select(...$this->selectTablaEstudianteADocenteWeb)
                //     ->selectRaw($this->nombre_completo_tabla_estudiante)
                //     ->where(['id' => $value->id_docente])
                //     ->first();
                // $tipoModalidad = $this->getTipoModalidad($value->tipo);

                $imageExist = Storage::exists("files/{$this->tabla}/{$value->foto}");

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_webinar_foto_envio}" => $imageExist ? $value->foto : null,
                    "{$this->tabla_webinar_envio}" => $value,
                    'loading' => false,
                    // "{$this->tabla_estudiante_docente_envio}" => $Docente,
                    // "{$this->tabla_tipo_envio}" => $tipoModalidad,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function publicGetWebinarWebinar()
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_public_web_home)
                ->where(['estado' => true])
                ->orderBy('id', 'desc')
                ->limit(6)
                ->get();

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                // $Docente = DB::table("{$this->tabla_estudiante_docente}")
                //     ->select(...$this->selectTablaEstudianteADocenteWeb)
                //     ->selectRaw($this->nombre_completo_tabla_estudiante)
                //     ->where(['id' => $value->id_docente])
                //     ->first();
                // $tipoModalidad = $this->getTipoModalidad($value->tipo);

                $imageExist = Storage::exists("files/{$this->tabla}/{$value->foto}");

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_webinar_foto_envio}" => $imageExist ? $value->foto : null,
                    "{$this->tabla_webinar_envio}" => $value,
                    'loading' => false,
                    // "{$this->tabla_estudiante_docente_envio}" => $Docente,
                    // "{$this->tabla_tipo_envio}" => $tipoModalidad,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function publicGetWebinarDetalle($webinarid)
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_public_web_home)
                ->where(['id' => $webinarid])
                ->first();

            $collection = [];
            // $Docente = DB::table("{$this->tabla_estudiante_docente}")
            //     ->select(...$this->selectTablaEstudianteADocenteWeb)
            //     ->selectRaw($this->nombre_completo_tabla_estudiante)
            //     ->where(['id' => $Datos->id_docente])
            //     ->first();
            // $tipoModalidad = $this->getTipoModalidad($Datos->tipo);

            $imageExist = Storage::exists("files/{$this->tabla}/{$Datos->foto}");

            $collection = [
                'id' => $Datos->id,
                "{$this->tabla_webinar_foto_envio}" => $imageExist ? $Datos->foto : null,
                "{$this->tabla_webinar_envio}" => $Datos,
                'loading' => false,
                // "{$this->tabla_estudiante_docente_envio}" => $Docente,
                // "{$this->tabla_tipo_envio}" => $tipoModalidad,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
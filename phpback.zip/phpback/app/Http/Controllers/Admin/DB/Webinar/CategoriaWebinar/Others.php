<?php

namespace App\Http\Controllers\Admin\DB\Webinar\CategoriaWebinar;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'categoria_webinar';
    public $tabla_webinar_envio = 'categoria_webinar';

    public $select = [
        'id',
        'nombre'
    ];
}
<?php

namespace App\Http\Controllers\Admin\DB\Webinar\CategoriaWebinar;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

use App\Http\Controllers\Admin\DB\Webinar\CategoriaWebinar\Others;

class CategoriaWebinarController extends Others
{

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            // 'index',
            // 'edit',
            // 'store',
            // 'update',
            // 'destroy',
        ]]);
    }

    public function index()
    {
        try {

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->orderBy('id', 'desc')
                ->get();

            // $collection = collect([]);
            // foreach ($Datos as $key => $value) {
            //     $collection->push([
            //         'id' => $value->id,
            //         "{$this->tabla_webinar_envio}" => $value,
            //         'loading' => false
            //     ]);
            // }

            return $this->sendResponse200($Datos, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function store(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'id' => 'required|string|max:100',
        //     'nombre' => 'required|string|max:50',
        //     'genero' => 'string|max:6',
        // ]);
        // $datos = $request->json()->all();

        // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        // [$palabra] = $this->textUppercase($request->nombre);
        // $nombre = $palabra;

        // if ($request->fotonew) {
        //     [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutFileArchivo($request->foto, $request->fotonew, $request->fotoextension, "{$this->tabla_webinar}", "img_{$this->tabla_webinar}");

        //     $datos['foto'] = $foto;
        //     $datos['fototam'] = $fototam;
        //     $datos['fototipo'] = $fototipo;
        // } else {
        //     $datos['foto'] = null;
        //     $datos['fototam'] = null;
        //     $datos['fototipo'] = null;
        // }

        // unset($datos['fotonew']);
        // unset($datos['fotoextension']);
        // unset($datos['created']);
        // unset($datos['updated']);

        try {
            $clienteId = DB::table("{$this->tabla}")->insertGetId([
                // 'id' => "{$request->id}",
                'nombre' => "{$request->nombre}",
                // 'foto' => $datos['foto'],
                // 'fototam' => $datos['fototam'],
                // 'fototipo' => $datos['fototipo'],
            ]);

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id' => $clienteId])
                ->first();

            $collection = [
                'id' => $Datos->id,
                "{$this->tabla_webinar_envio}" => $Datos,
                'loading' => false
            ];

            return $this->sendResponse200($collection, "{$this->success_register_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function edit($cliente)
    {
        $id = $cliente;
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where('id', $id)
                ->first();

            $collection = [];

            $collection = [
                'id' => $id,
                "{$this->tabla_webinar_envio}" => $Datos,
                'loading' => false
            ];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function update(Request $request, $cliente)
    {

        $Id = $cliente;
        $datos = $request->json()->all();

        // if ($request->fotonew) {
        //     [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutFileArchivo($request->foto, $request->fotonew, $request->fotoextension, "{$this->tabla_webinar}", "img_{$this->tabla_webinar}");

        //     $this->deleteFile("{$this->tabla}", $Id, 'foto');

        //     $datos['foto'] = $foto;
        //     $datos['fototam'] = $fototam;
        //     $datos['fototipo'] = $fototipo;
        // } else {
        //     $datos['foto'] = null;
        //     $datos['fototam'] = null;
        //     $datos['fototipo'] = null;
        // }

        unset($datos['fototipocom']);
        unset($datos['fotonew']);
        unset($datos['fotoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id' => $Id])
                ->first();

            $collection = [];
            $collection = [
                'id' => $Id,
                "{$this->tabla_webinar_envio}" => $Datos,
                'loading' => false
            ];

            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function destroy($id)
    {

        try {
            $this->deleteFile($this->tabla, $id, 'foto');
            DB::table("{$this->tabla}")->where('id', $id)->delete();

            return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Webinar\Webinar;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Webinar\Webinar\Others;

class QueryOtherWebinarController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function other(Request $request)
    {
        try {
            $collection = collect([]);

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Webinar\QueAprenderasWebinar;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

class QueryQueAprenderasWebinarController extends Ctrl
{

    private $tabla = 'que_aprenderas_webinar';
    private $tabla_webinar = 'que_aprenderas_webinar';

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function searchInString($value, $searchText)
    {
        $textSplit =  explode(" ", $searchText);

        $searchDato = array_map(function ($dato) use ($value) {
            return str_contains(Str::lower(strval($value)), $dato);
        }, $textSplit);
        return in_array(true, $searchDato);
    }

    public function searchInObject($itemObj, $searchText)
    {
        $arrayObj = collect($itemObj);
        $arrayRes = $arrayObj->filter(function ($val) use ($searchText) {
            return ($this->searchInString($val, $searchText));
        });
        if (count($arrayRes) === 0) return false;
        return true;
    }

    public function search(Request $request)
    {
        try {
            $Datos = DB::table("{$this->tabla}")->orderByDesc('id')->get();
            $text = $request->get('text');

            $newDatos = collect($Datos)->filter(function ($value) use ($text) {
                return ($this->searchInObject($value, $text));
            });

            $collection = collect([]);
            foreach ($newDatos as $key => $value) {
                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_webinar}" => $value,
                    'loading' => false
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function cantidadRows()
    {
        try {

            $Datos = DB::table("{$this->tabla}")->count('id');
            $DatoUltimo = DB::table("{$this->tabla}")->select('id')->orderByDesc('id')->first();
            $DatosIDs = DB::select("SELECT id FROM {$this->tabla} ORDER BY id desc");

            $collection = [];
            if ($DatoUltimo)
                $collection = [
                    'cantidadFilas' => $Datos,
                    'ultimoId' => $DatoUltimo->id,
                    'listaIds' => $DatosIDs
                ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function listRowsBetween($perPage = 12, $currentPage = 0)
    {
        try {
            // $currentPage = LengthAwarePaginator::resolveCurrentPage('producto', 0);
            // dd($currentPage);
            $Datos = DB::table("{$this->tabla}")
                ->select(
                    'id',
                    'item',
                )
                ->orderBy('id', 'desc')
                ->offset($currentPage * $perPage)
                ->limit($perPage)
                ->get();

            // $currentPAgeSearchResult = $Datos->slice($currentPage * $perPage, $perPage);

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_webinar}" => $value,
                    'loading' => false
                ]);
            }

            // $paginatedTop = new LengthAwarePaginator($currentPAgeSearchResult, count($collection), $perPage);
            // dd($paginatedTop);

            // $Datos = DB::table("{$this->tabla}")
            //     ->select(
            //         'id',
            //         'titulo',
            //         'descripcion'
            //     )
            //     ->where([
            //         ['id', '>=', $last],
            //         ['id', '<=', $first]
            //     ])->orderBy('id', 'desc')->get();

            // $collection = collect([]);
            // foreach ($Datos as $key => $value) {
            //     $collection->push([
            //         'id' => $value->id,
            //         "{$this->tabla_webinar}" => $value,
            //         'loading' => false
            //     ]);
            // }
            // dd($collection);
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
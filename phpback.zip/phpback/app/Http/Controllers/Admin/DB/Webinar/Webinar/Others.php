<?php

namespace App\Http\Controllers\Admin\DB\Webinar\Webinar;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'webinar';
    public $tabla_webinar_envio = 'webinar';
    public $tabla_webinar_foto_envio = 'foto';

    public $tabla_categoria_webinar = 'categoria_webinar';
    public $tabla_categoria_webinar_envio = 'id_categoria_webinar';

    public $select = [
        'id',
        'nombre',
        'link_youtube',
        'hora_inicio',
        'hora_fin',
        'fecha',
        'estado',
        'foto',
        'id_categoria_webinar',
    ];

    public $selectCategoriaWebinar = [
        'id',
        'nombre',
    ];

    public $select_public_web_home = [
        'id',
        'nombre',
        'link_youtube',
        'hora_inicio',
        'hora_fin',
        'fecha',
        'estado',
        'foto',
    ];
}
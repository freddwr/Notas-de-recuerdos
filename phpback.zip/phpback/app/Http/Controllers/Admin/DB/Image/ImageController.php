<?php

namespace App\Http\Controllers\Admin\DB\Image;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;

class ImageController extends Ctrl
{

    private $tabla = 'imagen';

    public function __construct(){
        $this->middleware('jwt.verify', ['except' => [
            'index',
            'convert',
            'store',
            'update',
            'destroy',
            'imagendiez',

            'reloadImages'
        ]]);
    }

    public function index(){
        try {

            $imagens = DB::table("{$this->tabla}")->orderBy('id', 'desc')->get();
            return $this->sendResponse200($imagens->toArray(), "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function imagendiez(){
        try {

            $imagenesdiez = DB::table("vista_imagen_diez")->inRandomOrder()->take(10)->get();

            return $this->sendResponse200($imagenesdiez->toArray(), "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function convert(Request $request){

        try {

            [$foto, $fototam, $fototipo, $fototipocom] = $this->imageConvertConDatosReset($request->foto, $this->tabla);

            [$fotocmda, $fotocmdatam, $fotocmdatipo, $fotocmdatipocom] = $this->imageConvertConDatos($request->foto, $request->message, $this->tabla, $request);

            return $this->sendResponse200(['imagen' => [
                'id' => $request->id,
                'foto' => $foto,
                'fototam' => $fototam,
                'fototipo' => $fototipo,
                'fototipocom' => $fototipocom,
                'fotocmda' => $fotocmda,
                'fotocmdatam' => $fotocmdatam,
                'fotocmdatipo' => $fotocmdatipo,
                'fotocmdatipocom' => $fotocmdatipocom,
                'logo_blanco' => $request->logo_blanco,
                'logo_negro' => $request->logo_negro,
                'logo_superior_derecha' => $request->logo_superior_derecha,
                'logo_superior_izquierda' => $request->logo_superior_izquierda,
                'logo_inferior_derecha' => $request->logo_inferior_derecha,
                'logo_inferior_izquierda' => $request->logo_inferior_izquierda,
                'text_superior_derecha' => $request->text_superior_derecha,
                'text_superior_izquierda' => $request->text_superior_izquierda,
                'text_inferior_derecha' => $request->text_inferior_derecha,
                'text_inferior_izquierda' => $request->text_inferior_izquierda,
                'cinta_superior' => $request->cinta_superior,
                'cinta_inferior' => $request->cinta_inferior,
                'triangulo_superior_derecha' => $request->triangulo_superior_derecha,
                'triangulo_superior_izquierda' => $request->triangulo_superior_izquierda,
                'triangulo_inferior_derecha' => $request->triangulo_inferior_derecha,
                'triangulo_inferior_izquierda' => $request->triangulo_inferior_izquierda,
            ], 'formulario' => ''], "{$this->success_register_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }

    }

    public function store(Request $request){
        // $validator = Validator::make($request->all(), [
        //     'id' => 'required|string|max:100',
        //     'nombre' => 'required|string|max:100',
        // ]);

        // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutFileArchivo($request->foto, $request->fotonew, $request->fotoextension, $this->tabla, "imagen_");

        [$fotocmda, $fotocmdatam, $fotocmdatipo, $fotocmdatipocom] = $this->imageConvert($request->foto, $request->message, $this->tabla);

        try {
            $imagenId = DB::table("{$this->tabla}")->insertGetId([
                'id' => $request->id,
                'descripcion' => "{$request->descripcion}",
                'foto' => $foto,
                'fototam' => $fototam,
                'fototipo' => $fototipo,
                'fototipocom' => $fototipocom,
                'fotocmda' => $fotocmda,
                'fotocmdatam' => $fotocmdatam,
                'fotocmdatipo' => $fotocmdatipo,
                'fotocmdatipocom' => $fotocmdatipocom,
                'id_inmueble' => $request->id_inmueble,
            ]);

            return $this->sendResponse200(['local' => $imagenId, 'formulario' => $request], "{$this->success_register_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }

    }



    public function create(Request $request){}
    public function show(Request $request){}



    public function edit($imagen){
        $id = $imagen;
        try {
            $imagen = DB::table("{$this->tabla}")->where('id', $id)->first();

            return $this->sendResponse200($imagen, "{$this->success_get_one_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }

    }

    public function update(Request $request, $imagen){

        $Id = $imagen; //solo obtiene el parametro /imagen/{imagen}
        $rowAffect = 0;
        $datos = $request->json()->all();
        // $validator = Validator::make($datos, [
        //     'nombre' => 'required|string|max:50',
        //     'paterno' => 'required|string|max:50',
        //     'profesion' => 'required|max:50',
        //     'telefono' => 'required|max:50',
        //     'correo' => 'required|max:50',
        // ]);

        // if ($validator->fails()) : return $this->sendError405('', "$this->data_require"); endif;

        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                $rowAffect = DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            return $this->sendResponse200(['local' => $Id, 'formulario' => $request], "{$this->success_update_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }

    }

    public function destroy($id){

        // $this->deleteFile($this->tabla, $id, 'foto');
        try {

            DB::table("{$this->tabla}")->where('id', $id)->delete();

            return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }


    public function reloadImages($id_inmueble){
        try {
            $imagens = DB::table("{$this->tabla}")->where(['id_inmueble' => $id_inmueble])->get();
            $inmueble = DB::table("inmueble")->where(['id' => $id_inmueble])->first();
            $index = 0;
            foreach ($imagens as $key => $value) {
                $this->deleteFileCmda($this->tabla, $value, 'foto', $inmueble, $index);
                $index++;
            }


//            $inmuebleDatos = DB::table("inmueble")->where('id', $id_inmueble)->first();

            $imagenes = DB::table($this->tabla)
                ->where([
                    "{$this->tabla}.id_inmueble"=>$id_inmueble,
                ])
                ->get();

//            $collection = ['id'=> $id_inmueble, 'inmuebles' => $inmuebleDatos, 'imagenes' => $imagenes];

            return $this->sendResponse200($imagenes, "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }


    public function reloadImagesProyecto($id_proyecto){
        try {
            $imagens = DB::table("{$this->tabla}_proyecto")->where(['id_proyecto' => $id_proyecto])->get();
            $proyecto = DB::table("proyecto")->where(['id' => $id_proyecto])->first();
            $index = 0;
            foreach ($imagens as $key => $value) {
                $this->deleteFileCmdaProyecto("{$this->tabla}_proyecto", $value, 'foto', $proyecto, $index);
                $index++;
            }


//            $proyectoDatos = DB::table("proyecto")->where('id', $id_proyecto)->first();

            $imagenes = DB::table("{$this->tabla}_proyecto")
                ->where([
                    "{$this->tabla}_proyecto.id_proyecto"=>$id_proyecto,
                ])
                ->get();

//            $collection = ['id'=> $id_proyecto, 'proyectos' => $proyectoDatos, 'imagenes' => $imagenes];

            return $this->sendResponse200($imagenes, "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}

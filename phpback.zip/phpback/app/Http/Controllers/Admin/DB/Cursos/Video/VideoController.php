<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Video;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

use App\Http\Controllers\Admin\DB\Cursos\Video\Others;

class VideoController extends Others
{

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            // 'index',
            // 'edit',
            // 'store',
            // 'update',
            // 'destroy',
        ]]);
    }

    // public function index()
    // {
    //     try {

    //         $Datos = DB::table("{$this->tabla}")->orderBy('id', 'desc')->get();

    //         $collection = collect([]);
    //         foreach ($Datos as $key => $value) {
    //             $collection->push([
    //                 'id' => $value->id,
    //                 "{$this->tabla}" => $value,
    //                 'loading' => false
    //             ]);
    //         }

    //         return $this->sendResponse200($collection, "{$this->success_get_message}");
    //     } catch (\Exception $e) {
    //         return $this->sendError500($e->getMessage(), '');
    //     }
    // }

    public function store(Request $request)
    {
        // // $validator = Validator::make($request->all(), [
        // //     'id' => 'required|string|max:100',
        // //     'nombre' => 'required|string|max:50',
        // //     'genero' => 'string|max:6',
        // // ]);
        $datos = $request->json()->all();

        // // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        // // [$palabra] = $this->textUppercase($request->nombre);
        // // $nombre = $palabra;

        // if ($request->fondonew) {
        //     [$fondo, $fondotam, $fondotipo, $fondotipocom] = $this->imagePutFileArchivo($request->fondo, $request->fondonew, $request->fondoextension, "{$this->tabla}", "img_{$this->tabla}");

        //     $datos['fondo'] = $fondo;
        //     $datos['fondotam'] = $fondotam;
        //     $datos['fondotipo'] = $fondotipo;
        // } else {
        //     $datos['fondo'] = null;
        //     $datos['fondotam'] = null;
        //     $datos['fondotipo'] = null;
        // }

        // unset($datos['fondonew']);
        // unset($datos['fondoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            $datosId = DB::table("{$this->tabla}")->insertGetId([
                // 'id' => "{$request->id}",
                'titulo' => "{$datos['titulo']}",
                'posicion' => "{$datos['posicion']}",
                'enlace' => "{$datos['enlace']}",
                'id_curso' => $datos['id_curso'],
                // 'fondo' => $datos['fondo'],
                // 'fondotam' => $datos['fondotam'],
                // 'fondotipo' => $datos['fondotipo'],
            ]);

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id' => $datosId])
                ->first();

            return $this->sendResponse200($Datos, "{$this->success_register_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function edit($curso)
    {
        $id = $curso;
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where('id_curso', $id)
                ->get();

            $CursoDetails = DB::table("{$this->tabla_curso}")
                ->select(...$this->select_curso)
                ->where('id', $id)
                ->first();


            $collection = [];

            $collection = [
                'id' => $id,
                "{$this->tabla_envio}" => $Datos,
                "{$this->tabla_curso_envio}" => $CursoDetails,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function update(Request $request, $video)
    {

        $Id = $video;
        $datos = $request->json()->all();

        if ($request->fondonew) {
            [$fondo, $fondotam, $fondotipo, $fondotipocom] = $this->imagePutFileArchivo($request->fondo, $request->fondonew, $request->fondoextension, "{$this->tabla}", "img_{$this->tabla}");

            $this->deleteFile("{$this->tabla}", $Id, 'fondo');

            $datos['fondo'] = $fondo;
            $datos['fondotam'] = $fondotam;
            $datos['fondotipo'] = $fondotipo;
        } else {
            unset($datos['fondo']);
            unset($datos['fondotam']);
            unset($datos['fondotamtipo']);
        }

        unset($datos['fondotipocom']);
        unset($datos['fondonew']);
        unset($datos['fondoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id' => $Id])
                ->first();


            $collection = [];
            $collection = [
                'id' => $Id,
                "{$this->tabla_envio}" => $Datos,
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function destroy($id)
    {

        try {
            $this->deleteFile($this->tabla, $id, 'fondo');
            DB::table("{$this->tabla}")->where('id', $id)->delete();

            return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
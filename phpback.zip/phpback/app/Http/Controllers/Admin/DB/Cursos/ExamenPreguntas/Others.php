<?php

namespace App\Http\Controllers\Admin\DB\Cursos\ExamenPreguntas;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'preguntas';
    public $tabla_envio = 'preguntas';

    public $select = [
        'id',
        'pregunta',
    ];

    public $tabla_respuestas = 'respuestas';
    public $tabla_respuestas_envio = 'respuestas';

    public $select_respuestas = [
        'id',
        'respuesta',
        'respuesta_bool',
    ];
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\CategoriaCurso;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'categoria';
    public $tabla_envio = 'categoria_curso';

    public $select = [
        'id',
        'titulo',
        'descripcion',
    ];
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Inscripcion;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\Others;

class QueryOtherInscripcionController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function cursosCertificado64($campo, $certificado)
    {
        try {
            $collection = [];

            $Certificado = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_estudiante)
                ->where([
                    'id' => $certificado,
                ])
                ->first();

            $campoCertificado = "certificado_{$campo}";
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$Certificado->$campoCertificado}");
            $image = $imageExist ? Storage::get("files/{$this->tabla_certificado}/{$Certificado->$campoCertificado}") : '';

            $image64 = $imageExist ? base64_encode($image) : '';

            $collection = [
                "{$this->tabla_certificado_envio}" => "data:image/jpeg;base64,{$image64}",
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function cursosCertificadoEstudiante($estudiante)
    {
        try {

            $Cursos = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos_curso)
                ->where(['id_estudiante' => $estudiante])
                ->orderByDesc('id')
                ->get();

            $collection = collect([]);

            foreach ($Cursos as $key => $value) {
                $Certificado = DB::table("{$this->tabla_certificado}")
                    ->select(...$this->select_certificado_estudiante)
                    ->where([
                        'id_estudiante' => $value->id_estudiante,
                        'id_curso' => $value->id_curso,
                    ])
                    ->first();

                $imgCertificado = '';
                $campoCertificado = '';
                if ($value->habilitado_certificado_participacion) {
                    $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$Certificado->certificado_capacitacion}");
                    $imgCertificado = $imageExist ? $Certificado->certificado_capacitacion : '';
                    $campoCertificado = 'capacitacion';
                }
                if ($value->habilitado_certificado_aprobacion) {
                    $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$Certificado->certificado_aprobacion}");
                    $imgCertificado = $imageExist ? $Certificado->certificado_aprobacion : '';
                    $campoCertificado = 'aprobacion';
                }

                $collection->push([
                    'id' => $Certificado->id,
                    "{$this->tabla_certificado_envio}" => $imgCertificado,
                    "campo" => $campoCertificado,
                    'loading' => false,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ajustesAllUpdate(Request $request)
    {
        try {
            $datos = $request->json()->all();

            foreach (array_keys($datos) as $campo) {
                DB::table("{$this->tabla}")->where('id_curso', $datos['id_curso'])->update([
                    $campo => $datos[$campo],
                ]);
            }

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ajustesEstudianteAll()
    {
        try {

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ajustesEstudianteInscripcion($inscripcion)
    {
        try {

            $SettingsEstudiante = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id' => $inscripcion])
                ->first();

            $Examen = false;
            $IsCertificadoExisteParticipacion = false;
            $IsCertificadoExisteAprobacion = false;
            // $Examen = null;
            if ($SettingsEstudiante) {
                $AsignacionExamen = DB::table("{$this->tabla_asignacion_examen}")
                    ->select(...$this->select_asignacion_examen)
                    ->where(['id_curso' => $SettingsEstudiante->id_curso])
                    ->first();
                if ($AsignacionExamen) {
                    $Examen = true;
                    // $Examen = DB::table("{$this->tabla_examen}")
                    //     ->select(...$this->select_examen)
                    //     ->where(['id' => $AsignacionExamen->id_examen])
                    //     ->first();
                }
                $AsignacionCertificados = DB::table("{$this->tabla_curso}")
                    ->select(...$this->select_curso_certificados)
                    ->where(['id' => $SettingsEstudiante->id_curso])
                    ->first();
                if ($AsignacionCertificados->id_certificado_capacitacion_disenio) {
                    $IsCertificadoExisteParticipacion = true;
                }
                if ($AsignacionCertificados->id_certificado_aprobacion_disenio) {
                    $IsCertificadoExisteAprobacion = true;
                }
            }

            $collection = [
                "$this->tabla_curso_certificado_participacion"  => $IsCertificadoExisteParticipacion,
                "$this->tabla_curso_certificado_aprobacion"  => $IsCertificadoExisteAprobacion,
                "$this->tabla_examen_envio"  => $Examen,
                "$this->tabla_envio" => $SettingsEstudiante
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Video;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Video\Others;

class QuerySearchVideoController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function searchInString($value, $searchText)
    {
        $textSplit =  explode(" ", $searchText);

        $searchDato = array_map(function ($dato) use ($value) {
            return str_contains(Str::lower(strval($value)), $dato);
        }, $textSplit);
        return in_array(true, $searchDato);
    }

    public function searchInObject($itemObj, $searchText)
    {
        $arrayObj = collect($itemObj);
        $arrayRes = $arrayObj->filter(function ($val) use ($searchText) {
            return ($this->searchInString($val, $searchText));
        });
        if (count($arrayRes) === 0) return false;
        return true;
    }

    public function search(Request $request)
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->orderByDesc('id')
                ->get();
            $text = $request->get('text');

            $newDatos = collect($Datos)->filter(function ($value) use ($text) {
                return ($this->searchInObject($value, $text));
            });

            $collection = collect([]);
            foreach ($newDatos as $key => $value) {

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_envio}" => $value,
                    'loading' => false,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function cantidadRows()
    {
        try {

            $Datos = DB::table("{$this->tabla}")->count('id');
            $DatoUltimo = DB::table("{$this->tabla}")->select('id')->orderByDesc('id')->first();
            // $DatosIDs = DB::select("SELECT id FROM {$this->tabla} ORDER BY id desc");

            $collection = [
                'cantidadFilas' => $Datos,
                'ultimoId' => $DatoUltimo->id,
                // 'listaIds' => $DatosIDs
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function listRowsBetween($perPage = 50, $currentPage = 0, $curso)
    {
        try {
            // $currentPage = LengthAwarePaginator::resolveCurrentPage('producto', 0);
            // dd($currentPage);
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id_curso' => $curso])
                ->orderBy('id', 'desc')
                ->offset($currentPage * $perPage)
                ->limit($perPage)
                ->get();

            $CursoDetails = DB::table("{$this->tabla_curso}")
                ->select(...$this->select_curso)
                ->where('id', $curso)
                ->first();

            // $currentPAgeSearchResult = $Datos->slice($currentPage * $perPage, $perPage);

            $collection = [];
            $collection = [
                'id' => $curso,
                "{$this->tabla_envio}" => $Datos,
                "{$this->tabla_curso_envio}" => $CursoDetails,
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    /* LISTA DE VIDEO QUE PODRA VER EL ESTUDIANTE */

    public function listRowsBetweenEstudiante($perPage = 50, $currentPage = 0, $curso, $estudiante)
    {
        try {
            $Inscripcion = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos)
                ->where([
                    'id_estudiante' => $estudiante,
                    'id_curso' => $curso
                ])
                ->first();

            $posicion = null;
            $menorDiferente = '!=';

            if (!$Inscripcion->todos_videos) {
                $posicion = $Inscripcion->numero_clases;
                $menorDiferente = '<=';
            }

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where([
                    'id_curso' => $curso,
                    ['posicion', $menorDiferente, $posicion]
                ])
                ->orderBy('id', 'desc')
                ->offset($currentPage * $perPage)
                ->limit($perPage)
                ->get();

            $CursoDetails = DB::table("{$this->tabla_curso}")
                ->select(...$this->select_curso)
                ->where('id', $curso)
                ->first();

            $collection = [];
            $collection = [
                'id' => $curso,
                "{$this->tabla_envio}" => $Datos,
                "{$this->tabla_curso_envio}" => $CursoDetails,
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Inscripcion;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\Others;

class QuerySearchInscripcionController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function searchInString($value, $searchText)
    {
        $textSplit =  explode(" ", $searchText);

        $searchDato = array_map(function ($dato) use ($value) {
            return str_contains(Str::lower(strval($value)), $dato);
        }, $textSplit);
        return in_array(true, $searchDato);
    }

    public function searchInObject($itemObj, $searchText)
    {
        $arrayObj = collect($itemObj);
        $arrayRes = $arrayObj->filter(function ($val) use ($searchText) {
            return ($this->searchInString($val, $searchText));
        });
        if (count($arrayRes) === 0) return false;
        return true;
    }

    public function search(Request $request)
    {
        try {
            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos)
                ->orderByDesc('id')
                ->get();
            $text = $request->get('text');

            $newDatos = collect($Datos)->filter(function ($value) use ($text) {
                return ($this->searchInObject($value, $text));
            });

            $collection = collect([]);
            foreach ($newDatos as $key => $value) {

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_vista_incritos_envio}" => $value,
                    'loading' => false,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function cantidadRows($curso)
    {
        try {
            if (!$curso) return $this->sendError500('Error :( ', '');

            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->where([
                    'id_curso' => $curso
                ])
                ->count('id');
            $DatoUltimo = DB::table("{$this->tabla_vista_incritos}")
                ->select('id', 'id_curso')
                ->where([
                    'id_curso' => $curso
                ])
                ->orderByDesc('id')
                ->first();
            // $DatosIDs = DB::select("SELECT id FROM {$this->tabla} ORDER BY id desc");

            $collection = [
                'cantidadFilas' => $Datos,
                'ultimoId' => $DatoUltimo ? $DatoUltimo->id : 0,
                // 'listaIds' => $DatosIDs
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function listRowsBetween($perPage = 50, $currentPage = 0, $curso)
    {
        try {
            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos)
                ->where([
                    'id_curso' => $curso
                ])
                ->orderBy('id', 'desc')
                ->offset($currentPage * $perPage)
                ->limit($perPage)
                ->get();

            $collection = collect([]);
            foreach ($Datos as $key => $value) {

                $Certificado = DB::table("{$this->tabla_certificado}")
                    ->select(...$this->select_certificado)
                    ->where([
                        'id_curso' => $value->id_curso,
                        'id_estudiante' => $value->id_estudiante
                    ])
                    ->first();

                $Profesion = DB::table("{$this->tabla_profesion}")
                    ->select(...$this->select_profesion)
                    ->where([
                        'id' => $value->id_profesion,
                    ])
                    ->first();

                $Codigo_pais = DB::table("{$this->tabla_codigo_pais}")
                    ->select(...$this->select_codigo_pais)
                    ->where([
                        'id' => $value->id_codigo_pais,
                    ])
                    ->first();

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_vista_incritos_envio}" => $value,
                    "{$this->tabla_certificado_envio}" => $Certificado,
                    "{$this->tabla_profesion_envio}" => $Profesion,
                    "{$this->tabla_codigo_pais_envio}" => $Codigo_pais,
                    "{$this->tabla_nota_aprobado_envio}" => $value->nota && $value->nota > 80 ? true : false,
                    "{$this->tabla_inscritos_cifrado_ids_envio}" => [
                        'id_inscrito' => base64_encode($value->id),
                        // 'id_curso' => base64_encode($value->id_curso),
                        // 'id_estudiante' => base64_encode($value->id_estudiante),
                        'id_certificado' => base64_encode($Certificado->id),
                    ],
                    'loading' => false,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    /* ESTUDIANTE INSCRITO POR CURSO */

    public function cantidadRowsEstudiante($estudiante)
    {
        try {

            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->where([
                    'id_estudiante' => $estudiante
                ])
                ->count('id');
            $DatoUltimo = DB::table("{$this->tabla_vista_incritos}")
                ->select('id', 'id_estudiante')
                ->where([
                    'id_estudiante' => $estudiante
                ])->orderByDesc('id')->first();
            // $DatosIDs = DB::select("SELECT id FROM {$this->tabla} ORDER BY id desc");

            $collection = [
                'cantidadFilas' => $Datos,
                'ultimoId' => $DatoUltimo->id,
                // 'listaIds' => $DatosIDs
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function listRowsBetweenEstudiante($perPage = 50, $currentPage = 0, $estudiante)
    {
        try {
            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos_estudiante)
                ->where([
                    'id_estudiante' => $estudiante
                ])
                ->orderBy('id', 'desc')
                ->offset($currentPage * $perPage)
                ->limit($perPage)
                ->get();

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                // $CategoriaCursos = DB::table("{$this->tabla_categoria_cursos}")
                //     ->select(...$this->selectCategoriaCursos)
                //     ->where(['id' => $value->id_categoria])
                //     ->first();
                // $Docente = DB::table("{$this->tabla_estudiante_docente}")
                //     ->select(...$this->selectTablaEstudianteDocente)
                //     ->selectRaw($this->nombre_completo_tabla_estudiante)
                //     ->where(['id' => $value->id_docente])
                //     ->first();
                // $tipoModalidad = $this->getTipoModalidad($value->tipo);

                $Examen = false;
                $Tiempo = null;
                $AsignacionExamen = DB::table("{$this->tabla_asignacion_examen}")
                    ->select(...$this->select_asignacion_examen)
                    ->where(['id_curso' => $value->id])
                    ->first();
                if ($AsignacionExamen) {
                    $Examen = $value->habilitado_examen && true;
                    $ExamenTiempo = DB::table("{$this->tabla_examen}")
                        ->select(...$this->select_examen_tiempo)
                        ->where(['id' => $AsignacionExamen->id_examen])
                        ->first();
                    $Tiempo = $ExamenTiempo->tiempo ?? null;
                }

                // $Profesion = DB::table("{$this->tabla_profesion}")
                //     ->select(...$this->select_profesion)
                //     ->where([
                //         'id' => $value->id_profesion,
                //     ])
                //     ->first();

                // $Codigo_pais = DB::table("{$this->tabla_codigo_pais}")
                //     ->select(...$this->select_codigo_pais)
                //     ->where([
                //         'id' => $value->id_codigo_pais,
                //     ])
                //     ->first();

                $Certificado = DB::table("{$this->tabla_certificado}")
                    ->select(...$this->select_certificado)
                    ->where([
                        'id_curso' => $value->id,
                        'id_estudiante' => $value->id_estudiante
                    ])
                    ->first();

                $imageExist = Storage::exists("files/{$this->tabla_curso}/{$value->foto}");

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_certificado_envio}" => $Certificado,
                    "{$this->tabla_examen_envio}" => $Examen,
                    "{$this->tabla_examen_tiempo_envio}" => $Tiempo,
                    "{$this->tabla_cursos_envio}" => $value,
                    "{$this->tabla_nota_aprobado_envio}" => $value->nota && $value->nota > 80 ? true : false,
                    // "{$this->tabla_profesion_envio}" => $Profesion,
                    // "{$this->tabla_codigo_pais_envio}" => $Codigo_pais,
                    "foto" => $imageExist && $value->foto != '' ? $value->foto : null,
                    'loading' => false,
                    // "{$this->tabla_categoria_cursos_envio}" => $CategoriaCursos,
                    // "{$this->tabla_estudiante_docente_envio}" => $Docente,
                    // "{$this->tabla_tipo_envio}" => $tipoModalidad,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function searchEstudiante(Request $request, $estudiante)
    {
        try {
            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos_estudiante)
                ->where([
                    'id_estudiante' => $estudiante
                ])
                ->orderByDesc('id')
                ->get();
            $text = $request->get('text');

            $newDatos = collect($Datos)->filter(function ($value) use ($text) {
                return ($this->searchInObject($value, $text));
            });

            $collection = collect([]);
            foreach ($newDatos as $key => $value) {

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_cursos_envio}" => $value,
                    'loading' => false,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
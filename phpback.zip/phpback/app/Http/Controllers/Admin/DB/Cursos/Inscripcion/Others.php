<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Inscripcion;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla_vista_incritos = 'vista_inscritos_estudiante_curso';
    public $tabla_vista_incritos_envio = 'inscritos';
    public $tabla_nota_aprobado_envio = 'nota';
    public $tabla_inscritos_cifrado_ids_envio = 'ids_certificado';

    public $select_vista_incritos = [
        'id',
        'nombre_completo_estudiante',
        'telefono',
        'id_curso',
        'id_estudiante',
        'id_profesion',
        'id_codigo_pais',
        'nota',
    ];

    public $select_vista_incritos_curso = [
        'id',
        'id_curso',
        'id_estudiante',
        'habilitado_certificado_participacion',
        'habilitado_certificado_aprobacion',
    ];

    public $tabla = 'inscritos_curso';
    public $tabla_envio = 'inscripcion';

    public $select = [
        'id',
        'contador',
        'habilitado_examen',
        'id_curso',
        'id_examen',
        'examen_bool',
        'nota',
        'habilitado_certificado_participacion',
        'habilitado_certificado_aprobacion',
        'todos_videos',
        'numero_clases',
    ];

    public $tabla_asignacion_examen = 'asignacion_curso_examen';
    public $tabla_asignacion_examen_envio = 'asignacion_examen';

    public $select_asignacion_examen = [
        'id',
        'id_examen',
        'id_curso',
    ];

    public $tabla_certificado = 'certificado';
    public $tabla_certificado_envio = 'certificado';

    public $select_certificado = [
        'id',
        'certificado',
    ];

    public $select_certificado_estudiante = [
        'id',
        'id_curso',
        'id_estudiante',
        'certificado_capacitacion',
        'certificado_aprobacion',
    ];

    public $select_public_certificado = [
        'id',
        'id_curso',
        'id_estudiante',
        'certificado_capacitacion',
        'nombre',
        'paterno',
        'materno',
        'carga_horaria',
        'fecha_iniciocurso',
        'fecha_fincurso',
    ];

    public $select_public_certificado_aprobacion = [
        'id',
        'id_curso',
        'id_estudiante',
        'certificado_aprobacion',
        'nombre',
        'paterno',
        'materno',
        'carga_horaria',
        'fecha_iniciocurso',
        'fecha_fincurso',
    ];

    public $tabla_examen = 'examen';
    public $tabla_examen_envio = 'examen';
    public $tabla_examen_tiempo_envio = 'examen_tiempo';

    public $select_examen = [
        'id',
        'titulo',
    ];

    public $select_examen_tiempo = [
        'id',
        'tiempo',
    ];

    public $tabla_curso = 'curso';
    public $tabla_curso_envio = 'curso';

    public $select_curso = [
        'id',
        'nombre',
        'foto',
        'fecha_inicio',
        'fecha_fin',
    ];

    public $tabla_curso_certificado_participacion = 'is_certificado_participacion';
    public $tabla_curso_certificado_aprobacion = 'is_certificado_aprobacion';

    public $select_curso_certificados = [
        'id',
        'id_certificado_capacitacion_disenio',
        'id_certificado_aprobacion_disenio',
    ];

    /* SELECCIONA CURSOS INSCRITOS DE CADA ESTUDIANTE */
    public $tabla_cursos_envio = 'cursos';

    public $select_vista_incritos_estudiante = [
        'id_curso as id',
        'id_estudiante',
        'nombre_curso as nombre',
        'foto',
        'habilitado_examen',
        'id_examen',
        'id as inscripcion',
        'id_profesion',
        'id_codigo_pais',
        'nota',
        'habilitado_certificado_participacion',
        'habilitado_certificado_aprobacion',
    ];

    public $tabla_profesion = 'profesion';
    public $tabla_profesion_envio = 'profesion';

    public $select_profesion = [
        'id',
        'nombre',
        'sigla',
    ];

    public $tabla_codigo_pais = 'codigo_pais';
    public $tabla_codigo_pais_envio = 'codigo_pais';

    public $select_codigo_pais = [
        'id',
        'codigo',
        'pais',
    ];

    /* CERTIFICADO COMPROVACION ENVIO */

    public $tabla_estudiante = 'estudiante';
    public $tabla_estudiante_envio = 'estudiante';

    public $select_estudiante = [
        'id',
        'foto',
        'correo',
        'telefono',
    ];
}
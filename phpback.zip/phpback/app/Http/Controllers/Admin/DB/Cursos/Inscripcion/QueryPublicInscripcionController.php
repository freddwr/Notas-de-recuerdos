<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Inscripcion;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\Others;

class QueryPublicInscripcionController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function certificadoEstudianteComprobanteAprobacion($certificado)
    {
        try {
            $idInscrito64 = base64_decode($certificado);
            $idInscrito = intval($idInscrito64);

            $Datos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_public_certificado_aprobacion)
                ->where([
                    'id' => intval($idInscrito)
                ])
                ->first();

            if (!$Datos)
                return $this->sendResponse200(['inscritoEstudiante' => false], "{$this->success_get_message}");

            $Estudiante = DB::table("{$this->tabla_estudiante}")
                ->select(...$this->select_estudiante)
                ->where([
                    'id' => $Datos->id_estudiante
                ])
                ->first();

            $Curso = DB::table("{$this->tabla_curso}")
                ->select(...$this->select_curso)
                ->where([
                    'id' => $Datos->id_curso
                ])
                ->first();

            $collection = [];

            $imageExistCertificado = Storage::exists("files/{$this->tabla_certificado}/{$Datos->certificado_aprobacion}");
            $imageExistEstudiante = Storage::exists("files/{$this->tabla_estudiante}/{$Estudiante->foto}");

            $collection = [
                'inscritoEstudiante' => true,
                "certificado" => [
                    'telefono_estudiante' => "{$Estudiante->telefono}",
                    'correo_estudiante' => "{$Estudiante->correo}",
                    'nombre_completo' => "{$Datos->nombre} {$Datos->paterno} {$Datos->materno}",
                    'fecha_inicio' => "{$Datos->fecha_iniciocurso}",
                    'fecha_fin' => "{$Datos->fecha_fincurso}",
                    'carga_horaria' => "{$Datos->carga_horaria}",
                    'curso' => "{$Curso->nombre}",
                    'imagen_certificado' => $imageExistCertificado && $Datos->certificado_aprobacion != '' ? $Datos->certificado_aprobacion : null,
                    'imagen_estudiante' => $imageExistEstudiante && $Estudiante->foto != '' ? $Estudiante->foto : null,
                ],
                // "{$this->tabla_cursos_envio}" => $Curso,
                // "foto" => $imageExist && $Datos->certificado_aprobacion != '' ? $Datos->certificado_aprobacion : null,
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function certificadoEstudianteComprobanteParticipacion($certificado)
    {
        try {
            $idInscrito64 = base64_decode($certificado);
            $idInscrito = intval($idInscrito64);

            $Datos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_public_certificado)
                ->where([
                    'id' => intval($idInscrito)
                ])
                ->first();

            if (!$Datos)
                return $this->sendResponse200(['inscritoEstudiante' => false], "{$this->success_get_message}");

            $Estudiante = DB::table("{$this->tabla_estudiante}")
                ->select(...$this->select_estudiante)
                ->where([
                    'id' => $Datos->id_estudiante
                ])
                ->first();

            $Curso = DB::table("{$this->tabla_curso}")
                ->select(...$this->select_curso)
                ->where([
                    'id' => $Datos->id_curso
                ])
                ->first();

            $collection = [];

            $imageExistCertificado = Storage::exists("files/{$this->tabla_certificado}/{$Datos->certificado_capacitacion}");
            $imageExistEstudiante = Storage::exists("files/{$this->tabla_estudiante}/{$Estudiante->foto}");

            $collection = [
                'inscritoEstudiante' => true,
                "certificado" => [
                    'telefono_estudiante' => "{$Estudiante->telefono}",
                    'correo_estudiante' => "{$Estudiante->correo}",
                    'nombre_completo' => "{$Datos->nombre} {$Datos->paterno} {$Datos->materno}",
                    'fecha_inicio' => "{$Datos->fecha_iniciocurso}",
                    'fecha_fin' => "{$Datos->fecha_fincurso}",
                    'carga_horaria' => "{$Datos->carga_horaria}",
                    'curso' => "{$Curso->nombre}",
                    'imagen_certificado' => $imageExistCertificado && $Datos->certificado_capacitacion != '' ? $Datos->certificado_capacitacion : null,
                    'imagen_estudiante' => $imageExistEstudiante && $Estudiante->foto != '' ? $Estudiante->foto : null,
                ],
                // "{$this->tabla_cursos_envio}" => $Curso,
                // "foto" => $imageExist && $Datos->certificado_capacitacion != '' ? $Datos->certificado_capacitacion : null,
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
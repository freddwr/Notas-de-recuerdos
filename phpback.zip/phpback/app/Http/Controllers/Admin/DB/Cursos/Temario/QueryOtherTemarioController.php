<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Temario;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Temario\Others;

class QueryOtherTemarioController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function asignacionCursoTemario(Request $request)
    {
        try {
            $datos = $request->json()->all();

            DB::table("{$this->tabla_asignacion}")->insertGetId([
                // 'id' => "{$request->id}",
                'id_temario' => $datos['id_temario'],
                'id_curso' => $datos['id_curso'],
            ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function deleteAsignacionCursoTemario($asignacion)
    {
        try {

            DB::table("{$this->tabla_asignacion}")->where('id', $asignacion)->delete();

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }
}
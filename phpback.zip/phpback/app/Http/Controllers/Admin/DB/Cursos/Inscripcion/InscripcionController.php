<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Inscripcion;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;

use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\Others;

class InscripcionController extends Others
{

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            // 'index',
            // 'edit',
            // 'store',
            // 'update',
            // 'destroy',
        ]]);
    }

    // public function index()
    // {
    //     try {

    //         $Datos = DB::table("{$this->tabla}")->select(...$this->select)->orderBy('id', 'desc')->get();

    //         // $collection = collect([]);
    //         // foreach ($Datos as $key => $value) {
    //         //     $collection->push([
    //         //         'id' => $value->id,
    //         //         "{$this->tabla}" => $value,
    //         //         'loading' => false
    //         //     ]);
    //         // }

    //         return $this->sendResponse200($Datos, "{$this->success_get_message}");
    //     } catch (\Exception $e) {
    //         return $this->sendError500($e->getMessage(), '');
    //     }
    // }

    public function store(Request $request)
    {
        // // $validator = Validator::make($request->all(), [
        // //     'id' => 'required|string|max:100',
        // //     'nombre' => 'required|string|max:50',
        // //     'genero' => 'string|max:6',
        // // ]);
        $datos = $request->json()->all();

        // // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        // // [$palabra] = $this->textUppercase($request->nombre);
        // // $nombre = $palabra;

        // if ($request->fondonew) {
        //     [$fondo, $fondotam, $fondotipo, $fondotipocom] = $this->imagePutFileArchivo($request->fondo, $request->fondonew, $request->fondoextension, "{$this->tabla}", "img_{$this->tabla}");

        //     $datos['fondo'] = $fondo;
        //     $datos['fondotam'] = $fondotam;
        //     $datos['fondotipo'] = $fondotipo;
        // } else {
        //     $datos['fondo'] = null;
        //     $datos['fondotam'] = null;
        //     $datos['fondotipo'] = null;
        // }

        // unset($datos['fondonew']);
        // unset($datos['fondoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            $EstudianteExist = DB::table("{$this->tabla_vista_incritos}")
                ->where([
                    'id_estudiante' => $datos['id_estudiante'],
                    'id_curso' => $datos['id_curso']
                ])
                ->first();

            if ($EstudianteExist)
                return $this->sendResponse200False('Estudiante esta inscrito');

            $datosId = DB::table("{$this->tabla}")->insertGetId([
                // 'id' => "{$request->id}",
                'id_estudiante' => $datos['id_estudiante'],
                'id_curso' => $datos['id_curso'],
                // 'fondo' => $datos['fondo'],
                // 'fondotam' => $datos['fondotam'],
                // 'fondotipo' => $datos['fondotipo'],
            ]);

            $Datos = DB::table("{$this->tabla_vista_incritos}")
                ->select(...$this->select_vista_incritos)
                ->where(['id' => $datosId])
                ->first();


            $Certificado = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado)
                ->where([
                    'id_curso' => $Datos->id_curso,
                    'id_estudiante' => $Datos->id_estudiante
                ])
                ->first();

            $Profesion = DB::table("{$this->tabla_profesion}")
                ->select(...$this->select_profesion)
                ->where([
                    'id' => $Datos->id_profesion,
                ])
                ->first();

            $Codigo_pais = DB::table("{$this->tabla_codigo_pais}")
                ->select(...$this->select_codigo_pais)
                ->where([
                    'id' => $Datos->id_codigo_pais,
                ])
                ->first();

            $collection = [
                'id' => $Datos->id,
                "{$this->tabla_vista_incritos_envio}" => $Datos,
                "{$this->tabla_certificado_envio}" => $Certificado,
                "{$this->tabla_profesion_envio}" => $Profesion,
                "{$this->tabla_codigo_pais_envio}" => $Codigo_pais,
                "{$this->tabla_nota_aprobado_envio}" => $Datos->nota && $Datos->nota > 80 ? true : false,
                "{$this->tabla_inscritos_cifrado_ids_envio}" => [
                    'id_inscrito' => $Datos->id,
                    'id_curso' => $Datos->id_curso,
                    'id_estudiante' => $Datos->id_estudiante,
                ],
                'loading' => false,
            ];

            return $this->sendResponse200($collection, "{$this->success_register_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function edit($inscripcion)
    {
        $id = $inscripcion;
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where('id', $id)
                ->first();


            $collection = [];

            $collection = [
                'id' => $id,
                "{$this->tabla_envio}" => $Datos,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function update(Request $request, $inscripcion)
    {

        $Id = $inscripcion;
        $datos = $request->json()->all();

        // if ($request->fondonew) {
        //     [$fondo, $fondotam, $fondotipo, $fondotipocom] = $this->imagePutFileArchivo($request->fondo, $request->fondonew, $request->fondoextension, "{$this->tabla}", "img_{$this->tabla}");

        //     $this->deleteFile("{$this->tabla}", $Id, 'fondo');

        //     $datos['fondo'] = $fondo;
        //     $datos['fondotam'] = $fondotam;
        //     $datos['fondotipo'] = $fondotipo;
        // } else {
        //     unset($datos['fondo']);
        //     unset($datos['fondotam']);
        //     unset($datos['fondotamtipo']);
        // }

        // unset($datos['fondotipocom']);
        // unset($datos['fondonew']);
        // unset($datos['fondoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            // $Datos = DB::table("{$this->tabla}")
            //     ->select(...$this->select)
            //     ->where(['id' => $Id])
            //     ->first();


            $collection = [];
            // $collection = [
            //     'id' => $Id,
            //     "{$this->tabla_envio}" => $Datos,
            //     'loading' => false,
            // ];

            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function destroy($id)
    {

        try {
            // $this->deleteFile($this->tabla, $id, 'fondo');
            DB::table("{$this->tabla}")->where('id', $id)->delete();

            return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
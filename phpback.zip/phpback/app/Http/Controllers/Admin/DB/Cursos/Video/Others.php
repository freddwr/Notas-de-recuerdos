<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Video;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'video';
    public $tabla_envio = 'video';

    public $select = [
        'id',
        'titulo',
        'posicion',
        'enlace',
        'id_curso',
    ];

    public $tabla_curso = 'curso';
    public $tabla_curso_envio = 'curso';

    public $select_curso = [
        'id',
        'nombre',
        'fecha_inicio',
    ];

    /* SELECCIONAR  */
    public $tabla_vista_incritos = 'vista_inscritos_estudiante_curso';

    public $select_vista_incritos = [
        'id_curso',
        'id_estudiante',
        'todos_videos',
        'numero_clases',
    ];
}
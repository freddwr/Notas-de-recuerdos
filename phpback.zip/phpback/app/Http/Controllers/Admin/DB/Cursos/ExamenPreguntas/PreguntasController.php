<?php

namespace App\Http\Controllers\Admin\DB\Cursos\ExamenPreguntas;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

use App\Http\Controllers\Admin\DB\Cursos\ExamenPreguntas\Others;

class PreguntasController extends Others
{

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            // 'index',
            // 'edit',
            // 'store',
            // 'update',
            // 'destroy',
        ]]);
    }

    // public function index()
    // {
    //     try {

    //         $Datos = DB::table("{$this->tabla}")
    //             ->select(...$this->select)
    //             ->orderBy('id', 'desc')
    //             ->get();

    //         // $collection = collect([]);
    //         // foreach ($Datos as $key => $value) {
    //         //     $collection->push([
    //         //         'id' => $value->id,
    //         //         "{$this->tabla_envio}" => $value,
    //         //         'loading' => false
    //         //     ]);
    //         // }

    //         return $this->sendResponse200($Datos, "{$this->success_get_message}");
    //     } catch (\Exception $e) {
    //         return $this->sendError500($e->getMessage(), '');
    //     }
    // }

    public function store(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'id' => 'required|string|max:100',
        //     'nombre' => 'required|string|max:50',
        //     'genero' => 'string|max:6',
        // ]);
        $datos = $request->json()->all();

        // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        // [$palabra] = $this->textUppercase($request->nombre);
        // $nombre = $palabra;

        // if ($request->archivonew) {
        //     [$archivo, $archivotam, $archivotipo, $archivotipocom] = $this->imagePutFileArchivo($request->archivo, $request->archivonew, $request->archivoextension, "{$this->tabla}", "img_{$this->tabla}");

        //     $datos['archivo'] = $archivo;
        //     $datos['archivotam'] = $archivotam;
        //     $datos['archivotipo'] = $archivotipo;
        // } else {
        //     $datos['archivo'] = null;
        //     $datos['archivotam'] = null;
        //     $datos['archivotipo'] = null;
        // }

        // unset($datos['archivonew']);
        // unset($datos['archivoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            $datosId = DB::table("{$this->tabla}")->insertGetId([
                // 'id' => "{$request->id}",
                'pregunta' => "{$datos['pregunta']}",
                'id_examen' => "{$datos['id_examen']}",
            ]);


            $collection = [];
            $collectionRespuestas = collect([]);
            foreach ($datos['respuesta'] as $key => $value) {
                $respuestasId = DB::table("{$this->tabla_respuestas}")->insertGetId([
                    'respuesta' => "{$value['respuesta']}",
                    'respuesta_bool' => $value['respuesta_bool'],
                    'id_pregunta' => $datosId
                ]);

                $collectionRespuestas->push([
                    'id' => $respuestasId,
                    'respuesta' => "{$value['respuesta']}",
                    'respuesta_bool' => $value['respuesta_bool']
                ]);
            }

            $collection = [
                "id" => $datosId,
                "loading" => false,
                "{$this->tabla_envio}"  => [
                    'id' => $datosId,
                    'pregunta' => "{$datos['pregunta']}"
                ],
                "{$this->tabla_respuestas_envio}"  => $collectionRespuestas
            ];

            return $this->sendResponse200($collection, "{$this->success_register_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function edit($examen)
    {
        $id = $examen;
        // try {
        //     $Datos = DB::table("{$this->tabla}")
        //         ->select(...$this->select)
        //         ->where('id', $id)
        //         ->first();

        //     $Preguntas = DB::table("{$this->tabla_preguntas}")
        //         ->select(...$this->select_preguntas)
        //         ->where(['id_examen' => $Datos->id])
        //         ->get();

        //     $collectionPreguntas = collect([]);
        //     foreach ($Preguntas as $key => $value) {

        //         $Respuestas = DB::table("{$this->tabla_respuestas}")
        //             ->select(...$this->select_respuestas)
        //             ->where(['id_pregunta' => $value->id])
        //             ->get();

        //         $collectionPreguntas->push([
        //             'id' => $value->id,
        //             "{$this->tabla_preguntas_envio}" => $value,
        //             "{$this->tabla_respuestas_envio}" => $Respuestas,
        //             'loading' => false
        //         ]);
        //     }

        //     $collection = [
        //         'id' => $id,
        //         "{$this->tabla_envio}" => $Datos,
        //         "{$this->tabla_preguntas_envio}" => $collectionPreguntas,
        //         'loading' => false
        //     ];

        //     return $this->sendResponse200($collection, "{$this->success_get_message}");
        // } catch (\Exception $e) {
        //     return $this->sendError500($e->getMessage(), '');
        // }
    }

    public function update(Request $request, $examen)
    {

        $Id = $examen;
        $datos = $request->json()->all();

        // if ($request->archivonew) {
        //     [$archivo, $archivotam, $archivotipo, $archivotipocom] = $this->imagePutFileArchivo($request->archivo, $request->archivonew, $request->archivoextension, "{$this->tabla}", "img_{$this->tabla}");

        //     $this->deleteFile("{$this->tabla}", $Id, 'archivo');

        //     $datos['archivo'] = $archivo;
        //     $datos['archivotam'] = $archivotam;
        //     $datos['archivotipo'] = $archivotipo;
        // } else {
        //     // $datos['archivo'] = null;
        //     // $datos['archivotam'] = null;
        //     // $datos['archivotipo'] = null;
        //     unset($datos['archivo']);
        //     unset($datos['archivotam']);
        //     unset($datos['archivotipo']);
        // }

        // unset($datos['archivotipocom']);
        // unset($datos['archivonew']);
        // unset($datos['archivoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->where(['id' => $Id])
                ->first();

            $collection = [];
            $collection = [
                'id' => $Id,
                "{$this->tabla_envio}" => $Datos,
                'loading' => false
            ];

            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function destroy($id)
    {

        try {
            $this->deleteFile($this->tabla, $id, 'archivo');
            DB::table("{$this->tabla}")->where('id', $id)->delete();

            return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
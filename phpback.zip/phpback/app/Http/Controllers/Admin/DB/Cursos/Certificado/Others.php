<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Certificado;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'certificado_disenio';
    public $tabla_certificado_envio = 'certificado';
    public $tabla_certificado64_envio = 'certificado64';
    public $tabla_certificadoBase64_envio = 'certificadoBase64';

    public $select = [
        'id',
        'nombre_certificado_tipo',
        'fondo',
        'fondotam',
        'fondotipo',
    ];

    public $select_edit = [
        'id',
        'nombre_certificado_tipo',
        'fondo',
        'img_arriba',
        'img_abajo_izq',
        'img_abajo_der',
        'img_titulo',
        'img_sello',
        'img_sello_direc',
        'img_firma_direc',
    ];

    public $tabla_asignacion = 'curso';
    public $tabla_asignacion_envio = 'asignacion';

    public $select_asignacion = [
        'id',
        'id_certificado_capacitacion_disenio',
    ];

    public $tabla_certificado = 'certificado';

    public $select_certificado_capacitacion = [
        'id',
        'certificado_capacitacion',
        'profesion_abreviatura',
        'nombre',
        'paterno',
        'materno',
        'carga_horaria',
        'fecha_iniciocurso',
        'fecha_fincurso',
        'id_certificado_capacitacion_disenio',
        'id_curso',
        'id_estudiante',
    ];

    public $select_certificado_aprobacion_est = [
        'id',
        'certificado_aprobacion',
        'profesion_abreviatura',
        'nombre',
        'paterno',
        'materno',
        'carga_horaria',
        'fecha_iniciocurso',
        'fecha_fincurso',
        'id_certificado_aprobacion_disenio',
        'id_curso',
        'id_estudiante',
    ];

    public $select_certificado_capacitacion_estudiante = [
        'id',
        'certificado_capacitacion',
    ];

    public $select_certificado_aprobacion_estudiante = [
        'id',
        'certificado_aprobacion',
    ];

    public $select_certificado_aprobacion = [
        'id',
        'certificado_aprobacion',
        'certificado_aprobaciontam',
        'certificado_aprobaciontipo',
        'profesion_abreviatura',
        'nombre',
        'paterno',
        'materno',
        'carga_horaria',
        'fecha_iniciocurso',
        'fecha_fincurso',
        'id_certificado_capacitacion_disenio',
        'id_certificado_aprobacion_disenio',
    ];

    public $select_certificado = [
        'id',
        'certificado_capacitacion',
        'certificado_capacitaciontam',
        'certificado_capacitaciontipo',
        'certificado_aprobacion',
        'certificado_aprobaciontam',
        'certificado_aprobaciontipo',
    ];

    public $tabla_estudiante_envio = 'estudiante';

    public $tabla_curso = 'curso';
    public $tabla_curso_envio = 'curso';

    public $select_curso = [
        'id',
        'carga_horaria',
        'fecha_inicio',
        'fecha_fin',
    ];
}
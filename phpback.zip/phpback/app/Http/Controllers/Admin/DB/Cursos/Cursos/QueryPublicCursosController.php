<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Cursos;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Cursos\Others;

class QueryPublicCursosController extends Others
{

    public function __construct()
    {
    }

    public function publicGetCursosHome()
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_public_web_home)
                ->where(['estado' => true])
                ->orderBy('id', 'desc')
                ->limit(10)
                ->get();

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                // $Docente = DB::table("{$this->tabla_estudiante_docente}")
                //     ->select(...$this->selectTablaEstudianteADocenteWeb)
                //     ->selectRaw($this->nombre_completo_tabla_estudiante)
                //     ->where(['id' => $value->id_docente])
                //     ->first();
                // $tipoModalidad = $this->getTipoModalidad($value->tipo);

                $imageExist = Storage::exists("files/{$this->tabla}/{$value->foto}");

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_cursos_foto_envio}" => $imageExist ? $value->foto : null,
                    "{$this->tabla_cursos_envio}" => $value,
                    'loading' => false,
                    // "{$this->tabla_estudiante_docente_envio}" => $Docente,
                    // "{$this->tabla_tipo_envio}" => $tipoModalidad,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function publicGetCursosCursos()
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_public_web_home)
                ->where(['estado' => true])
                ->orderBy('id', 'desc')
                ->limit(24)
                ->get();

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                // $Docente = DB::table("{$this->tabla_estudiante_docente}")
                //     ->select(...$this->selectTablaEstudianteADocenteWeb)
                //     ->selectRaw($this->nombre_completo_tabla_estudiante)
                //     ->where(['id' => $value->id_docente])
                //     ->first();
                // $tipoModalidad = $this->getTipoModalidad($value->tipo);

                $imageExist = Storage::exists("files/{$this->tabla}/{$value->foto}");

                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_cursos_foto_envio}" => $imageExist && $value->foto !== "" ? $value->foto : null,
                    "{$this->tabla_cursos_envio}" => $value,
                    'loading' => false,
                    // "{$this->tabla_estudiante_docente_envio}" => $Docente,
                    // "{$this->tabla_tipo_envio}" => $tipoModalidad,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function publicGetCursoDetalle($cursoid)
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_public_web_home)
                ->where(['id' => $cursoid])
                ->first();

            $AsignacionTemario = DB::table("{$this->tabla_asignacion_curso_temario}")
                ->select(...$this->select_asignacion_curso_temario)
                ->where(['id_curso' => $cursoid])
                ->first();

            $Temario64 = null;
            if ($AsignacionTemario) {
                $Temario = DB::table("{$this->tabla_temario}")
                    ->select(...$this->select_temario_web)
                    ->where(['id' => $AsignacionTemario->id_temario])
                    ->first();

                $pdfExist = Storage::exists("files/{$this->tabla_temario}/{$Temario->archivo}");
                if ($pdfExist) {
                    $image = Storage::get("files/{$this->tabla_temario}/{$Temario->archivo}");
                    $image64 = base64_encode($image);

                    $Temario64 = $image64;
                }
            }

            $collection = [];

            $Docente = DB::table("{$this->tabla_estudiante_docente}")
                ->select(...$this->selectTablaEstudianteADocenteWeb)
                ->selectRaw($this->nombre_completo_tabla_estudiante)
                ->where(['id' => $Datos->id_docente])
                ->first();

            $Profesion = DB::table("{$this->tabla_profesion}")
                ->select(...$this->selectProfesion)
                ->where(['id' => $Docente->id_profesion])
                ->first();

            $Categoria = DB::table("{$this->tabla_categoria_cursos}")
                ->select(...$this->selectCategoriaCursos)
                ->where(['id' => $Datos->id_categoria])
                ->first();

            $tipoModalidad = $this->getTipoModalidad($Datos->tipo);

            $imageExist = Storage::exists("files/{$this->tabla}/{$Datos->foto}");
            $imageExistDocente = Storage::exists("files/{$this->tabla_estudiante_docente}/{$Docente->foto}");

            $collection = [
                'id' => $Datos->id,
                "{$this->tabla_docente_foto_envio}" => $imageExistDocente ? $Docente->foto : null,
                "{$this->tabla_cursos_foto_envio}" => $imageExist ? $Datos->foto : null,
                "{$this->tabla_cursos_envio}" => $Datos,
                'loading' => false,
                "{$this->tabla_estudiante_docente_envio}" => $Docente,
                "{$this->tabla_profesion_envio}" => $Profesion,
                "{$this->tabla_categoria_cursos_envio}" => $Categoria,
                "{$this->tabla_temario_envio}" => $Temario64,
                "{$this->tabla_tipo_envio}" => $tipoModalidad,
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
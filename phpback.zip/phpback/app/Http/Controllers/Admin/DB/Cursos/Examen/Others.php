<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Examen;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'examen';
    public $tabla_envio = 'examen';

    public $select = [
        'id',
        'titulo',
        'tiempo'
    ];

    public $tabla_preguntas = 'preguntas';
    public $tabla_preguntas_envio = 'preguntas';

    public $select_preguntas = [
        'id',
        'pregunta',
    ];

    public $select_preguntas_estudiante = [
        'id',
        'pregunta',
        'id_examen'
    ];

    public $tabla_respuestas = 'respuestas';
    public $tabla_respuestas_envio = 'respuestas';

    public $select_respuestas = [
        'id',
        'respuesta',
        'respuesta_bool',
    ];
    public $select_respuestas_estudiantes = [
        'id',
        'respuesta',
        'id_pregunta'
    ];
    public $select_cada_respuesta_estudiantes = [
        'id',
        'respuesta_bool'
    ];

    public $tabla_asignacion = 'asignacion_curso_examen';
    public $tabla_asignacion_envio = 'asignacion';

    public $select_asignacion = [
        'id',
        'id_examen',
        'id_curso'
    ];

    public $tabla_inscripcion = 'inscritos_curso';

    public $select_inscripcion_estudiante = [
        'id',
        'habilitado_examen',
        'id_curso',
        'id_estudiante'
    ];
}
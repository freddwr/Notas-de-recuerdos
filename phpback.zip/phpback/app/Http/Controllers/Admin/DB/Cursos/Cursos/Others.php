<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Cursos;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'curso';
    public $tabla_cursos_envio = 'cursos';
    public $tabla_cursos_foto_envio = 'foto';

    public $select = [
        'id',
        'nombre',
        // 'sub_nombre',
        // 'descripcion',
        // 'carga_horaria',
        // 'grupo_whatsapp',
        'fecha_inicio',
        'fecha_fin',
        'hora_inicio',
        'hora_fin',
        'precio_bolivia',
        'precio_usa',
        'tipo',
        // 'estado',
        'created',
        'foto',
        // 'fototam',
        // 'fototipo',
        // 'modalidad',
        // 'programa',
        // 'duracion',
        // 'horarios_sabado',
        // 'horarios_domingo',
        // 'certificado',
        // 'certificadotam',
        // 'certificadotipo',
        // 'tigocomision',
        'id_categoria',
        'id_docente',
        // 'id_certificado_capacitacion_disenio',
        // 'id_certificado_aprobacion_disenio',
    ];

    public $selectAddUpdate = [
        'id',
        'nombre',
        'descripcion',
        'duracion',
        'estado',
        'fecha_fin',
        'fecha_inicio',
        'foto',
        'grupo_whatsapp',
        'hora_fin',
        'hora_inicio',
        'precio_bolivia',
        'precio_usa',
        'tigocomision',
        'tipo',
        'carga_horaria',
        'id_categoria',
        'id_docente',
    ];

    public $selectDetailsInfoListEstudiantes = [
        'id',
        'nombre',
        'estado',
        'fecha_fin',
        'fecha_inicio',
        'foto',
        'tipo',
        'carga_horaria',
        'id_certificado_capacitacion_disenio',
        'id_certificado_aprobacion_disenio',
    ];

    public $select_public_web_home = [
        'id',
        'nombre',
        'fecha_inicio',
        // 'fecha_fin',
        'hora_inicio',
        'hora_fin',
        'precio_bolivia',
        'precio_usa',
        'tipo',
        'estado',
        'foto',
        'modalidad',
        'duracion',
        'carga_horaria',
        'grupo_whatsapp',
        'descripcion',
        // 'horarios_sabado',
        // 'horarios_domingo',
        // 'certificado',
        // 'certificadotam',
        // 'certificadotipo',
        'tigocomision',
        'id_categoria',
        'id_docente',
        // 'id_certificado_capacitacion_disenio',
        // 'id_certificado_aprobacion_disenio',
    ];

    public $tabla_categoria_cursos = 'categoria';
    public $tabla_categoria_cursos_envio = 'id_categoria';

    public $selectCategoriaCursos = [
        'id',
        'titulo',
    ];

    public $tabla_profesion = 'profesion';
    public $tabla_profesion_envio = 'profesion';

    public $selectProfesion = [
        'id',
        'nombre'
    ];

    public $tabla_estudiante_docente = 'estudiante';
    public $tabla_estudiante_docente_envio = 'id_docente';
    public $tabla_docente_foto_envio = 'docente_foto';

    public $selectTablaEstudianteDocente = [
        'id',
    ];

    public $nombre_completo_tabla_estudiante = "CONCAT(nombre, ' ', paterno, ' ', materno) as nombre_completo";

    public $selectTablaEstudianteADocenteWeb = [
        'id',
        'foto',
        'id_profesion',
    ];

    public $tabla_tipo = 'tipo';
    public $tabla_tipo_envio = 'tipo';

    public $tipoCollection = [
        ['id' => 'Presencial', 'nombre' => 'Presencial'],
        ['id' => 'Online', 'nombre' => 'Online'],
    ];

    public function getTipoModalidad($id_tipo)
    {

        if ($id_tipo === 'Presencial') {
            return $this->tipoCollection[0];
        }
        if ($id_tipo === 'Online') {
            return $this->tipoCollection[1];
        }
    }

    public $tabla_asignacion_curso_temario = 'asignacion_curso_temario';
    public $tabla_asignacion_curso_temario_envio = 'asignacion';

    public $select_asignacion_curso_temario = [
        'id',
        'id_temario',
        'id_curso',
    ];

    public $tabla_temario = 'temario';
    public $tabla_temario_envio = 'temario';

    public $select_temario = [
        'id',
        'nombre_temario',
    ];

    public $select_temario_web = [
        'id',
        'archivo',
    ];

    public $tabla_asignacion_curso_examen = 'asignacion_curso_examen';
    public $tabla_asignacion_curso_examen_envio = 'asignacion';

    public $select_asignacion_curso_examen = [
        'id',
        'id_examen',
        'id_curso',
    ];

    public $tabla_examen = 'examen';
    public $tabla_examen_envio = 'examen';

    public $select_examen = [
        'id',
        'titulo',
    ];

    public $tabla_asignacion_curso_certificado_capacitacion_disenio = 'curso';
    public $tabla_asignacion_curso_certificado_capacitacion_disenio_envio = 'asignacion';

    public $select_asignacion_curso_certificado_capacitacion_disenio = [
        'id',
        'id_certificado_capacitacion_disenio',
    ];

    public $tabla_certificado_capacitacion_disenio = 'certificado_disenio';
    public $tabla_certificado_capacitacion_disenio_envio = 'certificado_capacitacion';

    public $select_certificado_capacitacion_disenio = [
        'id',
        'nombre_certificado_tipo',
    ];

    public $tabla_asignacion_curso_certificado_aprobacion_disenio = 'curso';
    public $tabla_asignacion_curso_certificado_aprobacion_disenio_envio = 'asignacion';

    public $select_asignacion_curso_certificado_aprobacion_disenio = [
        'id',
        'id_certificado_aprobacion_disenio',
    ];

    public $tabla_certificado_aprobacion_disenio = 'certificado_disenio';
    public $tabla_certificado_aprobacion_disenio_envio = 'certificado_aprobacion';

    public $select_certificado_aprobacion_disenio = [
        'id',
        'nombre_certificado_tipo',
    ];

    public $tabla_certificado_disenio = 'certificado_disenio';
    public $tabla_certificado_capacitacion_envio = 'certificado_capacitacion';
    public $tabla_certificado_aprobacion_envio = 'certificado_aprobacion';

    public $select_certificado_disenio = [
        'id',
        'fondo',
    ];
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Cursos;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Cursos\Others;

class QueryOtherCursosController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function viewCursoDetailsInfoListEstudiante($curso)
    {
        $id = $curso;
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->selectDetailsInfoListEstudiantes)
                ->where('id', $id)
                ->first();

            $tipoModalidad = $this->getTipoModalidad($Datos->tipo);

            $idCertificadoCapacitacion_disenio = null;
            $idCertificadoAprobacion_disenio = null;

            if ($Datos->id_certificado_capacitacion_disenio) {
                $CertificadoCapacitacion = DB::table("{$this->tabla_certificado_disenio}")
                    ->select(...$this->select_certificado_disenio)
                    ->where('id', $Datos->id_certificado_capacitacion_disenio)
                    ->first();
                $idCertificadoCapacitacion_disenio = $CertificadoCapacitacion ? $CertificadoCapacitacion->id : null;
            }
            if ($Datos->id_certificado_aprobacion_disenio) {
                $CertificadoAprobacion = DB::table("{$this->tabla_certificado_disenio}")
                    ->select(...$this->select_certificado_disenio)
                    ->where('id', $Datos->id_certificado_aprobacion_disenio)
                    ->first();
                $idCertificadoAprobacion_disenio = $CertificadoAprobacion ? $CertificadoAprobacion->id : null;
            }

            $collection = [];
            $collection = [
                'id' => $id,
                "{$this->tabla_cursos_envio}" => $Datos,
                'loading' => false,
                "{$this->tabla_tipo_envio}" => $tipoModalidad,
                "{$this->tabla_certificado_capacitacion_envio}" => $idCertificadoCapacitacion_disenio,
                "{$this->tabla_certificado_aprobacion_envio}" => $idCertificadoAprobacion_disenio,
            ];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function selectTipoModalidad()
    {
        try {

            return $this->sendResponse200($this->tipoCollection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ajustesCurso($cursos)
    {
        try {

            $AsignacionTemario = DB::table("{$this->tabla_asignacion_curso_temario}")
                ->select(...$this->select_asignacion_curso_temario)
                ->where(['id_curso' => $cursos])
                ->first();

            $Temario = null;
            if ($AsignacionTemario)
                $Temario = DB::table("{$this->tabla_temario}")
                    ->select(...$this->select_temario)
                    ->where(['id' => $AsignacionTemario->id_temario])
                    ->first();

            $AsignacionExamen = DB::table("{$this->tabla_asignacion_curso_examen}")
                ->select(...$this->select_asignacion_curso_examen)
                ->where(['id_curso' => $cursos])
                ->first();

            $Examen = null;
            if ($AsignacionExamen)
                $Examen = DB::table("{$this->tabla_examen}")
                    ->select(...$this->select_examen)
                    ->where(['id' => $AsignacionExamen->id_examen])
                    ->first();

            $AsignacionCertificadoCapacitacion = DB::table("{$this->tabla_asignacion_curso_certificado_capacitacion_disenio}")
                ->select(...$this->select_asignacion_curso_certificado_capacitacion_disenio)
                ->where(['id' => $cursos])
                ->first();

            $CertificadoCapacitacion = null;
            if ($AsignacionCertificadoCapacitacion)
                $CertificadoCapacitacion = DB::table("{$this->tabla_certificado_capacitacion_disenio}")
                    ->select(...$this->select_certificado_capacitacion_disenio)
                    ->where(['id' => $AsignacionCertificadoCapacitacion->id_certificado_capacitacion_disenio])
                    ->first();

            $AsignacionCertificadoAprobacion = DB::table("{$this->tabla_asignacion_curso_certificado_aprobacion_disenio}")
                ->select(...$this->select_asignacion_curso_certificado_aprobacion_disenio)
                ->where(['id' => $cursos])
                ->first();

            $CertificadoAprobacion = null;
            if ($AsignacionCertificadoAprobacion)
                $CertificadoAprobacion = DB::table("{$this->tabla_certificado_aprobacion_disenio}")
                    ->select(...$this->select_certificado_aprobacion_disenio)
                    ->where(['id' => $AsignacionCertificadoAprobacion->id_certificado_aprobacion_disenio])
                    ->first();

            $collection = [
                "$this->tabla_temario_envio" => [
                    "$this->tabla_temario_envio"  => $Temario,
                    "$this->tabla_asignacion_curso_temario_envio" => $AsignacionTemario
                ],
                "$this->tabla_examen_envio" => [
                    "$this->tabla_examen_envio"  => $Examen,
                    "$this->tabla_asignacion_curso_examen_envio" => $AsignacionExamen
                ],
                "$this->tabla_certificado_capacitacion_disenio_envio" => [
                    "$this->tabla_certificado_capacitacion_disenio_envio"  => $CertificadoCapacitacion,
                    "$this->tabla_asignacion_curso_certificado_capacitacion_disenio_envio" => $AsignacionCertificadoCapacitacion
                ],
                "$this->tabla_certificado_aprobacion_disenio_envio" => [
                    "$this->tabla_certificado_aprobacion_disenio_envio"  => $CertificadoAprobacion,
                    "$this->tabla_asignacion_curso_certificado_aprobacion_disenio_envio" => $AsignacionCertificadoAprobacion
                ],
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Examen;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Examen\Others;

class QueryOtherExamenController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function asignacionCursoExamen(Request $request)
    {
        try {
            $datos = $request->json()->all();

            DB::table("{$this->tabla_asignacion}")->insertGetId([
                // 'id' => "{$request->id}",
                'id_examen' => $datos['id_examen'],
                'id_curso' => $datos['id_curso'],
            ]);

            DB::table("{$this->tabla_inscripcion}")
                ->where('id_curso', $datos['id_curso'])
                ->update([
                    'id_examen' => $datos['id_examen'],
                ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function deleteAsignacionCursoExamen($asignacion)
    {
        try {

            DB::table("{$this->tabla_asignacion}")->where('id', $asignacion)->delete();

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    /* ESTUDIANTE TEST  */

    public function testComprobacionCurso($curso, $estudiante, $inscripcion)
    {
        try {
            $NoInscrito = ['st_inscrito' => false, 'message' => 'advertencia'];

            /* -----------------------------VERIFICACION y HABILITACION------------------------------------------- */
            $EstaInscrito = DB::table("{$this->tabla_inscripcion}")
                ->select(...$this->select_inscripcion_estudiante)
                ->where(['id' => $inscripcion])
                ->first();

            if (!$EstaInscrito)
                return $this->sendResponse200($NoInscrito, "{$this->success_get_message}1");

            if ($EstaInscrito->id_estudiante !== intval($estudiante) || $EstaInscrito->id_curso !== intval($curso) || !$EstaInscrito->habilitado_examen)
                return $this->sendResponse200($NoInscrito, "{$this->success_get_message}2");

            /* -----------------------------FIN DE VERIFICACION------------------------------------------- */

            DB::table("{$this->tabla_inscripcion}")
                ->where('id', $EstaInscrito->id)
                ->update([
                    'habilitado_examen' => false,
                    'nota' => 0,
                ]);

            $Datos = DB::table("{$this->tabla_asignacion}")
                ->select(...$this->select_asignacion)
                ->where(['id_curso' => $curso])
                ->first();

            $Examen = null;
            if ($Datos && $Datos->id_examen)
                $Examen = DB::table("{$this->tabla}")
                    ->select(...$this->select)
                    ->where(['id' => $Datos->id_examen])
                    ->first();

            $collection = [];
            $test = collect([]);

            $Preguntas = null;
            if ($Examen && $Examen->id)
                $Preguntas = DB::table("{$this->tabla_preguntas}")
                    ->select(...$this->select_preguntas_estudiante)
                    ->where(['id_examen' => $Examen->id])
                    ->inRandomOrder()
                    ->get();

            if ($Preguntas) {
                $contador = 0;
                foreach ($Preguntas as $key => $value) {
                    $Respuestas = DB::table("{$this->tabla_respuestas}")
                        ->select(...$this->select_respuestas_estudiantes)
                        ->where(['id_pregunta' => $value->id])
                        ->inRandomOrder()
                        ->get();

                    $cantidad = 0;

                    foreach ($Respuestas as $key => $resp) {
                        $Respuesta = DB::table("{$this->tabla_respuestas}")
                            ->select(...$this->select_cada_respuesta_estudiantes)
                            ->where(['id' => $resp->id])
                            ->first();
                        if ($Respuesta->respuesta_bool)
                            $cantidad = $cantidad + 1;
                    }

                    // $newDatos = collect($Respuestas)->map(function ($value) use ($text) {
                    $newDatosRespuestas = collect($Respuestas)->map(function ($value) use ($contador) {
                        return ([
                            'id' => $value->id,
                            'respuesta' => $value->respuesta,
                            'contador' => $contador
                        ]);
                    });

                    $contador = $contador + 1;

                    $test->push([
                        'pregunta' => $value,
                        'respuesta' => $newDatosRespuestas,
                        'cantidad' => $cantidad
                    ]);
                }
            }
            $collection = [
                'id' => intval($inscripcion),
                'st_inscrito' => true,
                'message' => 'continua',
                'examen' => $Examen,
                'test' => $test,
            ];


            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    /* FIN TEST ESTUDIANTE POR CURSO */

    public function finTestCurso(Request $request)
    {
        try {
            $datos = $request->json()->all();

            if (!$datos['test']) {
                return $this->sendError('error', ['error' => 'Error :( 1'], 200);
            }

            $totalCorrectas = 0;
            $totalRespEstudiante = 0;
            foreach ($datos['test'] as $key => $preg) {
                $totalCorrectas += $preg['cantidad'];

                foreach ($preg['respuesta'] as $key => $resp) {
                    if ($resp['respuesta_bool']) {
                        $IsRespTrue = DB::table("{$this->tabla_respuestas}")
                            ->select(...$this->select_cada_respuesta_estudiantes)
                            ->where(['id' => $resp['id']])
                            ->first();
                        $totalRespEstudiante += $IsRespTrue->respuesta_bool ? 1 : 0;
                    }
                }
            }

            $nota = (100 * $totalRespEstudiante) / $totalCorrectas;

            DB::table("{$this->tabla_inscripcion}")
                ->where('id', $datos['id_inscripcion'])
                ->update([
                    'nota' => round($nota, 2),
                    'habilitado_examen' => false,
                    'habilitado_certificado_aprobacion' => $nota > 80 ? true : false,
                ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }
}
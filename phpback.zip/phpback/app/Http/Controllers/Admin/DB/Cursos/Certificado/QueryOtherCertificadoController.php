<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Certificado;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Certificado\Others;

class QueryOtherCertificadoController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function certificadoEstudianteSave(Request $request, $certificado)
    {

        $Id = $certificado;
        $datos = $request->json()->all();

        try {

            // var_dump($datos);
            // dd($datos);
            // $SelectColumn = $datos['nombre'];

            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado)
                ->where(['id' => $datos['id']])
                ->first();

            $columName = $datos['nombre'];

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            if ($GetDatos && $GetDatos->$columName) {
                $this->deleteFile("{$this->tabla_certificado}", $datos['id'], "{$datos['nombre']}");
            }

            $imageName = null;

            if ($datos['imagen']) {
                [
                    $imagen,
                    $imagentam, $imagentipo, $imagentipocom
                ] = $this->imagePutFileArchivo($datos['imagen'], true, 'image/jpeg', "{$this->tabla_certificado}", "img_{$this->tabla_certificado}");
                // $datos['imagen'] = $imagen;
                $imageName = $imagen;
            }

            DB::table("{$this->tabla_certificado}")->where('id', $datos['id'])->update([
                "{$datos['nombre']}" => $imageName,
            ]);

            //     $Datos = DB::table("{$this->tabla}")
            //         ->select(...$this->select)
            //         ->where(['id' => $Id])
            //         ->first();

            $collection = [];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function updateOneImage(Request $request, $certificado)
    {

        // $Id = $certificado;
        $datos = $request->json()->all();
        $SelectColumn = $datos['nombre'];

        $GetDatos = DB::table("{$this->tabla}")
            ->select($SelectColumn)
            ->where(['id' => $datos['id']])
            ->first();

        $columData = $GetDatos->$SelectColumn;
        $PreImagenes = [
            '1_fondo_certificado.jpeg',
            '2_img_arriba_certificado.jpeg',
            '3_img_abajo_izq_certificado.jpeg',
            '4_img_abajo_der_certificado.jpeg',
            '6_img_sello_certificado.jpeg',
            '7_img_sello_direc_certificado.jpeg',
            '8_img_firma_direc_certificado.jpeg',
            '5_img_titulo_certificado.jpeg',
        ];

        // $searchDato = array_map(function ($dato) use ($columData) {
        //     return str_contains(Str::lower(strval($columData)), $dato);
        // }, $PreImagenes);

        if (!in_array($columData, $PreImagenes)) {
            $this->deleteFile("{$this->tabla}", $datos['id'], $SelectColumn);
        }

        $imageName = null;

        if ($datos['imagen']) {
            [
                $fondo,
                $fondotam, $fondotipo, $fondotipocom
            ] = $this->imagePutFileArchivo($datos['imagen'], true, 'image/jpeg', "{$this->tabla}", "img_{$this->tabla}");
            // $datos['fondo'] = $fondo;
            $imageName = $fondo;
        }

        // unset($datos['fondotipocom']);
        // unset($datos['fondonew']);
        // unset($datos['fondoextension']);
        // unset($datos['created']);
        // unset($datos['updated']);

        try {
            DB::table("{$this->tabla}")->where('id', $datos['id'])->update([
                $SelectColumn => $imageName,
            ]);

            //     $Datos = DB::table("{$this->tabla}")
            //         ->select(...$this->select)
            //         ->where(['id' => $Id])
            //         ->first();


            $collection = [];
            $collection = [
                'id' => $datos['id'],
                "image" => $imageName,
                'nombre' => $SelectColumn,
            ];

            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function getCursoCertificado($certificado, $curso)
    {
        try {
            if (!$certificado || $certificado === "null") {
                return $this->sendResponse200([], "{$this->success_get_message}");
            }

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select_edit)
                ->where(['id' => $certificado])
                ->first();


            $Curso = DB::table("{$this->tabla_curso}")
                ->select(...$this->select_curso)
                ->where(['id' => $curso])
                ->first();

            $DataCertificado = [
                'nombre_completo' => null,
                'fechaInicio' => $Curso->fecha_inicio,
                'fechaFin' => $Curso->fecha_fin,
                'cargaHoraria' => $Curso->carga_horaria,
            ];

            // $imageExist = Storage::exists("files/{$this->tabla}/{$Datos->fondo}");
            $collection = [];
            $arrayCertificado = $this->getImagenesCertificado($Datos, $this->tabla, $DataCertificado);

            $collection = [
                'id' => $certificado,
                "{$this->tabla_certificado_envio}" => $arrayCertificado,
                // "{$this->tabla_curso_envio}" => $Curso,
                'loading' => false,
            ];

            // $image64 = null;
            // if ($imageExist) {
            //     $image = Storage::get("files/{$this->tabla}/{$Datos->fondo}");
            //     $image64 = base64_encode($image);
            // }

            // $collection = [
            //     // "{$this->tabla_certificado_envio}" => $image64,
            // ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function asignacionCursoCertificadoCapacitacion(Request $request)
    {
        try {
            $datos = $request->json()->all();

            DB::table("{$this->tabla_asignacion}")->where('id', $datos['id_curso'])->update([
                'id_certificado_capacitacion_disenio' => $datos['id_certificado_capacitacion_disenio'],
            ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function deleteAsignacionCursoCertificadoCapacitacion($asignacion)
    {
        try {

            DB::table("{$this->tabla_asignacion}")->where('id', $asignacion)->update([
                'id_certificado_capacitacion_disenio' => null,
            ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function asignacionCursoCertificadoAprobacion(Request $request)
    {
        try {
            $datos = $request->json()->all();

            DB::table("{$this->tabla_asignacion}")->where('id', $datos['id_curso'])->update([
                'id_certificado_aprobacion_disenio' => $datos['id_certificado_aprobacion_disenio'],
            ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function deleteAsignacionCursoCertificadoAprobacion($asignacion)
    {
        try {

            DB::table("{$this->tabla_asignacion}")->where('id', $asignacion)->update([
                'id_certificado_aprobacion_disenio' => null,
            ]);

            $collection = [];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }

    public function getImage64Certificado($imagenName)
    {
        try {

            $existeImagen = Storage::exists("files/{$this->tabla}/{$imagenName}");

            $collection = [];

            if ($existeImagen && $imagenName) {
                $image = Storage::get("files/{$this->tabla}/{$imagenName}");
                $image64 = base64_encode($image);

                $collection = [
                    "imagen" => $image64,
                ];
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError('error', ['error' => $e->getMessage()], 200);
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Temario;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'temario';
    public $tabla_envio = 'temario';
    public $tabla_archivo64_envio = 'archivo';

    public $select = [
        'id',
        'nombre_temario',
        'archivo'
    ];

    public $tabla_asignacion = 'asignacion_curso_temario';
    public $tabla_asignacion_envio = 'asignacion';

    public $select_asignacion = [
        'id',
        'id_temario',
        'id_curso'
    ];
}
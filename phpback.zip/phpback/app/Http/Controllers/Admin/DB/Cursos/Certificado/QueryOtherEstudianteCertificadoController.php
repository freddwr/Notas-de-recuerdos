<?php

namespace App\Http\Controllers\Admin\DB\Cursos\Certificado;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Cursos\Certificado\Others;

class QueryOtherEstudianteCertificadoController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function certificadoEstudianteCapacitacion($certificado)
    {

        $Id = $certificado;
        // dd($certificado);
        try {

            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_capacitacion)
                ->where(['id' => $Id])
                ->first();

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            $certificado = DB::table("{$this->tabla}")
                ->select(...$this->select_edit)
                ->where('id', $GetDatos->id_certificado_capacitacion_disenio)
                ->first();

            $DataCertificado = [
                'nombre_completo' => "{$GetDatos->nombre} {$GetDatos->paterno} {$GetDatos->materno}",
                'fechaInicio' => $GetDatos->fecha_iniciocurso,
                'fechaFin' => $GetDatos->fecha_fincurso,
                'cargaHoraria' => $GetDatos->carga_horaria,
            ];

            $arrayCertificado = null;
            if ($certificado)
                $arrayCertificado = $this->getImagenesCertificado($certificado, $this->tabla, $DataCertificado);

            $imageBase64 = null;
            $image64 = false;
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$GetDatos->certificado_capacitacion}");
            if ($imageExist && $GetDatos->certificado_capacitacion) {
                $image = Storage::get("files/{$this->tabla_certificado}/{$GetDatos->certificado_capacitacion}");
                $imageBase64 = base64_encode($image);
                $image64 = true;
            }

            $collection = [
                "{$this->tabla_estudiante_envio}" => $GetDatos,
                "{$this->tabla_certificado64_envio}" => $image64,
                "{$this->tabla_certificadoBase64_envio}" => $imageBase64,
                "{$this->tabla_certificado_envio}" => $arrayCertificado,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function certificadoEstudianteCapacitacionSave(Request $request, $certificado)
    {

        $Id = $certificado;
        $datos = $request->json()->all();
        // dd($certificado);
        try {

            $this->deleteFile("{$this->tabla_certificado}", $datos['id'], "{$datos['nombre']}");

            $imageName = null;

            if ($datos['imagen']) {
                [
                    $imagen,
                    $imagentam, $imagentipo, $imagentipocom
                ] = $this->imagePutFileArchivo($datos['imagen'], true, 'image/jpeg', "{$this->tabla_certificado}", "img_{$this->tabla_certificado}");
                // $datos['imagen'] = $imagen;
                $imageName = $imagen;

                DB::table("{$this->tabla_certificado}")->where('id', $datos['id'])->update([
                    "{$datos['nombre']}" => $imageName,
                ]);
            }



            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_capacitacion)
                ->where(['id' => $Id])
                ->first();

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            $certificado = DB::table("{$this->tabla}")
                ->select(...$this->select_edit)
                ->where('id', $GetDatos->id_certificado_capacitacion_disenio)
                ->first();

            $DataCertificado = [
                'nombre_completo' => "{$GetDatos->nombre} {$GetDatos->paterno} {$GetDatos->materno}",
                'fechaInicio' => $GetDatos->fecha_iniciocurso,
                'fechaFin' => $GetDatos->fecha_fincurso,
                'cargaHoraria' => $GetDatos->carga_horaria,
            ];

            $arrayCertificado = null;
            if ($certificado)
                $arrayCertificado = $this->getImagenesCertificado($certificado, $this->tabla, $DataCertificado);

            // $image64 = null;
            $image64 = false;
            $imageBase64 = null;
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$GetDatos->certificado_capacitacion}");
            if ($imageExist && $GetDatos->certificado_capacitacion) {
                $image = Storage::get("files/{$this->tabla_certificado}/{$GetDatos->certificado_capacitacion}");
                $imageBase64 = base64_encode($image);
                $image64 = true;
            }

            $collection = [
                "{$this->tabla_estudiante_envio}" => $GetDatos,
                "{$this->tabla_certificado64_envio}" => $image64,
                "{$this->tabla_certificadoBase64_envio}" => $imageBase64,
                "{$this->tabla_certificado_envio}" => $arrayCertificado,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function certificadoEstudianteAprobacion($certificado)
    {
        $Id = $certificado;
        // dd($certificado);
        try {

            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_aprobacion_est)
                ->where(['id' => $Id])
                ->first();

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            $certificado = DB::table("{$this->tabla}")
                ->select(...$this->select_edit)
                ->where('id', $GetDatos->id_certificado_aprobacion_disenio)
                ->first();

            $DataCertificado = [
                'nombre_completo' => "{$GetDatos->nombre} {$GetDatos->paterno} {$GetDatos->materno}",
                'fechaInicio' => $GetDatos->fecha_iniciocurso,
                'fechaFin' => $GetDatos->fecha_fincurso,
                'cargaHoraria' => $GetDatos->carga_horaria,
            ];

            $arrayCertificado = null;
            if ($certificado)
                $arrayCertificado = $this->getImagenesCertificado($certificado, $this->tabla, $DataCertificado);

            $imageBase64 = null;
            $image64 = false;
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$GetDatos->certificado_aprobacion}");
            if ($imageExist && $GetDatos->certificado_aprobacion) {
                $image = Storage::get("files/{$this->tabla_certificado}/{$GetDatos->certificado_aprobacion}");
                $imageBase64 = base64_encode($image);
                $image64 = true;
            }

            $collection = [
                "{$this->tabla_estudiante_envio}" => $GetDatos,
                "{$this->tabla_certificado64_envio}" => $image64,
                "{$this->tabla_certificadoBase64_envio}" => $imageBase64,
                "{$this->tabla_certificado_envio}" => $arrayCertificado,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function certificadoEstudianteAprobacionSave(Request $request, $certificado)
    {

        $Id = $certificado;
        $datos = $request->json()->all();
        // dd($certificado);
        try {

            $this->deleteFile("{$this->tabla_certificado}", $datos['id'], "{$datos['nombre']}");

            $imageName = null;

            if ($datos['imagen']) {
                [
                    $imagen,
                    $imagentam, $imagentipo, $imagentipocom
                ] = $this->imagePutFileArchivo($datos['imagen'], true, 'image/jpeg', "{$this->tabla_certificado}", "img_{$this->tabla_certificado}");
                // $datos['imagen'] = $imagen;
                $imageName = $imagen;

                DB::table("{$this->tabla_certificado}")->where('id', $datos['id'])->update([
                    "{$datos['nombre']}" => $imageName,
                ]);
            }



            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_aprobacion_est)
                ->where(['id' => $Id])
                ->first();

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            $certificado = DB::table("{$this->tabla}")
                ->select(...$this->select_edit)
                ->where('id', $GetDatos->id_certificado_aprobacion_disenio)
                ->first();

            $DataCertificado = [
                'nombre_completo' => "{$GetDatos->nombre} {$GetDatos->paterno} {$GetDatos->materno}",
                'fechaInicio' => $GetDatos->fecha_iniciocurso,
                'fechaFin' => $GetDatos->fecha_fincurso,
                'cargaHoraria' => $GetDatos->carga_horaria,
            ];

            $arrayCertificado = null;
            if ($certificado)
                $arrayCertificado = $this->getImagenesCertificado($certificado, $this->tabla, $DataCertificado);

            // $image64 = null;
            $image64 = false;
            $imageBase64 = null;
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$GetDatos->certificado_aprobacion}");
            if ($imageExist && $GetDatos->certificado_aprobacion) {
                $image = Storage::get("files/{$this->tabla_certificado}/{$GetDatos->certificado_aprobacion}");
                $imageBase64 = base64_encode($image);
                $image64 = true;
            }

            $collection = [
                "{$this->tabla_estudiante_envio}" => $GetDatos,
                "{$this->tabla_certificado64_envio}" => $image64,
                "{$this->tabla_certificadoBase64_envio}" => $imageBase64,
                "{$this->tabla_certificado_envio}" => $arrayCertificado,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    /* ESTUDIANTE GET VISTA CERTIFICADO CAPACITACION APROBACION  */


    public function viewCertificadoEstudianteCapacitacion($certificado)
    {

        $Id = $certificado;
        // dd($certificado);
        try {

            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_capacitacion_estudiante)
                ->where(['id' => $Id])
                ->first();

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            // $image64 = false;
            $imageBase64 = null;
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$GetDatos->certificado_capacitacion}");
            if ($imageExist && $GetDatos->certificado_capacitacion) {
                $image = Storage::get("files/{$this->tabla_certificado}/{$GetDatos->certificado_capacitacion}");
                $imageBase64 = base64_encode($image);
                // $image64 = true;
            }

            $collection = [
                // "{$this->tabla_estudiante_envio}" => $GetDatos,
                "{$this->tabla_certificadoBase64_envio}" => $imageBase64,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function viewCertificadoEstudianteAprobacion($certificado)
    {

        $Id = $certificado;
        // dd($certificado);
        try {

            $GetDatos = DB::table("{$this->tabla_certificado}")
                ->select(...$this->select_certificado_aprobacion_estudiante)
                ->where(['id' => $Id])
                ->first();

            if (!$GetDatos) {
                return $this->sendError500('Error :(', '');
            }

            // $image64 = false;
            $imageBase64 = null;
            $imageExist = Storage::exists("files/{$this->tabla_certificado}/{$GetDatos->certificado_aprobacion}");
            if ($imageExist && $GetDatos->certificado_aprobacion) {
                $image = Storage::get("files/{$this->tabla_certificado}/{$GetDatos->certificado_aprobacion}");
                $imageBase64 = base64_encode($image);
                // $image64 = true;
            }

            $collection = [
                // "{$this->tabla_estudiante_envio}" => $GetDatos,
                "{$this->tabla_certificadoBase64_envio}" => $imageBase64,
                'loading' => false,
            ];
            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
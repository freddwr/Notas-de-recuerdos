<?php

namespace App\Http\Controllers\Admin\DB\Mail;

use Illuminate\Http\Request;
use App\Mail\CorreoMail;
use Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;

class CorreoMailController extends Ctrl
{
    public function enviarMail($contrasenia, $correo){
        $data = $contrasenia;
        Mail::to("$correo")->send(new CorreoMail($data, $correo));
    }
}
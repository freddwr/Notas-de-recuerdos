<?php

namespace App\Http\Controllers\Admin\DB;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\MessageRes;


class MessageController
{

    public function index()
    {
        Mail::send('view', [], function($message) {
            $message->subject("A new Member has been Registered" );
            $message->from('noreply@mydomain.net', 'Your application title');
            $message->to('yourcustomer@yourdomain.com');
        });

        return view('view');
    }

}
<?php

namespace App\Http\Controllers\Admin\DB\Roles;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class RolesController extends Ctrl
{

    private $tabla = 'roles';

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            'index',
        ]]);
    }

    public function index()
    {
        try {

            $roles = DB::table("{$this->tabla}")->orderBy('id', 'desc')->get();
            return $this->sendResponse200($roles->toArray(), "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}

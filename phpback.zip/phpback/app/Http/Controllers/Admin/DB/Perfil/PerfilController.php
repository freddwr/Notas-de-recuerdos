<?php

namespace App\Http\Controllers\Admin\DB\Perfil;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class PerfilController extends Ctrl
{

    private $tabla = 'users';

    public function __construct(){
        $this->middleware('jwt.verify', ['except' => [
            'index',
            // 'edit',
            // 'store',
            'update',
            // 'destroy'
        ]]);
    }

    public function index(){
        // dd(auth()->user());
        try {
            $id = auth()->user()->id;
            $perfil = User::where('id', $id)
                ->select(
                    'id',
                    'nombre',
                    'paterno',
                    'materno',
                    'id_nivel',
                    'celular',
                    'genero',
                    'facebook_link',
                    'acerca_de',
                    'carnet_identidad',
                )
                ->first();
            return $this->sendResponse200($perfil, "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function store(Request $request){
        // // dd($request);
        // $validator = Validator::make($request->all(), [
        //     'id' => 'required|string|max:100',
        //     'nombre' => 'required|string|max:100',
        // ]);

        // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        // // [$palabra] = $this->textUppercase($request->nombre);
        // // $nombre = $palabra;
        // // [$foto, $fototam, $fototipo] = $this->imagePutFileArchivo($request->foto, $request->fotonew, $request->fotoextension, $this->tabla);

        // try {
        //     $zonaId = DB::table("{$this->tabla}")->insertGetId([
        //         'id' => "{$request->id}",
        //         'nombre' => "{$request->nombre}",
        //     ]);

        //     return $this->sendResponse200(['local' => $zonaId, 'formulario' => $request], "{$this->success_register_message}");

        // } catch (\Exception $e) {
        //     return $this->sendError500($e->getMessage(), '');
        // }

    }



    public function create(Request $request){}
    public function show(Request $request){}



    public function edit($users){
        // $id = $users
        // // $id = auth()->user()->id;
        // try {
        //     $users = DB::table("{$this->tabla}")->where('id', $id)->first();

        //     return $this->sendResponse200($users, "{$this->success_get_one_message}");

        // } catch (\Exception $e) {
        //     return $this->sendError500($e->getMessage(), '');
        // }

    }

    public function update(Request $request, $users){

        $Id = $users; //solo obtiene el parametro /users/{users}
        $rowAffect = 0;
        $datos = $request->json()->all();
        // $validator = Validator::make($datos, [
        //     'nombre' => 'required|string|max:50',
        //     'paterno' => 'required|string|max:50',
        //     'profesion' => 'required|max:50',
        //     'telefono' => 'required|max:50',
        //     'correo' => 'required|max:50',
        // ]);

        // if ($validator->fails()) : return $this->sendError405('', "$this->data_require"); endif;

        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                $rowAffect = DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            return $this->sendResponse200(['local' => $Id, 'formulario' => $request], "{$this->success_update_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }

    }

    public function destroy($id){

        // $this->deleteFile($this->tabla, $id, 'foto');
        // try {

        //     DB::table("{$this->tabla}")->where('id', $id)->delete();

        //     return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");

        // } catch (\Exception $e) {
        //     return $this->sendError500($e->getMessage(), '');
        // }
    }
}
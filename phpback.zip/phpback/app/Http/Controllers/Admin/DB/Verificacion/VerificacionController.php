<?php

namespace App\Http\Controllers\Admin\DB\Verificacion;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Admin\ResController as Ctrl;

use Illuminate\Support\Facades\Crypt;

class VerificacionController extends Ctrl
{

    public function __construct()
    {
        // $this->middleware('auth')->except('index');
        // $this->middleware('auth', ['only' => ['store', 'edit', 'update', 'destroy']]);
        $this->middleware('jwt.verify', ['except' => [
            'verificacion',
        ]]);
    }

    public function verificacion($id_est, $id_cur)
    {
        // $id_estudiante = Crypt::decrypt($id_est);
        // $id_curso = Crypt::decrypt($id_cur);
        $id_estudiante = $id_est;
        $id_curso = $id_cur;

        try {
            $estudiante = DB::table('certificado')
                ->join('estudiante','certificado.id_estudiante', '=', 'estudiante.id')
                ->join('users','certificado.id_estudiante', '=', 'users.id_persona')
                ->join('curso','certificado.id_curso', '=', 'curso.id')
                ->where([
                    'certificado.id_estudiante' => $id_estudiante,
                    'certificado.id_curso' => $id_curso,
                    'certificado.certificado_habilitacion_examen' => true,
                ])
                ->select(
                    'estudiante.profesion_abreviatura as profesionAbrviaturaEstudiante',
                    'estudiante.nombre as nombreEstudiante',
                    'estudiante.paterno as paternoEstudiante',
                    'estudiante.materno as maternoEstudiante',
                    'estudiante.telefono as telefonoEstudiante',
                    'users.foto as fotoEstudiante',
                    'curso.nombre as nombreCurso',
                    'curso.sub_nombre as sub_nombreCurso',
                    'curso.carga_horaria as carga_horariaCurso',
                    'curso.foto as fotoCurso',
                    'curso.fecha_inicio as fecha_inicioCurso',
                    'curso.fecha_fin as fecha_finCurso',
                    )
                ->first();

            if(!$estudiante){
                $response = [
                    'success' => false,
                    'message' => 'Los datos no coinciden',
                ];
                return response()->json($response, 404);
            }

        } catch (\Exception $e) {
            $response = [
                'success' => false,
                'message' => 'Datos Incorrectos',
            ];

            if(!empty($e)){
                $response['data'] = $e;
            }
            return response()->json($response, 404);
        }
        $response = [
            'success' => true,
            'data'    => $estudiante,
            'message' => "datos obtenido",
        ];

        return response()->json($response, 200);
    }

}
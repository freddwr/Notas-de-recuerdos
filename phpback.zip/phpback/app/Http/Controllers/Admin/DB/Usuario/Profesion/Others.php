<?php

namespace App\Http\Controllers\Admin\DB\Usuario\Profesion;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'profesion';
    public $tabla_envio = 'profesion';

    public $select = [
        'id',
        'nombre',
        'sigla',
    ];
}
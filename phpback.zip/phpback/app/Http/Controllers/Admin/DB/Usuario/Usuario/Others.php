<?php

namespace App\Http\Controllers\Admin\DB\Usuario\Usuario;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'estudiante';
    public $tabla_envio = 'usuario';

    public $select = [
        'id',
        'nombre',
        'paterno',
        'materno',
        'profesion',
        'profesion_abreviatura',
        'telefono',
        'correo',
        'foto',
        'prefijo_telefono',
        'nick',
        'password',
        'pass_view',
        'activo',
        'rol',
        'id_persona',
        'id_anterior',
        'id_profesion',
        'id_codigo_pais',
        // 'id_roles',
    ];

    public $nombre_completo = "CONCAT(nombre, ' ', paterno, ' ', materno) as nombre_completo";

    public $nombre_completo_telefono = "CONCAT(nombre, ' ', paterno, ' ', materno, ' CEL:', telefono) as nombre_completo";

    public $tabla_codigo_pais = 'codigo_pais';
    public $tabla_codigo_pais_envio = 'id_codigo_pais';

    public $select_codigo_pais = [
        'id',
        'pais',
    ];

    public $tabla_profesion = 'profesion';
    public $tabla_profesion_envio = 'id_profesion';

    public $select_profesion = [
        'id',
        'nombre',
    ];

    public $tabla_rol = 'rol';
    public $tabla_rol_envio = 'rol';

    private $rolCollection = [
        ['id' => 'administrador_tobyc', 'nombre' => 'Administrador'],
        ['id' => 'estudiante_tobyc', 'nombre' => 'Estudiante'],
        ['id' => 'docente_tobyc', 'nombre' => 'Docente']
    ];

    public function getRolUsuario($id_rol)
    {

        if ($id_rol === 'administrador_tobyc') {
            return $this->rolCollection[0];
        }
        if ($id_rol === 'estudiante_tobyc') {
            return $this->rolCollection[1];
        }
        if ($id_rol === 'docente_tobyc') {
            return $this->rolCollection[2];
        }
    }
}
<?php

namespace App\Http\Controllers\Admin\DB\Usuario\CodigoPais;

use App\Http\Controllers\Admin\ResController as Ctrl;

class Others extends Ctrl
{

    public $tabla = 'codigo_pais';
    public $tabla_envio = 'codigo_pais';

    public $select = [
        'id',
        'codigo',
        'pais',
    ];
}
<?php

namespace App\Http\Controllers\Admin\DB\Usuario\Profesion;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;

use App\Http\Controllers\Admin\DB\Usuario\Profesion\Others;

class QuerySearchProfesionController extends Others
{

    public function __construct()
    {
        // $this->middleware('jwt.verify', ['except' => [
        //     'cantidadRows',
        // ]]);
    }

    public function searchInString($value, $searchText)
    {
        $textSplit =  explode(" ", $searchText);

        $searchDato = array_map(function ($dato) use ($value) {
            return str_contains(Str::lower(strval($value)), $dato);
        }, $textSplit);
        return in_array(true, $searchDato);
    }

    public function searchInObject($itemObj, $searchText)
    {
        $arrayObj = collect($itemObj);
        $arrayRes = $arrayObj->filter(function ($val) use ($searchText) {
            return ($this->searchInString($val, $searchText));
        });
        if (count($arrayRes) === 0) return false;
        return true;
    }

    public function search(Request $request)
    {
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->orderByDesc('id')
                ->get();
            $text = $request->get('text');

            $newDatos = collect($Datos)->filter(function ($value) use ($text) {
                return ($this->searchInObject($value, $text));
            });

            $collection = collect([]);
            foreach ($newDatos as $key => $value) {
                $rolUsuario = $this->getRolUsuario($value->rol);
                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_envio}" => $value,
                    'loading' => false,
                    "{$this->tabla_rol_envio}" => $rolUsuario,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function cantidadRows()
    {
        try {

            $Datos = DB::table("{$this->tabla}")->count('id');
            $DatoUltimo = DB::table("{$this->tabla}")->select('id')->orderByDesc('id')->first();
            // $DatosIDs = DB::select("SELECT id FROM {$this->tabla} ORDER BY id desc");

            $collection = [
                'cantidadFilas' => $Datos,
                'ultimoId' => $DatoUltimo ? $DatoUltimo->id : 0,
                // 'listaIds' => $DatosIDs
            ];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function listRowsBetween($perPage = 12, $currentPage = 0)
    {
        try {
            // $currentPage = LengthAwarePaginator::resolveCurrentPage('producto', 0);
            // dd($currentPage);
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->orderBy('id', 'desc')
                ->offset($currentPage * $perPage)
                ->limit($perPage)
                ->get();

            // $currentPAgeSearchResult = $Datos->slice($currentPage * $perPage, $perPage);

            $collection = collect([]);
            foreach ($Datos as $key => $value) {
                $collection->push([
                    'id' => $value->id,
                    "{$this->tabla_envio}" => $value,
                    'loading' => false,
                ]);
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
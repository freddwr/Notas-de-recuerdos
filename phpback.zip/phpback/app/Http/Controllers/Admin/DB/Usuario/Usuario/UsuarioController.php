<?php

namespace App\Http\Controllers\Admin\DB\Usuario\Usuario;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

use App\Http\Controllers\Admin\DB\Usuario\Usuario\Others;

class UsuarioController extends Others
{

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            // 'index',
            // 'edit',
            // 'store',
            // 'update',
            // 'destroy',
        ]]);
    }

    // public function index()
    // {
    //     try {

    //         $Datos = DB::table("{$this->tabla}")->orderBy('id', 'desc')->get();

    //         $collection = collect([]);
    //         foreach ($Datos as $key => $value) {
    //             $collection->push([
    //                 'id' => $value->id,
    //                 "{$this->tabla}" => $value,
    //                 'loading' => false
    //             ]);
    //         }

    //         return $this->sendResponse200($collection, "{$this->success_get_message}");
    //     } catch (\Exception $e) {
    //         return $this->sendError500($e->getMessage(), '');
    //     }
    // }

    public function store(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'id' => 'required|string|max:100',
        //     'nombre' => 'required|string|max:50',
        //     'genero' => 'string|max:6',
        // ]);
        $datos = $request->json()->all();

        // if ($validator->fails()) : return $this->sendError405('', "{$this->data_require}"); endif;

        // [$palabra] = $this->textUppercase($request->nombre);
        // $nombre = $palabra;

        if ($request->fotonew) {
            [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutFileArchivo($request->foto, $request->fotonew, $request->fotoextension, "{$this->tabla}", "img_{$this->tabla}");

            $datos['foto'] = $foto;
            $datos['fototam'] = $fototam;
            $datos['fototipo'] = $fototipo;
        } else {
            $datos['foto'] = null;
            $datos['fototam'] = null;
            $datos['fototipo'] = null;
        }

        unset($datos['fotonew']);
        unset($datos['fotoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            $clienteId = DB::table("{$this->tabla}")->insertGetId([
                // 'id' => "{$request->id}",
                'nombre' => "{$request->nombre}",
                'paterno' => "{$request->paterno}",
                'materno' => "{$request->materno}",
                // 'profesion' => "{$request->profesion}",
                // 'profesion_abreviatura' => "{$request->profesion_abreviatura}",
                'telefono' => "{$request->telefono}",
                'correo' => "{$request->correo}",
                // 'prefijo_telefono' => "+591",
                // 'nick' => "{$request->nick}",
                // 'activo' => $request->activo,
                'rol' => "{$request->rol}",
                'id_profesion' => "{$request->id_profesion}",
                'id_codigo_pais' => "{$request->id_codigo_pais}",
                // 'id_persona' => $request->id_persona,
                // 'id_anterior' => $request->id_anterior,
                // 'id_roles' => $request->id_roles,
                'foto' => $datos['foto'],
                'fototam' => $datos['fototam'],
                'fototipo' => $datos['fototipo'],
                'nick' => "{$request->password}",
                'pass_view' => "{$request->password}",
                'password' => Hash::make("{$request->password}"),
            ]);

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->selectRaw(DB::raw($this->nombre_completo))
                ->where(['id' => $clienteId])
                ->first();

            $rolUsuario = $this->getRolUsuario($Datos->rol);

            $profData = null;
            if ($Datos && $Datos->id_profesion) {
                $profData = DB::table("{$this->tabla_profesion}")
                    ->select(...$this->select_profesion)
                    ->where('id', $Datos->id_profesion)
                    ->first();
            }

            $paisData = null;
            if ($Datos && $Datos->id_codigo_pais) {
                $paisData = DB::table("{$this->tabla_codigo_pais}")
                    ->select(...$this->select_codigo_pais)
                    ->where('id', $Datos->id_codigo_pais)
                    ->first();
            }

            $collection = [
                'id' => $Datos->id,
                "{$this->tabla_envio}" => $Datos,
                'loading' => false,
                "{$this->tabla_rol_envio}" => $rolUsuario,
                "{$this->tabla_profesion_envio}" => $profData,
                "{$this->tabla_codigo_pais_envio}" => $paisData,
            ];

            return $this->sendResponse200($collection, "{$this->success_register_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function edit($usuario)
    {
        $id = $usuario;
        try {
            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->selectRaw(DB::raw($this->nombre_completo))
                ->where('id', $id)
                ->first();

            $rolUsuario = $this->getRolUsuario($Datos->rol);

            $profData = null;
            if ($Datos && $Datos->id_profesion) {
                $profData = DB::table("{$this->tabla_profesion}")
                    ->select(...$this->select_profesion)
                    ->where('id', $Datos->id_profesion)
                    ->first();
            }

            $paisData = null;
            if ($Datos && $Datos->id_codigo_pais) {
                $paisData = DB::table("{$this->tabla_codigo_pais}")
                    ->select(...$this->select_codigo_pais)
                    ->where('id', $Datos->id_codigo_pais)
                    ->first();
            }

            $collection = [];

            $collection = [
                'id' => $id,
                "{$this->tabla_envio}" => $Datos,
                'loading' => false,
                "{$this->tabla_rol_envio}" => $rolUsuario,
                "{$this->tabla_profesion_envio}" => $profData,
                "{$this->tabla_codigo_pais_envio}" => $paisData,
            ];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function update(Request $request, $usuario)
    {

        $Id = $usuario;
        $datos = $request->json()->all();

        if ($request->fotonew) {
            [$foto, $fototam, $fototipo, $fototipocom] = $this->imagePutFileArchivo($request->foto, $request->fotonew, $request->fotoextension, "{$this->tabla}", "img_{$this->tabla}");

            $this->deleteFile("{$this->tabla}", $Id, 'foto');

            $datos['foto'] = $foto;
            $datos['fototam'] = $fototam;
            $datos['fototipo'] = $fototipo;
        } else {
            unset($datos['foto']);
            unset($datos['fototam']);
            unset($datos['fototamtipo']);
        }

        unset($datos['passwordConfirm']);
        unset($datos['nombre_completo']);
        unset($datos['fototipocom']);
        unset($datos['fotonew']);
        unset($datos['fotoextension']);
        unset($datos['created']);
        unset($datos['updated']);

        try {
            foreach (array_keys($datos) as $campo) {
                DB::table("{$this->tabla}")->where('id', $Id)->update([
                    $campo => $datos[$campo],
                ]);
            }

            $Datos = DB::table("{$this->tabla}")
                ->select(...$this->select)
                ->selectRaw(DB::raw($this->nombre_completo))
                ->where(['id' => $Id])
                ->first();

            $rolUsuario = $this->getRolUsuario($Datos->rol);

            $profData = null;
            if ($Datos && $Datos->id_profesion) {
                $profData = DB::table("{$this->tabla_profesion}")
                    ->select(...$this->select_profesion)
                    ->where('id', $Datos->id_profesion)
                    ->first();
            }

            $paisData = null;
            if ($Datos && $Datos->id_codigo_pais) {
                $paisData = DB::table("{$this->tabla_codigo_pais}")
                    ->select(...$this->select_codigo_pais)
                    ->where('id', $Datos->id_codigo_pais)
                    ->first();
            }

            $collection = [];
            $collection = [
                'id' => $Id,
                "{$this->tabla_envio}" => $Datos,
                'loading' => false,
                "{$this->tabla_rol_envio}" => $rolUsuario,
                "{$this->tabla_profesion_envio}" => $profData,
                "{$this->tabla_codigo_pais_envio}" => $paisData,
            ];

            return $this->sendResponse200($collection, "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function updatePassword(Request $request, $usuario)
    {

        $Id = $usuario;

        try {
            DB::table("{$this->tabla}")->where('id', $Id)->update([
                'pass_view' => "{$request->password}",
                'password' => Hash::make("{$request->password}"),
            ]);

            return $this->sendResponse200([], "{$this->success_update_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function destroy($id)
    {

        try {
            $this->deleteFile($this->tabla, $id, 'foto');
            DB::table("{$this->tabla}")->where('id', $id)->delete();

            return $this->sendResponse200(['local' => $id], "{$this->success_delete_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}
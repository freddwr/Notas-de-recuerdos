<?php

namespace App\Http\Controllers\Admin\DB\Estadistica;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;

class EstadisticaController extends Ctrl
{

    // private $tabla = 'personal';

    public function __construct(){
        $this->middleware('jwt.verify', ['except' => [
            'numeros',
            'estadisticasemanal',
            'estadisticames',
            'estadisticaanio',
            'estadisticaservicio',
        ]]);
    }

    public function numeros(){
        try {
            $collectionnumeros = collect([]);

            $Datos_Clientes = DB::table('cliente')->select(DB::raw('count(*) as numero_clientes'))->first();
            $Datos_Personal = DB::table('personal')->select(DB::raw('count(*) as numero_personal'))->first();

            $collectionnumeros->push($Datos_Clientes);
            $collectionnumeros->push($Datos_Personal);

            return $this->sendResponse200($collectionnumeros, "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    // public function personalnumero(){
    //     try {

    //         $Datos_Personal = DB::table('personal')->select(DB::raw('count(*) as numero_personal'))->get();

    //         return $this->sendResponse200($Datos_Personal, "{$this->success_get_message}");

    //     } catch (\Exception $e) {
    //         return $this->sendError500($e->getMessage(), '');
    //     }
    // }

    public function estadisticasemanal(){
        try {

            $Datos_Semanales = DB::table('vista_dia_semana_vista_servicio_totalbs_group')->get();

            $collection = collect([0,0,0,0,0,0,0]);
            
            $datasets = collect([]);
            $borderColor = collect([]);
            $borderColor->push("rgb(255, 51, 57)");
            $labels = collect(["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"]);

            $i=0;
            foreach ($Datos_Semanales as $key => $value) {
                $i=($value->dia_semana)-1;
                $collection[$i]=floatval($value->total);
            }

            $datasets->push([
                'label' => "Total Bs.",
                'fill' => true,
                'borderColor' => $borderColor,
                'tension' => 0.1,
                'data' => $collection
            ]);


            return $this->sendResponse200(['labels'=>$labels, 'datasets'=>$datasets], "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
    
    public function estadisticames(){
        try {

            $Datos_Mes = DB::table('vista_mes_vista_servicio_totalbs_group')->get();

            $collection = collect([]);
            
            $labels = collect([]);
            $datasets = collect([]);
            $borderColor = collect([]);
            $borderColor->push("rgb(255, 51, 57)");
            
            $i=0;
            foreach ($Datos_Mes as $key => $value) {
                $collection->push(floatval($value->total));
                $labels->push($value->fecha);
            }
            
            $datasets->push([
                'label' => "Total Bs.",
                'fill' => true,
                'borderColor' => $borderColor,
                'tension' => 0.1,
                'data' => $collection
            ]);
            
            return $this->sendResponse200(['labels'=>$labels, 'datasets'=>$datasets], "{$this->success_get_message}");
            
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
    
    public function estadisticaanio(){
        try {

            $Datos_anual = DB::table('vista_anio_vista_servicio_totalbs_group')->get();

            $collection = collect([0,0,0,0,0,0,0,0,0,0,0,0]);
            
            $datasets = collect([]);
            $borderColor = collect([]);
            $borderColor->push("rgb(255, 51, 57)");
            $labels = collect(["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]);

            $i=0;
            foreach ($Datos_anual as $key => $value) {
                $i=($value->mes)-1;
                $collection[$i]=floatval($value->total);
            }

            $datasets->push([
                'label' => "Total Bs.",
                'fill' => true,
                'borderColor' => $borderColor,
                'tension' => 0.1,
                'data' => $collection
            ]);

            return $this->sendResponse200(['labels'=>$labels, 'datasets'=>$datasets], "{$this->success_get_message}");

        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function estadisticaservicio(){
        try{
            $collection = collect([]);
            $labels = collect([
                'Alizado Permanente', 
                'Baño Luna', 
                'Base', 'Cortes', 
                'Day Spa', 
                'Depilacion', 
                'Exfoliacion', 
                'Facial',
                'Mano',
                'Maquillaje',
                'Novias',
                'Peinado',
                'Quince Años',
                'Reductora',
                'Relax',
                'Tintes',
                'Tratamiento Capilar',
            ]);
            $salizado_permanente_bs = DB::table('s_alizado_permanente')->sum('precio_bs');
            $sbanio_luna_bs = DB::table('s_banio_luna')->sum('precio_bs');
            $sbase_bs = DB::table('s_base')->sum('precio_bs');
            $scortes_bs = DB::table('s_cortes')->sum('precio_bs');
            $sday_spa_bs = DB::table('s_day_spa')->sum('precio_bs');
            $sdepilacion_bs = DB::table('s_depilacion')->sum('precio_bs');
            $sexfoliacion_bs = DB::table('s_exfoliacion')->sum('precio_bs');
            $sfacial_bs = DB::table('s_facial')->sum('precio_bs');
            $smano_bs = DB::table('s_mano')->sum('precio_bs');
            $smaquillaje_bs = DB::table('s_maquillaje')->sum('precio_bs');
            $snovias_bs = DB::table('s_novias')->sum('precio_bs');
            $speinado_bs = DB::table('s_peinado')->sum('precio_bs');
            $squince_anios_bs = DB::table('s_quince_anios')->sum('precio_bs');
            $sreductora_bs = DB::table('s_reductora')->sum('precio_bs');
            $srelax_bs = DB::table('s_relax')->sum('precio_bs');
            $stintes_bs = DB::table('s_tintes')->sum('precio_bs');
            $stratamiento_capilar_bs = DB::table('s_tratamiento_capilar')->sum('precio_bs');
            $collection->push([floatval($salizado_permanente_bs)]);
            $collection->push([floatval($sbanio_luna_bs)]);
            $collection->push([floatval($sbase_bs)]);
            $collection->push([floatval($scortes_bs)]);
            $collection->push([floatval($sday_spa_bs)]);
            $collection->push([floatval($sdepilacion_bs)]);
            $collection->push([floatval($sexfoliacion_bs)]);
            $collection->push([floatval($sfacial_bs)]);
            $collection->push([floatval($smano_bs)]);
            $collection->push([floatval($smaquillaje_bs)]);
            $collection->push([floatval($snovias_bs)]);
            $collection->push([floatval($speinado_bs)]);
            $collection->push([floatval($squince_anios_bs)]);
            $collection->push([floatval($sreductora_bs)]);
            $collection->push([floatval($srelax_bs)]);
            $collection->push([floatval($stintes_bs)]);
            $collection->push([floatval($stratamiento_capilar_bs)]);

            $datasets=collect([]);
            $datasets->push([
                  'data'=> $collection,
                  'borderWidth'=> 2,
                  'borderColor'=> ["#641E16 ", "#512E5F", "#1B4F72", "#0E6251", "#7D6608", "#F39C12", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6", "--theme-color-6"],
                  'backgroundColor'=> [
                    "rgb(250, 219, 216)",
                    "rgb(235, 222, 240)",
                    "rgb(214, 234, 248 )",
                    "rgb(162, 217, 206)",
                    "rgb(252, 243, 207)",
                    "rgb(253, 235, 208 )",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10",
                    "--theme-color-3-10"
                  ]
            ]);

            // dd($datasets);

            return $this->sendResponse200(['labels'=>$labels, 'datasets'=>$datasets], "{$this->success_get_message}");

        }
        catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
    
}

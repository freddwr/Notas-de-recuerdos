<?php

namespace App\Http\Controllers\Admin\DB\Reporte;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Admin\ResController as Ctrl;
use Illuminate\Support\Facades\Validator;

class ReportesController extends Ctrl
{

    // private $tabla = 'personal';

    public function __construct()
    {
        $this->middleware('jwt.verify', ['except' => [
            'servicios_totales_entre',
            'ganacias_dia_entre',
            'ganancias_mes',
            'ganancias_anio',
            'ultimo_historial',
            'fechas_historial',
            // 'ganacias_por_servicio',
            // 'servicio_personal_entre',
            // 'servicio_todos_personal_entre',
        ]]);
    }

    public function servicios_totales_entre($min, $max)
    {
        try {

            $Datos = DB::table("vista_servicio_cliente")
                ->select(
                    'created',
                    'total_bs',
                    'hora_total',
                    'cliente',
                    'genero',
                    'cumpleanios_mes',
                    'cumpleanios_dia',
                    's_alizado_permanente',
                    's_banio_luna',
                    's_base',
                    's_cortes',
                    's_day_spa',
                    's_depilacion',
                    's_exfoliacion',
                    's_facial',
                    's_mano',
                    's_maquillaje',
                    's_novias',
                    's_peinado',
                    's_quince_anios',
                    's_reductora',
                    's_relax',
                    's_tintes',
                    's_tratamiento_capilar'
                )
                ->whereBetween('created', ($min == $max) ? ["{$min} 00:00:00", "{$max} 23:59:59"] : [$min, $max])
                ->get();


            $collection = [];
            $total = 0;

            foreach ($Datos as $key => $value) {
                $total = $total + $value->total_bs;
            }

            $collection = ['reporte' => $Datos, 'total' => $total];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ganacias_dia_entre($min, $max)
    {
        try {

            $Datos = DB::table("vista_servicio_totalbs_group")
                ->whereBetween('fecha', [$min, $max])
                ->get();

            $collection = [];
            $total = 0.0;

            foreach ($Datos as $key => $value) {
                $total = $total + $value->total;
            }

            $collection = ['reporte' => $Datos, 'total' => $total];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ganancias_mes($mes, $anio)
    {
        try {
            $Datos = DB::table("vista_servicio_totalbs_group")
                ->whereRaw("date_part('month'::text, fecha) = {$mes} AND date_part('year'::text, fecha) = {$anio}")
                ->get();

            $collection = [];
            $total = 0.0;

            foreach ($Datos as $key => $value) {
                $total = $total + $value->total;
            }

            $collection = ['reporte' => $Datos, 'total' => $total];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ganancias_anio($anio)
    {
        try {
            $Datos = DB::table("vista_servicio_totalbs_group")
                ->whereRaw("date_part('year'::text, fecha) = {$anio}")
                ->get();

            $collection = [];
            $total = 0.0;

            foreach ($Datos as $key => $value) {
                $total = $total + $value->total;
            }

            $collection = ['reporte' => $Datos, 'total' => $total];
            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ultimo_historial($id_cliente)
    {
        try {
            $tablas = [
                's_alizado_permanente',
                's_banio_luna',
                's_base',
                's_cortes',
                's_day_spa',
                's_depilacion',
                's_exfoliacion',
                's_facial',
                's_mano',
                's_maquillaje',
                's_novias',
                's_peinado',
                's_quince_anios',
                's_reductora',
                's_relax',
                's_tintes',
                's_tratamiento_capilar',
            ];
            $collection = collect([]);
            $collectionFinal = [];

            $Datos = DB::table("servicio")
                ->where('id_cliente', '=', $id_cliente)
                ->where('estado_servicio', '=', false)
                ->orderByRaw('id_int DESC')
                ->first();


            if ($Datos !== null) {
                foreach ($tablas as $key => $value) {
                    $tabla_historial = DB::table($value)
                        ->where('id_servicio', '=', $Datos->id)
                        ->get();
                    if (count($tabla_historial) > 0) {
                        $collection->push(['tabla' => $value, 'datos' => $tabla_historial]);
                    }
                }
                $imagenes = DB::table("imgs_x_servicios")
                    ->where('id_servicio', $Datos->id)
                    ->get();
                $collectionFinal = ['servicio' => $Datos, 'servicios' => $collection, 'imagenes' => $imagenes];
            }

            return $this->sendResponse200($collectionFinal, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function fechas_historial($fecha_inicio, $fecha_final, $id_cliente)
    {
        try {
            $tablas = [
                's_alizado_permanente',
                's_banio_luna',
                's_base',
                's_cortes',
                's_day_spa',
                's_depilacion',
                's_exfoliacion',
                's_facial',
                's_mano',
                's_maquillaje',
                's_novias',
                's_peinado',
                's_quince_anios',
                's_reductora',
                's_relax',
                's_tintes',
                's_tratamiento_capilar',
            ];
            $collectionFinal = collect([]);

            $from = date($fecha_inicio);
            $to = date($fecha_final);

            $Datos = DB::table("servicio")
                ->where(['id_cliente' => $id_cliente, ['created', '>=', $from], ['created', '<=', $to]])
                // ->whereBetween('created', [$from, $to])
                ->orderByRaw('id_int DESC')
                ->get();

            if ($Datos !== null) {

                foreach ($Datos as $key => $cadaServicio) {
                    $collection = collect([]);

                    foreach ($tablas as $key => $value) {
                        $tabla_historial = DB::table($value)
                            ->where('id_servicio', '=', $cadaServicio->id)
                            ->get();
                        if (count($tabla_historial) > 0) {
                            $collection->push(['tabla' => $value, 'datos' => $tabla_historial]);
                        }
                    }
                    $imagenes = DB::table("imgs_x_servicios")
                        ->where('id_servicio', $cadaServicio->id)
                        ->get();

                    $collectionFinal->push(['servicio' => $cadaServicio, 'servicios' => $collection, 'imagenes' => $imagenes]);
                }
            }

            return $this->sendResponse200($collectionFinal, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function personal_dia($fecha_dia, $id_personal)
    {
        try {
            $tablas = [
                's_alizado_permanente',
                's_banio_luna',
                's_base',
                's_cortes',
                's_day_spa',
                's_depilacion',
                's_exfoliacion',
                's_facial',
                's_mano',
                's_maquillaje',
                's_novias',
                's_peinado',
                's_quince_anios',
                's_reductora',
                's_relax',
                's_tintes',
                's_tratamiento_capilar',
            ];

            $from = date($fecha_dia);

            $collection = collect([]);

            foreach ($tablas as $key => $value) {
                $tabla_historial = DB::table($value)
                    ->where(['id_personal' => $id_personal])
                    ->whereDate('created', $from)
                    ->get();
                if (count($tabla_historial) > 0) {
                    $collection->push(['tabla' => $value, 'datos' => $tabla_historial]);
                }
            }

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function ganacias_por_servicio($servicio, $min, $max)
    {
        try {

            $Datos = DB::table($servicio)
                ->join('vista_servicio_cliente', "{$servicio}.id_servicio", '=', 'vista_servicio_cliente.id')
                ->join('vista_personal_completo', "{$servicio}.id_personal", '=', 'vista_personal_completo.id')
                ->whereBetween("{$servicio}.created", [$min, $max])
                ->select("{$servicio}.*", 'vista_servicio_cliente.cliente', 'vista_personal_completo.nombre_completo as personal')
                ->get();

            $collection = [];
            $total = 0.0;

            foreach ($Datos as $key => $value) {
                $total = $total + $value->precio_bs;
            }

            $collection = ['reporte' => $Datos, 'total' => $total, 'servicio' => $servicio];

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function servicio_personal_entre($personal, $servicio, $min, $max)
    {
        try {

            $p = DB::table("personal")
                ->where(['id' => $personal])
                ->get();

            $ser = DB::table("{$servicio}")
                ->join('vista_servicio_cliente', "{$servicio}.id_servicio", '=', 'vista_servicio_cliente.id')
                ->where(["{$servicio}.id_personal" => $personal])
                ->whereBetween("{$servicio}.created", [$min, $max])
                ->select("{$servicio}.*", 'vista_servicio_cliente.cliente')
                ->get();

            $collection = collect([]);

            $collection->push($p, $ser);

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }

    public function servicio_todos_personal_entre($personal, $min, $max)
    {
        try {

            $p = DB::table("personal")
                ->where(['id' => $personal])
                ->get();

            $s_alizado_permanente = DB::table("s_alizado_permanente")
                ->join('vista_servicio_cliente', 's_alizado_permanente.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_alizado_permanente.id_personal' => $personal])
                ->whereBetween('s_alizado_permanente.created', [$min, $max])
                ->select('s_alizado_permanente.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_banio_luna = DB::table("s_banio_luna")
                ->join('vista_servicio_cliente', 's_banio_luna.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_banio_luna.id_personal' => $personal])
                ->whereBetween('s_banio_luna.created', [$min, $max])
                ->select('s_banio_luna.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_base = DB::table("s_base")
                ->join('vista_servicio_cliente', 's_base.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_base.id_personal' => $personal])
                ->whereBetween('s_base.created', [$min, $max])
                ->select('s_base.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_cortes = DB::table("s_cortes")
                ->join('vista_servicio_cliente', 's_cortes.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_cortes.id_personal' => $personal])
                ->whereBetween('s_cortes.created', [$min, $max])
                ->select('s_cortes.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_day_spa = DB::table("s_day_spa")
                ->join('vista_servicio_cliente', 's_day_spa.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_day_spa.id_personal' => $personal])
                ->whereBetween('s_day_spa.created', [$min, $max])
                ->select('s_day_spa.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_depilacion = DB::table("s_depilacion")
                ->join('vista_servicio_cliente', 's_depilacion.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_depilacion.id_personal' => $personal])
                ->whereBetween('s_depilacion.created', [$min, $max])
                ->select('s_depilacion.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_exfoliacion = DB::table("s_exfoliacion")
                ->join('vista_servicio_cliente', 's_exfoliacion.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_exfoliacion.id_personal' => $personal])
                ->whereBetween('s_exfoliacion.created', [$min, $max])
                ->select('s_exfoliacion.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_facial = DB::table("s_facial")
                ->join('vista_servicio_cliente', 's_facial.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_facial.id_personal' => $personal])
                ->whereBetween('s_facial.created', [$min, $max])
                ->select('s_facial.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_mano = DB::table("s_mano")
                ->join('vista_servicio_cliente', "s_mano.id_servicio", '=', 'vista_servicio_cliente.id')
                ->where(["s_mano.id_personal" => $personal])
                ->whereBetween("s_mano.created", [$min, $max])
                ->select("s_mano.*", 'vista_servicio_cliente.cliente')
                ->get();

            $s_maquillaje = DB::table("s_maquillaje")
                ->join('vista_servicio_cliente', 's_maquillaje.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_maquillaje.id_personal' => $personal])
                ->whereBetween('s_maquillaje.created', [$min, $max])
                ->select('s_maquillaje.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_novias = DB::table("s_novias")
                ->join('vista_servicio_cliente', 's_novias.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_novias.id_personal' => $personal])
                ->whereBetween('s_novias.created', [$min, $max])
                ->select('s_novias.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_peinado = DB::table("s_peinado")
                ->join('vista_servicio_cliente', 's_peinado.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_peinado.id_personal' => $personal])
                ->whereBetween('s_peinado.created', [$min, $max])
                ->select('s_peinado.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_quince_anios = DB::table("s_quince_anios")
                ->join('vista_servicio_cliente', 's_quince_anios.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_quince_anios.id_personal' => $personal])
                ->whereBetween('s_quince_anios.created', [$min, $max])
                ->select('s_quince_anios.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_reductora = DB::table("s_reductora")
                ->join('vista_servicio_cliente', 's_reductora.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_reductora.id_personal' => $personal])
                ->whereBetween('s_reductora.created', [$min, $max])
                ->select('s_reductora.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_relax = DB::table("s_relax")
                ->join('vista_servicio_cliente', 's_relax.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_relax.id_personal' => $personal])
                ->whereBetween('s_relax.created', [$min, $max])
                ->select('s_relax.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_tintes = DB::table("s_tintes")
                ->join('vista_servicio_cliente', 's_tintes.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_tintes.id_personal' => $personal])
                ->whereBetween('s_tintes.created', [$min, $max])
                ->select('s_tintes.*', 'vista_servicio_cliente.cliente')
                ->get();

            $s_tratamiento_capilar = DB::table("s_tratamiento_capilar")
                ->join('vista_servicio_cliente', 's_tratamiento_capilar.id_servicio', '=', 'vista_servicio_cliente.id')
                ->where(['s_tratamiento_capilar.id_personal' => $personal])
                ->whereBetween('s_tratamiento_capilar.created', [$min, $max])
                ->select('s_tratamiento_capilar.*', 'vista_servicio_cliente.cliente')
                ->get();

            $collection = collect([]);

            $collection->push([
                'personal' => $p,
                's_alizado_permanente' => $s_alizado_permanente,
                's_banio_luna' => $s_banio_luna,
                's_base' => $s_base,
                's_cortes' => $s_cortes,
                's_day_spa' => $s_day_spa,
                's_depilacion' => $s_depilacion,
                's_exfoliacion' => $s_exfoliacion,
                's_facial' => $s_facial,
                's_mano' => $s_mano,
                's_maquillaje' => $s_maquillaje,
                's_novias' => $s_novias,
                's_peinado' => $s_peinado,
                's_quince_anios' => $s_quince_anios,
                's_reductora' => $s_reductora,
                's_relax' => $s_relax,
                's_tintes' => $s_tintes,
                's_tratamiento_capilar' => $s_tratamiento_capilar,
            ]);

            return $this->sendResponse200($collection, "{$this->success_get_message}");
        } catch (\Exception $e) {
            return $this->sendError500($e->getMessage(), '');
        }
    }
}

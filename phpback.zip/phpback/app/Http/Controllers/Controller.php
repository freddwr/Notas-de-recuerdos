<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Collection;
use Intervention\Image\ImageManagerStatic as Image;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public $success_get_message = "Datos obtenido";
    public $success_get_one_message = "Dato obtenido";
    public $success_login_message = "Cession iniciado exitosamente";
    public $success_register_message = "Registrado exitosamente";
    public $success_update_message = "Actualizado exitosamente";
    public $success_update_one_message = "Actualizado exitosamente un registro";
    public $success_delete_message = "Eliminado exitosamente";

    public $data_require = "Datos requeridos";

    public function sendResponse($result, $message, $code = 200)
    {
        $response = [
            'success' => true,
            'data'    => $result,
            'message' => $message,
        ];

        return response()->json($response, $code);
    }

    //no autorizado
    public function sendError401($error, $message)
    {
        $response = [
            'success' => false,
            'message' => $message,
        ];

        if (!empty($error)) {
            $response['data'] = $error;
        }

        return response()->json($response, 401);
    }

    public function sendResponseFuse($result, $message, $code = 200)
    {
        $response = [
            'success' => true,
            'data'    => $result,
            'message' => $message,
        ];

        return response()->json($response, $code);
    }

    public function sendErrorFuse($error, $errorMessages = [], $code = 200)
    {
        $response = [
            'success' => false,
            'data' => null,
            'message' => $errorMessages,
        ];

        if (!empty($error)) {
            $response['error'] = $error;
        }

        return response()->json($response, $code);
    }

    function menu_permisos($permiso)
    {
        $main_rutas = [];
        $main_ruta_principal = $permiso === 'estudiante_tobyc' ? '/student' : '/app';

        $main_rutas = [
            'Perfil' => in_array($permiso, ['administrador_tobyc', 'estudiante_tobyc'], true),
            'Mis-Cursos' => in_array($permiso, ['estudiante_tobyc'], true),

            'Group-Configuracion' => in_array($permiso, ['administrador_tobyc'], true),
            'Codigo-Pais' => in_array($permiso, ['administrador_tobyc'], true),
            'Profesion' => in_array($permiso, ['administrador_tobyc'], true),

            'Group-Usuario' => in_array($permiso, ['administrador_tobyc'], true),
            'Usuario' => in_array($permiso, ['administrador_tobyc'], true),
            'Docente' => in_array($permiso, ['administrador_tobyc'], true),
            'Estudiante' => in_array($permiso, ['administrador_tobyc'], true),
            // 'Codigo-Pais' => in_array($permiso, ['administrador_tobyc'], true),
            // 'Profesion' => in_array($permiso, ['administrador_tobyc'], true),

            'Group-Cursos' => in_array($permiso, ['administrador_tobyc'], true),
            'Cursos' => in_array($permiso, ['administrador_tobyc'], true),
            'Categoria-Cursos' => in_array($permiso, ['administrador_tobyc'], true),
            'Temario' => in_array($permiso, ['administrador_tobyc'], true),
            'Examen' => in_array($permiso, ['administrador_tobyc'], true),
            'Certificado' => in_array($permiso, ['administrador_tobyc'], true),

            'Group-Webinar' => in_array($permiso, ['administrador_tobyc'], true),
            'Webinar' => in_array($permiso, ['administrador_tobyc'], true),
            'Categoria-Webinar' => in_array($permiso, ['administrador_tobyc'], true),
            // 'Que-Aprenderas-Webinar' => in_array($permiso, ['administrador_tobyc'], true),
        ];
        // $main_rutas = [
        //     'Usuarios' => in_array($permiso, ['Gerente'], true),
        //     'Personal' => in_array($permiso, ['Gerente'], true),
        //     'Group-Usuarios' => in_array($permiso, ['Gerente'], true),
        //     'Cliente' => in_array($permiso, ['Gerente', 'Administrador'], true),
        //     'Servicios' => in_array($permiso, ['Gerente', 'Administrador'], true),
        //     'Historial' => in_array($permiso, ['Gerente'], true),
        //     'Estadistica' => in_array($permiso, ['Gerente'], true),
        //     'Reportes' => in_array($permiso, ['Gerente'], true),
        //     'Promocion' => in_array($permiso, ['Gerente'], true),
        // ];

        $Menu_Perfil = [
            'id' => "perfil",
            'icon' => "iconsminds-business-man",
            'label' => "menu.sidebar.perfil",
            'to' => "${main_ruta_principal}/perfil",
            'permiso' => $main_rutas['Perfil'],
            'newWindow' => false,
            'subs' => null,
        ];


        /* ADMINISTRADOR */
        /* MENU CURSO */

        $Menu_Cursos = [
            'id' => "cursos",
            'icon' => "iconsminds-student-hat",
            'label' => "menu.cursos",
            'to' => "$main_ruta_principal/menu-group-cursos/cursos/page/1",
            'permiso' => $main_rutas['Cursos'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Categoria_Cursos = [
            'id' => "categoria-cursos",
            'icon' => "iconsminds-id-card",
            'label' => "menu.sidebar.categoria-cursos",
            'to' => "$main_ruta_principal/menu-group-cursos/categoria-cursos/page/1",
            'permiso' => $main_rutas['Categoria-Cursos'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Examen = [
            'id' => "examen",
            'icon' => "iconsminds-check",
            'label' => "menu.examen",
            'to' => "$main_ruta_principal/menu-group-cursos/examen/page/1",
            'permiso' => $main_rutas['Examen'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Temario = [
            'id' => "temario",
            'icon' => "iconsminds-receipt-4",
            'label' => "menu.temario",
            'to' => "$main_ruta_principal/menu-group-cursos/temario/page/1",
            'permiso' => $main_rutas['Temario'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Certificado = [
            'id' => "certificado",
            'icon' => "iconsminds-diploma-2",
            'label' => "menu.certificado",
            'to' => "$main_ruta_principal/menu-group-cursos/certificado/page/1",
            'permiso' => $main_rutas['Certificado'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Group_Menu_Cursos = [
            'id' => "group-cursos",
            'icon' => "iconsminds-student-hat",
            'label' => "menu.sidebar.group-cursos",
            'to' => "$main_ruta_principal/menu-group-cursos",
            'permiso' => $main_rutas['Group-Cursos'],
            'newWindow' => false,
            'subs' => [
                $Menu_Cursos,
                $Menu_Categoria_Cursos,
                $Menu_Temario,
                $Menu_Examen,
                $Menu_Certificado,
                // $Menu_Que_Aprenderas_Cursos,
            ],
        ];

        /* MENU WEBINAR */

        $Menu_Webinar = [
            'id' => "webinar",
            'icon' => "iconsminds-blackboard",
            'label' => "menu.webinar",
            'to' => "$main_ruta_principal/menu-group-webinar/webinar/page/1",
            'permiso' => $main_rutas['Webinar'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Categoria_Webinar = [
            'id' => "category-webinar",
            'icon' => "iconsminds-id-card",
            'label' => "menu.sidebar.category-webinar",
            'to' => "$main_ruta_principal/menu-group-webinar/category-webinar/page/1",
            'permiso' => $main_rutas['Categoria-Webinar'],
            'newWindow' => false,
            'subs' => null,
        ];

        // $Menu_Que_Aprenderas_Webinar = [
        //     'id' => "que-aprenderas-webinar",
        //     'icon' => "iconsminds-business-man-woman",
        //     'label' => "menu.sidebar.que-aprenderas-webinar",
        //     'to' => "$main_ruta_principal/menu-group-webinar/que-aprenderas-webinar/page/1",
        //     'permiso' => $main_rutas['Que-Aprenderas-Webinar'],
        //     'newWindow' => false,
        //     'subs' => null,
        // ];

        $Group_Menu_Webinar = [
            'id' => "group-webinar",
            'icon' => "iconsminds-blackboard",
            'label' => "menu.sidebar.group-webinar",
            'to' => "$main_ruta_principal/menu-group-webinar",
            'permiso' => $main_rutas['Group-Webinar'],
            'newWindow' => false,
            'subs' => [
                $Menu_Categoria_Webinar,
                // $Menu_Que_Aprenderas_Webinar,
                $Menu_Webinar
            ],
        ];
        /* MENU CONFIGURACION */

        $Codigo_Pais = [
            'id' => "codigo-pais",
            'icon' => "iconsminds-edit-map",
            'label' => "menu.codigo-pais",
            'to' => "$main_ruta_principal/menu-group-configuracion/codigo-pais/page/1",
            'permiso' => $main_rutas['Codigo-Pais'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Profesion = [
            'id' => "profesion",
            'icon' => "iconsminds-engineering",
            'label' => "menu.profesion",
            'to' => "$main_ruta_principal/menu-group-configuracion/profesion/page/1",
            'permiso' => $main_rutas['Profesion'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Group_Menu_Configuracion = [
            'id' => "group-configuracion",
            'icon' => "iconsminds-gear",
            'label' => "menu.sidebar.group-configuracion",
            'to' => "$main_ruta_principal/menu-group-configuracion",
            'permiso' => $main_rutas['Group-Configuracion'],
            'newWindow' => false,
            'subs' => [
                $Codigo_Pais,
                $Profesion,
            ],
        ];

        /* MENU USUARIO */

        $Menu_Usuario = [
            'id' => "usuario",
            'icon' => "iconsminds-male-female",
            'label' => "menu.usuario",
            'to' => "$main_ruta_principal/menu-group-usuario/usuario/page/1",
            'permiso' => $main_rutas['Usuario'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Estudiante = [
            'id' => "estudiante",
            'icon' => "iconsminds-student-male-female",
            'label' => "menu.estudiante",
            'to' => "$main_ruta_principal/menu-group-usuario/estudiante/page/1",
            'permiso' => $main_rutas['Estudiante'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Menu_Docente = [
            'id' => "docente",
            'icon' => "iconsminds-business-man-woman",
            'label' => "menu.docente",
            'to' => "$main_ruta_principal/menu-group-usuario/docente/page/1",
            'permiso' => $main_rutas['Docente'],
            'newWindow' => false,
            'subs' => null,
        ];

        $Group_Menu_Usuario = [
            'id' => "group-usuario",
            'icon' => "iconsminds-male-female",
            'label' => "menu.sidebar.group-usuario",
            'to' => "$main_ruta_principal/menu-group-usuario",
            'permiso' => $main_rutas['Group-Usuario'],
            'newWindow' => false,
            'subs' => [
                $Menu_Usuario,
                $Menu_Docente,
                $Menu_Estudiante,
            ],
        ];


        /* ESTUDIANTE */
        /* MENU MIS CURSO */

        $Menu_Mis_Cursos = [
            'id' => "mis-cursos",
            'icon' => "iconsminds-student-hat",
            'label' => "menu.mis-cursos",
            'to' => "$main_ruta_principal/menu-group-mis-cursos/mis-cursos/page/1",
            'permiso' => $main_rutas['Mis-Cursos'],
            'newWindow' => false,
            'subs' => null,
        ];

        $main_menu = collect([]);
        $main_menu->push(
            // $Menu_Perfil,
            /* ADMINISTRADOR */
            $Group_Menu_Configuracion,
            $Group_Menu_Usuario,
            $Group_Menu_Cursos,
            $Group_Menu_Webinar,
            /* ADMINISTRADOR */
            $Menu_Mis_Cursos,
        );

        return [$main_ruta_principal, $main_rutas, $main_menu->toArray()];
    }

    function imagePutUsuario($img, $fotonew, $fotoextension, $carpeta)
    {
        $image = $img;
        $image_extension = "";
        $image_extension_completo = "";
        $archivo_extension = '';
        $cont = 0;

        $allowed_mimetypes_excel_pdf = array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/pdf', 'application/zip');

        $allowed_mimetypes_imagen = array('image/png', 'image/jpeg', 'image/jpg');

        if ($image && in_array($fotoextension, $allowed_mimetypes_excel_pdf)) {
            preg_match("/data:application\/(.*?);/", $image, $image_extension);
            preg_match("/data:(.*?);/", $image, $image_extension_completo);
            $cont = 1;
        }

        if ($image && in_array($fotoextension, $allowed_mimetypes_imagen)) {
            preg_match("/data:image\/(.*?);/", $image, $image_extension);
            preg_match("/data:(.*?);/", $image, $image_extension_completo);
            $cont = 2;
        }

        $datos['foto'] = "";
        $datos['fototam'] = 0.0;
        $datos['fototipo'] = "";
        $datos['fototipocom'] = "";

        $allowed_mimetypes = array('zip', 'png', 'jpeg', 'jpg', 'pdf', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet');

        if ($fotonew && $image && in_array($image_extension[1], $allowed_mimetypes)) {

            if ($cont == 1) $image = preg_replace("/data:application\/(.*?);base64,/", '', $image);

            if ($cont == 2) $image = preg_replace("/data:image\/(.*?);base64,/", '', $image);

            $image = str_replace(' ', '+', $image);

            if ($image_extension[1] == 'vnd.openxmlformats-officedocument.spreadsheetml.sheet') $image_extension[1] = 'xlsx';

            $imageName = "{$carpeta}_image_" . date('Ymd_Gis') . '.' . $image_extension[1];
            Storage::disk("{$carpeta}")->put("{$imageName}", base64_decode($image));

            $datos['foto'] = $imageName;
            $datos['fototam'] = round(floatval((strlen(base64_decode($image))) / 1024), 4);
            $datos['fototipo'] = $image_extension[1];
            $datos['fototipocom'] = $image_extension_completo[1];
        }

        return [
            $datos['foto'],
            $datos['fototam'],
            $datos['fototipo'],
            $datos['fototipocom']
        ];
    }

    function deleteFile($tabla, $id,  $campo)
    {
        try {

            $delete = DB::table("{$tabla}")
                ->where('id', $id)
                ->first();

            Storage::disk("{$tabla}")->delete("{$delete->$campo}");

            DB::table("{$tabla}")
                ->where('id', $id)
                ->update([
                    "${campo}" => '',
                    "${campo}tipo" => '',
                    "${campo}tam" => 0,
                ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}
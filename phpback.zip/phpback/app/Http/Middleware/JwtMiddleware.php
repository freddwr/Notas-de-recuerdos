<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use JWTAuth;
use Exception;
use Tymon\JWTAuth\Http\Middleware\BaseMiddleware;
use Illuminate\Support\Facades\DB;


class JwtMiddleware extends BaseMiddleware
{
    // public function handle(Request $request, Closure $next)
    // {
    //     return $next($request);
    // }

    public function handle($request, Closure $next)
    {
        // dd($request->server->get('DOCUMENT_ROOT'));
        // dd($request->headers->get('referer'));
        // dd(JWTAuth::parseToken()->authenticate());
        try {
            $user = JWTAuth::parseToken()->authenticate();
            if (!$user) throw new Exception('User Not Found');
        } catch (Exception $e) {
            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException) {
                return response()->json([
                    'data' => null,
                    'status' => false,
                    'err_' => [
                        'message' => 'Token Invalid',
                        'code' => 1
                    ]
                ]);
            } else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException) {
                // try
                // {
                //     $refreshed = JWTAuth::refresh(JWTAuth::getToken());
                //     $user = JWTAuth::setToken($refreshed)->toUser();
                //     $request->headers->set('Authorization','Bearer '.$refreshed);

                //     return response()->json([
                //         'token' => $refreshed
                //     ],200);

                // }catch (JWTException $e){
                //     return response()->json([
                //         'code'   => 103,
                //         'message' => 'Token cannot be refreshed, please Login again'
                //     ],200);
                // }

                return response()->json([
                    'data' => null,
                    'status' => false,
                    'err_' => [
                        'message' => 'Token Expired',
                        'code' => 1
                    ]
                ], 401);
            } else {
                if ($e->getMessage() === 'User Not Found') {
                    return response()->json([
                        "data" => null,
                        "status" => false,
                        "err_" => [
                            "message" => "User Not Found",
                            "code" => 1
                        ]
                    ]);
                }

                return response()->json([
                    'data' => null,
                    'status' => false,
                    'err_' => [
                        'message' => 'Authorization Token not found',
                        'code' => 1
                    ]
                ]);
            }
        }

        // dd($request);
        // $id = $this->v4();
        $id_users = auth()->user()->id;
        // $id_registro = $request->id;
        // // $acction = $request->server->get('DOCUMENT_ROOT'));
        // $tabla = explode("/",$request->server->get('REQUEST_URI'));
        // $ruta = $request->server->get('REQUEST_URI');
        // $navegador = $request->server->get('HTTP_SEC_CH_UA');
        // $ip = $request->server->get('REMOTE_ADDR');
        // $port = $request->server->get('REMOTE_PORT');
        // $tiempo = $request->server->get('REQUEST_TIME');
        // $accion = $request->server->get('REQUEST_METHOD');

        //    DB::table("users")->where([
        //        'id' => $id_users,
        //    ])->update([
        //        'estado' => true
        //    ]);

        //        if($tabla[3]!=='access_token')
        //        DB::table("usuario_historial_tabla")->insertGetId([
        //            'id' => $id,
        //            'id_registro' => $id_registro,
        //            'tabla' => $tabla[3],
        //            'accion' => $accion,
        //            'navegador' => $navegador,
        //            'ruta' => $ruta,
        //            'tiempo' => $tiempo,
        //            'ip' => $ip,
        //            'port' => $port,
        //            'id_users' => $id_users,
        //        ]);

        return $next($request);
    }

    function v4()
    {
        $data = openssl_random_pseudo_bytes(16, $secure);
        if (false === $data) {
            return false;
        }
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
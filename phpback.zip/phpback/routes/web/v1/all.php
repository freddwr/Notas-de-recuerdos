<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;


/* CURSO */

require(__DIR__ . './../routes/Cursos/cursos/all.php');
require(__DIR__ . './../routes/Cursos/inscripcion/all.php');
require(__DIR__ . './../routes/Webinar/webinar/all.php');
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Webinar\Webinar\QueryPublicWebinarController;

Route::prefix('public-webinar')->name('_public-webinar_')->group(function () {
    /* PUBLIC WEB */
    Route::get('/home', [QueryPublicWebinarController::class, 'publicGetWebinarHome']);
    Route::get('/webinar', [QueryPublicWebinarController::class, 'publicGetWebinarWebinar']);
    Route::get('/webinar/{webinarid}', [QueryPublicWebinarController::class, 'publicGetWebinarDetalle']);
});
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Cursos\QueryPublicCursosController;

Route::prefix('public-cursos')->name('_public-cursos_')->group(function () {
    /* PUBLIC WEB */
    Route::get('home', [QueryPublicCursosController::class, 'publicGetCursosHome']);
    Route::get('cursos', [QueryPublicCursosController::class, 'publicGetCursosCursos']);
    Route::get('curso/{cursoid}', [QueryPublicCursosController::class, 'publicGetCursoDetalle']);
});
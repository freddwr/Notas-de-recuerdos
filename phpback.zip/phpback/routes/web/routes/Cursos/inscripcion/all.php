<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\QueryPublicInscripcionController;

Route::prefix('public-inscripcion-verificacion')->name('_public-inscripcion-cursos_')->group(function () {
    /* PUBLIC WEB */
    Route::get('certificado-participacion/{certificado}', [QueryPublicInscripcionController::class, 'certificadoEstudianteComprobanteParticipacion']);
    Route::get('certificado-aprobacion/{certificado}', [QueryPublicInscripcionController::class, 'certificadoEstudianteComprobanteAprobacion']);
});
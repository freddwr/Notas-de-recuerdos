<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\CategoriaCurso\CategoriaCursoController;
use App\Http\Controllers\Admin\DB\Cursos\CategoriaCurso\QuerySearchCategoriaCursoController;

Route::prefix('categoria-curso')->name('_categoria_curso_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchCategoriaCursoController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchCategoriaCursoController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchCategoriaCursoController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/select', [CategoriaCursoController::class, 'index']);
    Route::post('/', [CategoriaCursoController::class, 'store']);
    Route::post('/search', [QuerySearchCategoriaCursoController::class, 'search']);
    Route::get('/{cliente}', [CategoriaCursoController::class, 'edit']);
    Route::put('/{cliente}', [CategoriaCursoController::class, 'update']);
    Route::delete('/{id}', [CategoriaCursoController::class, 'destroy']);
});
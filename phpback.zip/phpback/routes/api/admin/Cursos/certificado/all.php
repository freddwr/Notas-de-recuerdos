<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Certificado\CertificadoController;
use App\Http\Controllers\Admin\DB\Cursos\Certificado\QuerySearchCertificadoController;
use App\Http\Controllers\Admin\DB\Cursos\Certificado\QueryOtherCertificadoController;
use App\Http\Controllers\Admin\DB\Cursos\Certificado\QueryOtherEstudianteCertificadoController;

Route::prefix('certificado')->name('_certificado_')->group(function () {
    /* MORE QUERYS OTHER*/

    Route::get('estudiante-certificado/capacitacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'certificadoEstudianteCapacitacion']);
    Route::post('estudiante-certificado/capacitacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'certificadoEstudianteCapacitacionSave']);

    Route::get('estudiante-certificado/aprobacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'certificadoEstudianteAprobacion']);
    Route::post('estudiante-certificado/aprobacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'certificadoEstudianteAprobacionSave']);

    /* sin uso */
    Route::get('imagen-certificado/{imagenName}', [QueryOtherCertificadoController::class, 'getImage64Certificado']);
    /*  */
    Route::get('images-all-certificado/{certificado}/{curso}', [QueryOtherCertificadoController::class, 'getCursoCertificado']);
    Route::post('images-certificado-for-estudiante/{certificado}/save', [QueryOtherCertificadoController::class, 'certificadoEstudianteSave']);
    Route::post('image-one/{certificado}/update', [QueryOtherCertificadoController::class, 'updateOneImage']);
    Route::post('/asignacion-aprobacion', [QueryOtherCertificadoController::class, 'asignacionCursoCertificadoAprobacion']);
    Route::delete('/delete-asignacion-aprobacion/{asignacion}', [QueryOtherCertificadoController::class, 'deleteAsignacionCursoCertificadoAprobacion']);
    Route::post('/asignacion', [QueryOtherCertificadoController::class, 'asignacionCursoCertificadoCapacitacion']);
    Route::delete('/delete-asignacion/{asignacion}', [QueryOtherCertificadoController::class, 'deleteAsignacionCursoCertificadoCapacitacion']);
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchCertificadoController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchCertificadoController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchCertificadoController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/', [CertificadoController::class, 'index']);
    Route::post('/', [CertificadoController::class, 'store']);
    Route::post('/search', [QuerySearchCertificadoController::class, 'search']);
    Route::get('/{certificado}', [CertificadoController::class, 'edit']);
    Route::put('/{certificado}', [CertificadoController::class, 'update']);
    Route::delete('/{id}', [CertificadoController::class, 'destroy']);
});

Route::prefix('view-certificado-estudiante')->name('_certificado_')->group(function () {
    /* MORE QUERYS OTHER*/

    Route::get('capacitacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'viewCertificadoEstudianteCapacitacion']);
    Route::get('aprobacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'viewCertificadoEstudianteAprobacion']);
    // Route::post('estudiante-certificado/capacitacion/{certificado}', [QueryOtherEstudianteCertificadoController::class, 'certificadoEstudianteCapacitacionSave']);
});
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Temario\TemarioController;
use App\Http\Controllers\Admin\DB\Cursos\Temario\QuerySearchTemarioController;
use App\Http\Controllers\Admin\DB\Cursos\Temario\QueryOtherTemarioController;

Route::prefix('temario')->name('_ubicacion_')->group(function () {
    /* MORE QUERYS OTHER*/
    Route::post('/asignacion', [QueryOtherTemarioController::class, 'asignacionCursoTemario']);
    Route::delete('/delete-asignacion/{asignacion}', [QueryOtherTemarioController::class, 'deleteAsignacionCursoTemario']);
    // Route::get('/arhivo64/{archivo}', [QueryOtherTemarioController::class, 'filePdf']);
    /* MORE QUERYS SEARCH*/
    Route::get('/cantidad-rows', [QuerySearchTemarioController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchTemarioController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchTemarioController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/', [TemarioController::class, 'index']);
    Route::post('/', [TemarioController::class, 'store']);
    Route::post('/search', [QuerySearchTemarioController::class, 'search']);
    Route::get('/{temario}', [TemarioController::class, 'edit']);
    Route::put('/{temario}', [TemarioController::class, 'update']);
    Route::delete('/{id}', [TemarioController::class, 'destroy']);
});
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\ExamenPreguntas\PreguntasController;
use App\Http\Controllers\Admin\DB\Cursos\ExamenPreguntas\QuerySearchPreguntasController;
use App\Http\Controllers\Admin\DB\Cursos\ExamenPreguntas\QueryOtherPreguntasController;

Route::prefix('preguntas')->name('_preguntas_')->group(function () {
    /* MORE QUERYS OTHER*/
    Route::post('/remove/{pregunta}', [QueryOtherPreguntasController::class, 'deletePreguntaRespuestas']);
    /* MORE QUERYS SEARCH*/
    /* QUERYS CRUD */
    // Route::get('/', [PreguntasController::class, 'index']);
    Route::post('/', [PreguntasController::class, 'store']);
    // Route::get('/{preguntas}', [PreguntasController::class, 'edit']);
    // Route::put('/{preguntas}', [PreguntasController::class, 'update']);
    Route::delete('/{id}', [PreguntasController::class, 'destroy']);
});
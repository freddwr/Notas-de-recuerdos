<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Examen\ExamenController;
use App\Http\Controllers\Admin\DB\Cursos\Examen\QuerySearchExamenController;
use App\Http\Controllers\Admin\DB\Cursos\Examen\QueryOtherExamenController;

Route::prefix('examen')->name('_ubicacion_')->group(function () {
    /* MORE QUERYS OTHER*/
    Route::post('/asignacion', [QueryOtherExamenController::class, 'asignacionCursoExamen']);
    Route::delete('/delete-asignacion/{asignacion}', [QueryOtherExamenController::class, 'deleteAsignacionCursoExamen']);
    /* MORE QUERYS SEARCH*/
    Route::get('/cantidad-rows', [QuerySearchExamenController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchExamenController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchExamenController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/', [ExamenController::class, 'index']);
    Route::post('/', [ExamenController::class, 'store']);
    Route::post('/search', [QuerySearchExamenController::class, 'search']);
    Route::get('/{examen}', [ExamenController::class, 'edit']);
    Route::put('/{examen}', [ExamenController::class, 'update']);
    Route::delete('/{id}', [ExamenController::class, 'destroy']);
});

Route::prefix('test-course-student')->name('_test-course_')->group(function () {
    /* MORE QUERYS OTHER*/
    Route::get('/{curso}/{estudiante}/{inscripcion}', [QueryOtherExamenController::class, 'testComprobacionCurso']);
    Route::post('/fin-examen', [QueryOtherExamenController::class, 'finTestCurso']);
});
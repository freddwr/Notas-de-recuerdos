<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\InscripcionController;
use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\QuerySearchInscripcionController;
use App\Http\Controllers\Admin\DB\Cursos\Inscripcion\QueryOtherInscripcionController;

Route::prefix('inscripcion')->name('_ubicacion_')->group(function () {
    /* MORE QUERYS OTHER*/
    Route::get('certificado-64/{campo}/{estudiante}', [QueryOtherInscripcionController::class, 'cursosCertificado64']);
    Route::get('cursos-certificado/{estudiante}', [QueryOtherInscripcionController::class, 'cursosCertificadoEstudiante']);
    Route::get('settings-estudiante-all', [QueryOtherInscripcionController::class, 'ajustesEstudianteAll']);
    Route::get('settings-estudiante/{inscripcion}', [QueryOtherInscripcionController::class, 'ajustesEstudianteInscripcion']);
    Route::post('update-inscritos', [QueryOtherInscripcionController::class, 'ajustesAllUpdate']);
    /* MORE QUERYS */
    Route::get('/cantidad-rows/{curso}', [QuerySearchInscripcionController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}/{curso}', [QuerySearchInscripcionController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchInscripcionController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    // Route::get('/', [InscripcionController::class, 'index']);
    Route::post('/', [InscripcionController::class, 'store']);
    Route::post('/search', [QuerySearchInscripcionController::class, 'search']);
    Route::get('/{inscripcion}', [InscripcionController::class, 'edit']);
    Route::put('/{inscripcion}', [InscripcionController::class, 'update']);
    Route::delete('/{id}', [InscripcionController::class, 'destroy']);
});

/* ESTUDIANTE INSCRITO POR CURSOS */
Route::prefix('inscripcion-estudiante')->name('_cursos-estudiante_')->group(function () {
    /* MORE QUERYS OTHERS*/
    /* MORE QUERYS SEARCH*/
    Route::get('/cantidad-rows/{estudiante}', [QuerySearchInscripcionController::class, 'cantidadRowsEstudiante']);
    Route::get('/{perPage}/{currentPage}/{estudiante}', [QuerySearchInscripcionController::class, 'listRowsBetweenEstudiante']);
    // // Route::get('/{first}/{last}', [QuerySearchCursosController::class, 'listRowsBetween']);
    // /* QUERYS CRUD */
    Route::post('/search/{estudiante}', [QuerySearchInscripcionController::class, 'searchEstudiante']);
});
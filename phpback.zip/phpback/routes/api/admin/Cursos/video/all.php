<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Video\VideoController;
use App\Http\Controllers\Admin\DB\Cursos\Video\QuerySearchVideoController;

Route::prefix('video')->name('_video_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchVideoController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}/{curso}', [QuerySearchVideoController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchVideoController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    // Route::get('/', [VideoController::class, 'index']);
    Route::post('/', [VideoController::class, 'store']);
    Route::post('/search', [QuerySearchVideoController::class, 'search']);
    Route::get('/{video}', [VideoController::class, 'edit']);
    Route::put('/{video}', [VideoController::class, 'update']);
    Route::delete('/{id}', [VideoController::class, 'destroy']);
});

Route::prefix('video-estudiante')->name('_video-estudiante_')->group(function () {
    /* MORE QUERYS */
    // Route::get('/cantidad-rows/{curso}/{estudiante}', [QuerySearchVideoController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}/{curso}/{estudiante}', [QuerySearchVideoController::class, 'listRowsBetweenEstudiante']);
    /* QUERYS CRUD */
    // Route::post('/search/curso/{estudiante}', [QuerySearchVideoController::class, 'search']);
});
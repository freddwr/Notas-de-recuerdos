<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Cursos\Cursos\CursosController;
use App\Http\Controllers\Admin\DB\Cursos\Cursos\QuerySearchCursosController;
use App\Http\Controllers\Admin\DB\Cursos\Cursos\QueryOtherCursosController;

Route::prefix('cursos')->name('_cursos_')->group(function () {
    /* MORE QUERYS OTHERS*/
    Route::get('select-modalidad', [QueryOtherCursosController::class, 'selectTipoModalidad']);
    Route::get('settings-curso/{cursos}', [QueryOtherCursosController::class, 'ajustesCurso']);
    Route::get('list/{curso}/estudiante', [QueryOtherCursosController::class, 'viewCursoDetailsInfoListEstudiante']);
    /* MORE QUERYS SEARCH*/
    Route::get('/cantidad-rows', [QuerySearchCursosController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchCursosController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchCursosController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    // Route::get('/', [CursosController::class, 'index']);
    Route::post('/', [CursosController::class, 'store']);
    Route::post('/search', [QuerySearchCursosController::class, 'search']);
    Route::get('/{cursos}', [CursosController::class, 'edit']);
    Route::put('/{cursos}', [CursosController::class, 'update']);
    Route::delete('/{id}', [CursosController::class, 'destroy']);
});
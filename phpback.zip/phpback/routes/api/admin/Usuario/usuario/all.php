<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Usuario\Usuario\UsuarioController;
use App\Http\Controllers\Admin\DB\Usuario\Usuario\QuerySearchUsuarioController;
use App\Http\Controllers\Admin\DB\Usuario\Usuario\QueryOtherUsuarioController;

Route::prefix('usuario')->name('_usuario_')->group(function () {
    /* MORE QUERYS OTHERS*/
    Route::get('select-estudiante', [QueryOtherUsuarioController::class, 'selectEstudiante']);
    Route::get('select-docente', [QueryOtherUsuarioController::class, 'selectDocente']);
    /* MORE QUERYS SEARCH */
    /* -- USUARIO-- */
    Route::get('/cantidad-rows', [QuerySearchUsuarioController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchUsuarioController::class, 'listRowsBetween']);
    Route::post('usuario/search', [QuerySearchUsuarioController::class, 'searchUsuario']);
    /* -- ESTUDIANTE-- */
    Route::get('/cantidad-rows-estudiante', [QuerySearchUsuarioController::class, 'cantidadRowsEstudiante']);
    Route::get('/estudiante/{perPage}/{currentPage}', [QuerySearchUsuarioController::class, 'listRowsBetweenEstudiante']);
    Route::post('estudiante/search', [QuerySearchUsuarioController::class, 'searchEstudiante']);
    /* -- DOCENTE-- */
    Route::get('/cantidad-rows-docente', [QuerySearchUsuarioController::class, 'cantidadRowsDocente']);
    Route::get('/docente/{perPage}/{currentPage}', [QuerySearchUsuarioController::class, 'listRowsBetweenDocente']);
    Route::post('docente/search', [QuerySearchUsuarioController::class, 'searchDocente']);
    // Route::get('/{first}/{last}', [QuerySearchUsuarioController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    // Route::get('/', [UsuarioController::class, 'index']);
    Route::post('/', [UsuarioController::class, 'store']);
    Route::get('/{usuario}', [UsuarioController::class, 'edit']);
    Route::put('/{usuario}/change-password', [UsuarioController::class, 'updatePassword']);
    Route::put('/{usuario}', [UsuarioController::class, 'update']);
    Route::delete('/{id}', [UsuarioController::class, 'destroy']);
});
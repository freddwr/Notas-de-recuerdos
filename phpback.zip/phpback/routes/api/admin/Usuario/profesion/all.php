<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Usuario\Profesion\ProfesionController;
use App\Http\Controllers\Admin\DB\Usuario\Profesion\QuerySearchProfesionController;

Route::prefix('profesion')->name('_profesion_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchProfesionController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchProfesionController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchProfesionController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/', [ProfesionController::class, 'index']);
    Route::post('/', [ProfesionController::class, 'store']);
    Route::post('/search', [QuerySearchProfesionController::class, 'search']);
    Route::get('/{profesion}', [ProfesionController::class, 'edit']);
    Route::put('/{profesion}', [ProfesionController::class, 'update']);
    Route::delete('/{id}', [ProfesionController::class, 'destroy']);
});
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Usuario\CodigoPais\CodigoPaisController;
use App\Http\Controllers\Admin\DB\Usuario\CodigoPais\QuerySearchCodigoPaisController;

Route::prefix('codigo-pais')->name('_codigo-pais_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchCodigoPaisController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchCodigoPaisController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchCodigoPaisController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/', [CodigoPaisController::class, 'index']);
    Route::post('/', [CodigoPaisController::class, 'store']);
    Route::post('/search', [QuerySearchCodigoPaisController::class, 'search']);
    Route::get('/{cliente}', [CodigoPaisController::class, 'edit']);
    Route::put('/{cliente}', [CodigoPaisController::class, 'update']);
    Route::delete('/{id}', [CodigoPaisController::class, 'destroy']);
});
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Webinar\QueAprenderasWebinar\QueAprenderasWebinarController;
use App\Http\Controllers\Admin\DB\Webinar\QueAprenderasWebinar\QueryQueAprenderasWebinarController;

Route::prefix('que-aprenderas-webinar')->name('_ubicacion_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QueryQueAprenderasWebinarController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QueryQueAprenderasWebinarController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QueryQueAprenderasWebinarController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    // Route::get('/', [QueAprenderasWebinarController::class, 'index']);
    Route::post('/', [QueAprenderasWebinarController::class, 'store']);
    Route::post('/search', [QueryQueAprenderasWebinarController::class, 'search']);
    Route::get('/{cliente}', [QueAprenderasWebinarController::class, 'edit']);
    Route::put('/{cliente}', [QueAprenderasWebinarController::class, 'update']);
    Route::delete('/{id}', [QueAprenderasWebinarController::class, 'destroy']);
});
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Webinar\CategoriaWebinar\CategoriaWebinarController;
use App\Http\Controllers\Admin\DB\Webinar\CategoriaWebinar\QuerySearchCategoriaWebinarController;

Route::prefix('categoria-webinar')->name('_ubicacion_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchCategoriaWebinarController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchCategoriaWebinarController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchCategoriaWebinarController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    Route::get('/', [CategoriaWebinarController::class, 'index']);
    Route::post('/', [CategoriaWebinarController::class, 'store']);
    Route::post('/search', [QuerySearchCategoriaWebinarController::class, 'search']);
    Route::get('/{cliente}', [CategoriaWebinarController::class, 'edit']);
    Route::put('/{cliente}', [CategoriaWebinarController::class, 'update']);
    Route::delete('/{id}', [CategoriaWebinarController::class, 'destroy']);
});
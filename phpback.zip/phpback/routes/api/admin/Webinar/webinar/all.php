<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DB\Webinar\Webinar\WebinarController;
use App\Http\Controllers\Admin\DB\Webinar\Webinar\QuerySearchWebinarController;

Route::prefix('webinar')->name('_ubicacion_')->group(function () {
    /* MORE QUERYS */
    Route::get('/cantidad-rows', [QuerySearchWebinarController::class, 'cantidadRows']);
    Route::get('/{perPage}/{currentPage}', [QuerySearchWebinarController::class, 'listRowsBetween']);
    // Route::get('/{first}/{last}', [QuerySearchWebinarController::class, 'listRowsBetween']);
    /* QUERYS CRUD */
    // Route::get('/', [WebinarController::class, 'index']);
    Route::post('/', [WebinarController::class, 'store']);
    Route::post('/search', [QuerySearchWebinarController::class, 'search']);
    Route::get('/{webinar}', [WebinarController::class, 'edit']);
    Route::put('/{webinar}', [WebinarController::class, 'update']);
    Route::delete('/{id}', [WebinarController::class, 'destroy']);
});
<?php



header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization, Accept,charset,boundary,Content-Length');
header('Access-Control-Allow-Origin: *');



use Illuminate\Support\Facades\Route;



Route::prefix('v1')->name('_version_1_')->group(function(){
    // //usuarios
    require (__DIR__ . '/v1/all.php');
});

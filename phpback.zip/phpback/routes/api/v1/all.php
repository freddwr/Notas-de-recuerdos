<?php


use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\DB\Perfil\PerfilController;



Route::post('login', [AuthController::class, 'login']);
// Route::post('register', [AuthController::class, 'register']);
Route::get('refresh', [AuthController::class, 'refresh']);
// Route::post('forgot-password', [AuthController::class, 'fogotpassword']);

// Route::prefix('api')->group(function () {
Route::group(['middleware' => ['jwt.verify']], function () {

    Route::resource('perfil', PerfilController::class);

    Route::get('user/clear-photo', [AuthController::class, 'updateUserClearPhoto']);
    Route::get('user/datos/{user}', [AuthController::class, 'getUser']);
    Route::get('access_token', [AuthController::class, 'accessToken']);
    Route::put('user/change/{user}', [AuthController::class, 'updateUserPass'])->name('_change_pass_');
    Route::put('user/{user}', [AuthController::class, 'updateUser']);

    /* USUARIO */
    require(__DIR__ . './../admin/Usuario/usuario/all.php');
    require(__DIR__ . './../admin/Usuario/profesion/all.php');
    require(__DIR__ . './../admin/Usuario/codigo-pais/all.php');

    /* CURSO */
    require(__DIR__ . './../admin/Cursos/categoria-curso/all.php');
    require(__DIR__ . './../admin/Cursos/cursos/all.php');
    require(__DIR__ . './../admin/Cursos/temario/all.php');
    require(__DIR__ . './../admin/Cursos/examen/all.php');
    require(__DIR__ . './../admin/Cursos/examen/all-preguntas.php');
    require(__DIR__ . './../admin/Cursos/certificado/all.php');
    require(__DIR__ . './../admin/Cursos/video/all.php');
    require(__DIR__ . './../admin/Cursos/inscripcion/all.php');

    /* WEBINAR */
    require(__DIR__ . './../admin/Webinar/categoria-webinar/all.php');
    require(__DIR__ . './../admin/Webinar/que-aprenderas-webinar/all.php');
    require(__DIR__ . './../admin/Webinar/webinar/all.php');






    Route::get('logout', [AuthController::class, 'logout']);
    // Route::resource('docente', DocenteController::class);

});
<?php

header('Access-Control-Allow-Origin: *');

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\DB\Mail\CorreoMailController;


require(__DIR__ . '/web/api.php');



Route::get('contraseniapass', [AuthController::class, 'contraseniapass']);


Route::post('logout/user', [AuthController::class, 'logoutuser']);

Route::post('mail/{contrasenia}/{correo}/enviar', [CorreoMailController::class, 'enviarMail']);

Route::get('/{path?}', function () {
    return view('welcome');
})->where('path', '^((?!api).)*?');